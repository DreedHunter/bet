(function () {
  "use strict";

  // ═══════════════════════════════════════════════════════════════════════════
  // William Hill Fast Bet v3.0 — MAIN world.
  //
  // SCOPO: la GUI di William Hill (carrello → scrivi importo → Scommetti) è LENTA.
  //   Questa estensione ti fa piazzare in UN CLICK: clicchi una quota (es. "Casa (8)")
  //   e parte SUBITO la giocata con l'importo che imposti nel pannello, saltando
  //   del tutto il carrello.
  //
  // PIATTAFORMA: xSport. Piazzamento POST /XSportDatastore/purchase → code -9996 +
  //   delay dichiarato dal server (~10s reali ADM/Sogei), poi polling
  //   /getScheduledPurchaseTransaction finché code:0 + ticketSogei = confermata.
  //
  // COME COSTRUISCE IL PAYLOAD (cattura & replica):
  //   Il payload xSport è enorme. Catturiamo la PRIMA purchase reale che fai a mano
  //   (una giocata normale qualsiasi) e la usiamo come TEMPLATE. Poi, ad ogni click
  //   su una quota, iniettiamo nel template la selezione cliccata + il tuo importo.
  //
  // ⚠️ L'attesa ~10s dopo l'invio è del server (ADM), non riducibile. Qui
  //   velocizziamo il TUO gesto: 1 click invece di carrello+importo+Scommetti.
  // ═══════════════════════════════════════════════════════════════════════════

  const LS_STAKE    = "whfb_stake";
  const LS_TEMPLATE = "whfb_purchase_tpl";
  const LS_TOKEN    = "whfb_token";
  const LS_ENABLED  = "whfb_enabled";

  let stake   = 2.0;
  let enabled = true;
  let busy    = false;   // evita doppi invii ravvicinati

  try { const s = parseFloat(localStorage.getItem(LS_STAKE)); if (s > 0) stake = s; } catch (e) {}
  try { enabled = localStorage.getItem(LS_ENABLED) !== "0"; } catch (e) {}

  const API  = "/XSportDatastore/purchase";
  const POLL = "/XSportDatastore/getScheduledPurchaseTransaction";

  // ───────────────────── cattura template purchase ─────────────────────
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    this._whUrl = url || "";
    return _open.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (this._whUrl && this._whUrl.indexOf(API) !== -1 && body && !this._whFast) {
        try {
          const decoded = decodeURIComponent(String(body));
          const obj = JSON.parse(decoded);
          if (extractSelection(obj)) {
            localStorage.setItem(LS_TEMPLATE, decoded);
            const tm = this._whUrl.match(/[?&]token=([^&]+)/);
            if (tm) localStorage.setItem(LS_TOKEN, tm[1]);
            toast("Pronto ✓ — ora clicca una quota per giocare al volo", "ok", 4000);
            paintPanel();
          }
        } catch (e) {}
      }
    } catch (e) {}
    return _send.apply(this, arguments);
  };

  function extractSelection(obj) {
    try {
      const c1 = obj.betslip.coupons["1"];
      const sel = (c1.selections && c1.selections[0]) ||
                  (c1.multipleBonus && c1.multipleBonus.bonusElements && c1.multipleBonus.bonusElements[0]);
      if (sel && sel.bets && sel.bets[0]) return sel;
    } catch (e) {}
    return null;
  }
  function hasTemplate() { try { return !!localStorage.getItem(LS_TEMPLATE); } catch (e) { return false; } }

  // ───────────────────── lettura selezione dalla quota (DOM) ─────────────────────
  // La quota è un div.quota.quota-con-nome dentro una barra "barra-extra-{sport}_{cat}_{tor}_{idEv}_{scom}_{hcap}".
  // Ne ricaviamo: scomSogei, handicap, quota (odd) e nome esito (Casa/Ospite/Nessuno).
  function readSelection(quotaEl) {
    try {
      const barra = quotaEl.closest('[id^="barra-extra-"]');
      let scomSogei = null, handicap = null;
      if (barra) {
        const m = barra.id.match(/barra-extra-\d+_\d+_\d+_(\d+)_(\d+)_([\d;]+)/);
        if (m) { scomSogei = m[2]; handicap = m[3]; }
      }
      if (!scomSogei) return null;
      const spans = quotaEl.querySelectorAll("span");
      let descDraw = null, oddText = null;
      if (spans.length >= 2) {
        descDraw = (spans[0].textContent || "").replace(/\s*\(\d+\)\s*/, "").trim();
        oddText  = (spans[spans.length - 1].textContent || "").trim();
      }
      const odd = oddText ? Math.round(parseFloat(oddText.replace(",", ".")) * 100) : null;
      return { scomSogei, handicap, descDraw, odd, oddText };
    } catch (e) { return null; }
  }

  // dato un target di click, risale alla quota cliccabile giocabile
  function quotaFromTarget(el) {
    if (!el || !el.closest) return null;
    const q = el.closest(".quota-con-nome, .quota");
    return (q && q.closest('[id^="barra-extra-"]')) ? q : null;
  }

  // ───────────────────── invio purchase ─────────────────────
  function fastPurchase(sel) {
    if (busy) return;
    if (!hasTemplate()) {
      toast("Prima fai UNA giocata normale a mano (serve per il modello). Poi il click gioca al volo.", "warn", 7000);
      return;
    }
    if (!sel || !sel.scomSogei || sel.odd == null) { toast("Quota non leggibile.", "warn"); return; }

    let tpl;
    try { tpl = JSON.parse(localStorage.getItem(LS_TEMPLATE)); } catch (e) { toast("Modello non valido: rifai una giocata normale.", "warn"); return; }

    const amountCents = Math.round(stake * 100);
    const printable = stake.toFixed(2).replace(".", ",");
    const base = extractSelection(tpl) || {};

    const newBet = {
      scomSogei: parseInt(sel.scomSogei, 10),
      handicap: String(sel.handicap || "").split(";")[0],
      draw: 1, odd: String(sel.odd), legabile: false, combinationType: 0,
      amount: amountCents, printableAmount: printable,
      descBet: (base.bets && base.bets[0].descBet) || "", descDraw: sel.descDraw || "",
      minPlError: false, maxPlError: false, minOddError: null, isBonusMultiple: false, updated: null
    };
    const newSel = {
      pal: base.pal, avv: base.avv, banker: false, descEvent: base.descEvent || "",
      isLive: true, bets: [newBet], alias: base.alias || "",
      descSport: base.descSport || "", descTournament: base.descTournament || "",
      sportId: base.sportId || 1, tournamentId: base.tournamentId || 0,
      timestamp: base.timestamp || "", matchData: base.matchData || {}
    };

    try {
      const c1 = tpl.betslip.coupons["1"];
      c1.selections = [newSel];
      c1.selectedContainer = "singlebets";
      c1.amountSingle = amountCents; c1.amountMulti = amountCents; c1.betOnAll = amountCents;
      c1.printableBetOnAll = printable; c1.printableAmountMulti = printable;
      if (c1.multipleBonus) { c1.multipleBonus.bonusElements = []; c1.multipleBonus.applied = false; }
      tpl.betslip.selectedCoupon = "1";
      tpl.frontendTransactionId = (tpl.frontendTransactionId || "WILLIAMHILL-0-0").replace(/-\d+$/, "-" + Date.now());
    } catch (e) { toast("Errore nel costruire la giocata.", "warn"); return; }

    busy = true;
    const token = (() => { try { return localStorage.getItem(LS_TOKEN) || ""; } catch (e) { return ""; } })();
    const url = API + "?systemCode=WILLIAMHILL&lingua=IT&hash=&token=" + token + "&shopUserType=";
    const xhr = new XMLHttpRequest();
    xhr._whFast = true;
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8;");
    xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
    xhr.setRequestHeader("Cache-Control", "no-transform");
    const t0 = performance.now();
    toast(`▶ ${printable}€ su «${newBet.descDraw}» @${sel.oddText}…`, "info", 12000);
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      busy = false;
      try {
        const data = JSON.parse(xhr.responseText);
        const rc = data && data.returnCode;
        const tx = rc && rc.object && rc.object.transactionId;
        if (rc && (rc.code === -9996 || rc.code === 0) && tx) {
          const delay = (rc.object && rc.object.delay) || "?";
          toast(`In elaborazione (~${delay}s)…`, "info", 14000);
          pollOutcome(tx, t0);
        } else {
          toast(`Rifiutata (code ${rc ? rc.code : "?"}).`, "warn", 6000);
        }
      } catch (e) { toast("Risposta inattesa dal server.", "warn"); }
    };
    try { xhr.send(encodeURIComponent(JSON.stringify(tpl))); }
    catch (e) { busy = false; toast("Errore invio.", "warn"); }
  }

  function pollOutcome(transactionId, t0) {
    let tries = 0;
    const tick = () => {
      tries++;
      const xhr = new XMLHttpRequest();
      xhr._whFast = true;
      xhr.open("POST", POLL, true);
      xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8;");
      xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== 4) return;
        try {
          const data = JSON.parse(xhr.responseText);
          const rc = data && (data.returnCode ||
                     (data.responseSingle && data.responseSingle.returnCode) ||
                     (data.responseMultiple && data.responseMultiple.returnCode));
          const code = rc ? rc.code : null;
          const ticket = findTicket(data);
          if (code === 0 && ticket) {
            toast(`✓ CONFERMATA — ${((performance.now()-t0)/1000).toFixed(1)}s`, "ok", 8000);
            return;
          }
          if (code != null && code !== -9996 && code !== -9995 && code !== 0) {
            toast(`Esito: code ${code}. Controlla lo storico.`, "warn", 7000);
            return;
          }
        } catch (e) {}
        if (tries < 25) setTimeout(tick, 900);
        else toast("Esito non ricevuto — controlla lo storico.", "warn", 7000);
      };
      try { xhr.send(JSON.stringify({ transactionId: transactionId })); } catch (e) {}
    };
    setTimeout(tick, 900);
  }
  function findTicket(data) {
    try { for (const r of [data.responseSingle, data.responseMultiple, data.responseSystems]) if (r && r.ticketSogei) return r.ticketSogei; } catch (e) {}
    return null;
  }

  // ───────────────────── CLICK su quota = gioca ─────────────────────
  // Intercettiamo il click in CATTURA: se è su una quota e la Fast Bet è ON,
  // blocchiamo il comportamento nativo (che aprirebbe il carrello lento) e giochiamo.
  document.addEventListener("click", function (e) {
    if (!enabled) return;
    const q = quotaFromTarget(e.target);
    if (!q) return;
    e.preventDefault();
    e.stopPropagation();
    fastPurchase(readSelection(q));
  }, true);

  // ───────────────────── PANNELLO (solo importo + on/off) ─────────────────────
  const T = { accent: "#e2231a", bg: "#12161c", box: "#1b212b", border: "#2b3542", ok: "#1a9e5f" };

  function ensurePanel() {
    if (document.getElementById("whfb-panel")) return;
    const style = document.createElement("style");
    style.textContent = `
      #whfb-panel{position:fixed;right:16px;bottom:16px;z-index:2147483647;width:230px;
        font:13px/1.4 -apple-system,Segoe UI,sans-serif;color:#fff;background:${T.bg};
        border:1px solid ${T.border};border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.5);overflow:hidden}
      #whfb-panel .hd{display:flex;align-items:center;justify-content:space-between;
        padding:11px 13px;background:linear-gradient(135deg,${T.accent},#a01018);font-weight:800}
      #whfb-panel .hd small{opacity:.85;font-weight:600}
      #whfb-panel .bd{padding:12px 13px;display:flex;flex-direction:column;gap:10px}
      #whfb-panel .row{display:flex;align-items:center;justify-content:space-between;gap:8px;
        background:${T.box};border:1px solid ${T.border};border-radius:9px;padding:9px 11px}
      #whfb-panel .lbl{font-weight:700}
      #whfb-panel input#whfb-stake{width:88px;padding:7px 9px;border-radius:7px;border:1px solid ${T.border};
        background:${T.bg};color:${T.accent};font-weight:800;text-align:right;font-size:15px}
      #whfb-panel .sw{position:relative;width:44px;height:24px;border-radius:24px;background:#444;cursor:pointer;transition:.2s;flex:none}
      #whfb-panel .sw.on{background:${T.ok}}
      #whfb-panel .sw::after{content:"";position:absolute;top:2px;left:2px;width:20px;height:20px;border-radius:50%;background:#fff;transition:.2s}
      #whfb-panel .sw.on::after{left:22px}
      #whfb-panel .hint{font-size:11.5px;opacity:.82;text-align:center;line-height:1.35}
      #whfb-panel .hint b{color:${T.accent}}
      #whfb-toast{position:fixed;right:16px;bottom:210px;z-index:2147483647;max-width:290px;
        font:13px/1.4 -apple-system,Segoe UI,sans-serif;color:#fff;padding:11px 14px;border-radius:10px;
        box-shadow:0 6px 20px rgba(0,0,0,.4);display:none;font-weight:600}
    `;
    document.head.appendChild(style);

    const p = document.createElement("div");
    p.id = "whfb-panel";
    p.innerHTML = `
      <div class="hd"><span>⚡ WH Fast Bet</span><small>v3.0</small></div>
      <div class="bd">
        <div class="row"><span class="lbl">Fast Bet</span><div class="sw" id="whfb-sw"></div></div>
        <div class="row"><span class="lbl">Importo (€)</span><input type="number" id="whfb-stake" min="0.05" step="0.05"></div>
        <div class="hint" id="whfb-hint"></div>
      </div>`;
    (document.body || document.documentElement).appendChild(p);

    const stakeInput = p.querySelector("#whfb-stake");
    stakeInput.value = stake;
    stakeInput.addEventListener("input", () => {
      const v = parseFloat(stakeInput.value);
      if (v > 0) { stake = v; try { localStorage.setItem(LS_STAKE, String(v)); } catch (e) {} }
    });
    // impedisce che il click sull'input venga intercettato dal gioco-al-click
    stakeInput.addEventListener("click", (e) => e.stopPropagation(), true);
    p.querySelector("#whfb-sw").addEventListener("click", (e) => {
      e.stopPropagation();
      enabled = !enabled; try { localStorage.setItem(LS_ENABLED, enabled ? "1" : "0"); } catch (er) {}
      paintPanel();
    });
    // il pannello non deve mai far scattare il gioco-al-click
    p.addEventListener("click", (e) => e.stopPropagation(), true);

    paintPanel();
  }

  function paintPanel() {
    const p = document.getElementById("whfb-panel");
    if (!p) return;
    const sw = p.querySelector("#whfb-sw"); if (sw) sw.classList.toggle("on", enabled);
    const hint = p.querySelector("#whfb-hint");
    if (hint) {
      hint.innerHTML = hasTemplate()
        ? `<b>Clicca una quota</b> per giocare ${stake.toFixed(2).replace(".", ",")}€ al volo.<br>L'attesa ~10s è del server (ADM).`
        : `Fai <b>una giocata normale</b> la prima volta (per il modello). Poi il click gioca da solo.`;
    }
  }

  // ───────────────────── toast ─────────────────────
  let toastTimer = null;
  function toast(msg, kind, ms) {
    try {
      let t = document.getElementById("whfb-toast");
      if (!t) { t = document.createElement("div"); t.id = "whfb-toast"; (document.body||document.documentElement).appendChild(t); }
      const col = kind === "ok" ? "#0a7d2c" : kind === "warn" ? "#c0182b" : kind === "info" ? "#1560bd" : "#333";
      t.style.background = col; t.style.display = "block"; t.innerHTML = msg;
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => { t.style.display = "none"; }, ms || 3500);
    } catch (e) {}
  }

  function boot() { ensurePanel(); setInterval(ensurePanel, 3000); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, { once: true });
  else boot();

  console.log("%c[WH FastBet v3.0]%c click su una quota = gioca subito col tuo importo",
    "color:#fff;background:#e2231a;padding:1px 6px;border-radius:3px;font-weight:bold", "color:inherit");
})();
