// bridge.js — content script in ISOLATED world.
// Il plugin vero (fastbet.js) gira in MAIN world per intercettare le XHR di Angular,
// ma in MAIN world le chrome API (storage/runtime/tabs) non sono affidabili. Questo
// bridge sta in ISOLATED world, dove le chrome API funzionano, e fa da ponte:
//   MAIN (postMessage) → bridge (chrome.*) → background, e ritorno.
//
// Protocollo: fastbet.js manda window.postMessage({ source:"gbfb", type, ...payload, __req:id }).
// Il bridge esegue e, se serve una risposta, rimanda window.postMessage({ source:"gbfb-bridge", __res:id, ... }).

(function () {
  "use strict";

  // inoltra al background e (se richiesto) restituisce la risposta al MAIN
  function toBackground(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (resp) => {
          // ignora errori di canale (background addormentato ecc.)
          if (chrome.runtime.lastError) { resolve(null); return; }
          resolve(resp || null);
        });
      } catch (e) { resolve(null); }
    });
  }

  window.addEventListener("message", async (ev) => {
    // accetta solo messaggi da QUESTA pagina e con la nostra firma
    if (ev.source !== window) return;
    const msg = ev.data;
    if (!msg || msg.source !== "gbfb") return;

    try {
      switch (msg.type) {

        // salva gli header auth catturati (per bookmaker) — chrome.storage lato ISOLATED
        case "SAVE_AUTH": {
          const entry = {
            headers: msg.headers || {},
            allHeaders: msg.allHeaders || {},
            userAgent: msg.userAgent || null,
            lastInsertBetBody: msg.lastInsertBetBody || null,
            ts: msg.ts || Date.now(),
            bookmaker: msg.bookmaker
          };
          if (msg.bookmaker) chrome.storage.local.set({ ["auth_" + msg.bookmaker]: entry });
          break;
        }

        // richiesta di replica: inoltra al background che fa le fetch cross-dominio
        case "REPLICATE_BET": {
          const resp = await toBackground({
            type: "REPLICATE_BET",
            sourceBookmaker: msg.sourceBookmaker,
            payload: msg.payload,
            stake: msg.stake,
            betId: msg.betId || null,   // id del papà: le repliche lo ereditano
            t0Abs: msg.t0Abs || null,   // T0 comune per la timeline sincronizzata
            extraDomains: msg.extraDomains || [],
            extraAccounts: msg.extraAccounts || []   // account extra su cui replicare + saldi
          });
          if (msg.__req != null) {
            window.postMessage({
              source: "gbfb-bridge", __res: msg.__req,
              results: (resp && resp.results) || [],
              extraBalances: (resp && resp.extraBalances) || []   // saldi aggiornati account extra
            }, "*");
          }
          break;
        }

        // login account extra: inoltra al background che fa la fetch cross-dominio
        // sul dominio del bookmaker target (il content script non può per il CORS).
        case "LOGIN_EXTRA": {
          const resp = await toBackground({
            type: "LOGIN_EXTRA",
            bookmaker: msg.bookmaker,
            body: msg.body,
            brand: msg.brand
          });
          if (msg.__req != null) {
            window.postMessage(Object.assign(
              { source: "gbfb-bridge", __res: msg.__req },
              resp || { status: "error", data: null }
            ), "*");
          }
          break;
        }

        // apre le schede di login dei bookmaker (setup iniziale)
        case "OPEN_LOGIN_TABS": {
          await toBackground({ type: "OPEN_LOGIN_TABS", domains: msg.domains || [] });
          break;
        }

        // broadcast cross-scheda: inoltra al background un comando da recapitare
        // a TUTTE le schede del gruppo (es. action:"refresh_balance").
        case "BROADCAST_TO_TABS": {
          await toBackground({ type: "BROADCAST_TO_TABS", action: msg.action, payload: msg.payload });
          break;
        }

        // apre UNA scheda (per il re-login quando un token scade)
        case "OPEN_TAB": {
          await toBackground({ type: "OPEN_TAB", url: msg.url });
          break;
        }

        // salva il saldo di un bookmaker (per mostrarlo nel menu multibook)
        case "SAVE_BALANCE": {
          if (msg.bookmaker == null) break;
          chrome.storage.local.set({
            ["balance_" + msg.bookmaker]: { saldo: msg.saldo, ts: msg.ts || Date.now() }
          });
          break;
        }

        // legge lo stato auth di tutti i bookmaker (fresco/scaduto) + saldo e lo rimanda al MAIN
        case "GET_AUTH_STATUS": {
          chrome.storage.local.get(null, (all) => {
            const status = {};
            for (const k of Object.keys(all || {})) {
              if (k.indexOf("auth_") === 0) {
                const e = all[k];
                status[k.slice(5)] = { ts: e && e.ts, hasAuth: !!(e && e.headers && e.headers["X-Auth-Token"]) };
              }
            }
            // aggancia il saldo salvato a ciascun bookmaker
            for (const k of Object.keys(all || {})) {
              if (k.indexOf("balance_") === 0) {
                const bk = k.slice(8);
                const b = all[k];
                status[bk] = Object.assign(status[bk] || {}, { saldo: b && b.saldo, saldoTs: b && b.ts });
              }
            }
            if (msg.__req != null) {
              window.postMessage({ source: "gbfb-bridge", __res: msg.__req, status }, "*");
            }
          });
          break;
        }

        // salva/legge la lista dei domini custom aggiunti dall'utente (menu impostazioni)
        case "SET_CUSTOM_DOMAINS": {
          chrome.storage.local.set({ custom_domains: msg.domains || [] });
          break;
        }
        case "GET_CUSTOM_DOMAINS": {
          chrome.storage.local.get("custom_domains", (r) => {
            if (msg.__req != null) {
              window.postMessage({ source: "gbfb-bridge", __res: msg.__req, domains: (r && r.custom_domains) || [] }, "*");
            }
          });
          break;
        }

        // ─── SNIFF multi-bookmaker: persistenza + export aggregato cross-scheda ───
        // Ogni scheda scrive nella SUA chiave sniff_<bookmaker> (append, max 200).
        // Così l'export rilegge tutte le chiavi e mette insieme i 3 bookmaker.
        case "SNIFF_SAVE": {
          const bk = msg.bookmaker;
          if (!bk || !msg.entry) break;
          const key = "sniff_" + bk;
          chrome.storage.local.get(key, (r) => {
            const arr = (r && r[key]) || [];
            arr.unshift(msg.entry);
            if (arr.length > 200) arr.length = 200;
            chrome.storage.local.set({ [key]: arr });
          });
          break;
        }
        case "SNIFF_EXPORT": {
          chrome.storage.local.get(null, (all) => {
            const merged = [];
            for (const k of Object.keys(all || {})) {
              if (k.indexOf("sniff_") === 0 && Array.isArray(all[k])) merged.push(...all[k]);
            }
            merged.sort((a, b) => (b.ts || 0) - (a.ts || 0));
            if (msg.__sniffreq != null) {
              window.postMessage({ source: "gbfb-bridge", __sniffres: msg.__sniffreq, all: merged }, "*");
            }
          });
          break;
        }
        case "SNIFF_CLEAR": {
          chrome.storage.local.get(null, (all) => {
            const toRemove = Object.keys(all || {}).filter(k => k.indexOf("sniff_") === 0);
            if (toRemove.length) chrome.storage.local.remove(toRemove);
          });
          break;
        }
      }
    } catch (e) { /* silenzioso */ }
  });

  // ─── broadcast cross-scheda: comandi recapitati dal background ───
  // Il background (via chrome.tabs.sendMessage) manda GBFB_TAB_COMMAND a questa
  // tab. Lo inoltriamo al MAIN come TAB_COMMAND: fastbet.js decide cosa fare in
  // base ad action (es. "refresh_balance" → rilegge il proprio saldo).
  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg && msg.type === "GBFB_TAB_COMMAND" && msg.action) {
        try {
          window.postMessage({
            source: "gbfb-bridge", type: "TAB_COMMAND",
            action: msg.action, payload: msg.payload
          }, "*");
        } catch (e) {}
        try { sendResponse && sendResponse({ ok: true }); } catch (e) {}
      }
    });
  } catch (e) { /* chrome.runtime non disponibile: ignora */ }

  // segnala al MAIN che il bridge è pronto
  try { window.postMessage({ source: "gbfb-bridge", type: "READY" }, "*"); } catch (e) {}
})();
