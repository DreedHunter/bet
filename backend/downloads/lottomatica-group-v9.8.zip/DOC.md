# Lottomatica Group Fast Bet — Documentazione

## Cos'è
Estensione Chrome unificata che velocizza il piazzamento scommesse sui tre bookmaker del gruppo Lottomatica: **Goldbet**, **Lottomatica** e **Planetwin365**. È l'evoluzione delle tre estensioni singole (v6.x) in un unico plugin che riconosce il sito dall'hostname e permette anche la replica di una stessa giocata su più book (multibook).

## Piattaforma tecnica
GAD / piattaforma Lottomatica in **Angular** (custom elements Angular, endpoint `/api/sport/...`). I tre siti girano sulla stessa piattaforma tecnica. Endpoint chiave del piazzamento:
- `POST /api/sport/book/insertBet` — registra la scommessa e restituisce già il `couponCode`.
- `pendingBet` — passo successivo, in origine usato dal sito per un polling di conferma (in realtà estetico).
- `GET /api/sport/live/getDetailsEventLive/1/<evtId>` — stato live aggiornato di un evento (quote fresche, selezioni sospese).

## Velocità di piazzamento LIVE
**~2,4 secondi** (contro i ~7,4s originali del sito, circa -67%). Circa 1230 ms di `insertBet` sono server-side invalicabili. Il `couponCode` NON è generabile lato client (contiene un contatore globale di tutte le bet).

## Come funziona
Il trucco chiave è che `insertBet` restituisce già il `couponCode` alla prima chiamata: la scommessa è di fatto già registrata. Il passo `pendingBet` era solo un polling estetico. L'estensione intercetta `pendingBet` e **mocka la conferma** (`statusCode:"P"`), eliminando l'attesa fittizia. Oltre a questo offre:
- **Multibook (replica di gruppo)**: `evtId`, `selId`, `markId` e `aamsId` sono condivisi tra i 3 book, quindi la stessa giocata si replica sugli altri bookmaker senza tradurre gli ID; si recupera solo l'`oddsId` fresco del target (l'`oddsId` è l'unico dato che cambia per brand).
- **Hotkey** da tastiera (incluso il mercato "Prossimo Gol 1° Tempo").
- **Guardia anti-storno**: prima dell'invio confronta ogni selezione con lo stato reale del feed (cache `getDetailsEventLive`); se una selezione è sospesa o la quota si è mossa, avvisa del rischio storno.
- **Misura latenza** (click→invio e invio→risposta), **sniff multi-bookmaker** (`gbfbSniff()` in console) per confrontare gli ID e i tempi tra i book su una timeline sincronizzata per giocata.
- **Keep-alive** della sessione + lettura saldo, e **re-login automatico** dell'account principale e degli account extra (le sessioni scadono, il re-login usa l'hash della password salvato).

## Cosa è stato provato / scoperto
- Mock del `pendingBet` con `statusCode:"P"` → **funziona**, bet reale, tempo ridotto a ~2,4s.
- Verificato con sniff che `evtId`/`selId`/`markId`/`aamsId` sono **identici** sui 3 book → replica multibook fattibile senza mappa di traduzione.
- L'`oddsId` è volatile: cambia per brand e persino tra `checkEventOdd` e `insertBet` dello stesso book → va sempre riletto fresco.
- **Rischio storno reale**: se la selezione è sospesa o la quota è mossa al momento del mock, il server può stornare in riserva. Osservati storni concreti (es. **75€** e **52€**) → da qui la guardia anti-storno.
- Retry automatico su errore 41 (quota scaduta): recupera la quota fresca da `getDetailsEventLive` e ripiazza.

## Stato
**Funzionante.** È l'estensione di produzione del progetto. L'unico limite residuo è il rischio di storno quando la selezione cambia stato nell'istante del piazzamento (gestito ma non azzerabile: dipende dal server).

## Come si usa
1. Chrome → `chrome://extensions` → attiva **Modalità sviluppatore** → **Carica estensione non pacchettizzata** e seleziona la cartella `lottomatica_group_fast_bet`.
2. Fai login sul sito del bookmaker (Goldbet / Lottomatica / Planetwin365): l'estensione legge lo username dall'header.
3. Nell'overlay dell'estensione esegui il login con la licenza (email + password del backend). Il plugin si attiva solo se la licenza è attiva e lo username è autorizzato.
4. Prepara la giocata come al solito e piazza; usa le hotkey o il menu multibook se vuoi replicare su più book.
