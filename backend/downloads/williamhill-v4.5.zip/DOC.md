# William Hill Fast Bet (v4.5) — Documentazione

## Cos'è
Estensione Chrome che velocizza i **gesti** di piazzamento su **William Hill** (sports.williamhill.it). Non tocca il tempo del server: fa al posto tuo, in un click, i passaggi lenti della GUI (aggiungi al carrello → scrivi importo → clicca Scommetti).

## Piattaforma tecnica
**xSport** (la stessa di Vincitu e NetBet), frontend React. Piazzamento via `POST /XSportDatastore/purchase` seguito dal polling `getScheduledPurchaseTransaction`. Il server dichiara lui stesso un `delay` (in secondi) e tiene `ticketSogei` a null finché non finalizza.

## Velocità di piazzamento LIVE
Misurata (luglio 2026):
- Live in gioco: **~12 secondi** (il server dichiara `delay:10`).
- Live all'intervallo / momenti calmi: **~8,5 secondi** (`delay:7` — il server abbassa il delay quando la partita è ferma).
- Prematch: **~0,4 secondi** (nessun delay, `ticketSogei` subito, zero polling).

## Come funziona
Modalità **AUTO-CLICK DOM**. Al click o alla hotkey su una quota: l'estensione clicca la quota (è il SITO ad aggiungerla al carrello e a costruire il payload xSport corretto), scrive l'importo usando il native setter di React, poi clicca "Scommetti". Simula click reali (mousedown→mouseup→click) perché i click sintetici vengono ignorati dal framework. Hotkey per Casa/Ospite e Gol 1° Tempo Casa/Ospite. Palette nero/oro. Non blocca il click nativo (listener in bubbling).

## Cosa è stato provato / scoperto
- **API diretta**: costruire il payload xSport a mano viene **RIFIUTATO** dal server (`code -2007`, validazione) → si è scelto l'auto-click DOM, così è il sito a costruire il payload.
- **Live-as-prematch** (forzando `selection.isLive:false` + `matchData.isLive:false` su una live): **RIFIUTATA** con `code -5105` in 336 ms. Il server non si fida del flag: controlla lo stato reale dell'evento nel suo database.
- **Betdelay live NON azzerabile** (deciso da ADM/Sogei sullo stato reale dell'evento).

## Stato
**Funzionante come velocizzatore di invio.** NON azzera i secondi del server. Le uniche leve reali sono: (1) velocizzare il tuo invio, cosa che l'estensione fa; (2) tempismo, giocare all'intervallo (~8,5s invece di ~12s).

## Come si usa
1. Chrome → `chrome://extensions` → **Modalità sviluppatore** → **Carica estensione non pacchettizzata** → cartella `williamhill_fast_bet`.
2. Apri sports.williamhill.it e fai login sul sito.
3. Imposta l'importo nel pannello dell'estensione.
4. Clicca una quota (o usa la hotkey): l'estensione aggiunge al carrello, scrive l'importo e clicca Scommetti da sola. L'attesa dopo lo Scommetti è del server e non è riducibile.
