# BetFast — Betzone (v1.2.0) — Documentazione

## Cos'è
Estensione Chrome che velocizza il piazzamento e logga tutto il flusso su **Betzone** (betzone365.org / mywin365.net): dal POST alla riserva all'accettazione via Pusher, con cronometro. Elimina i ritardi lato client; la riserva lato server resta invariata.

## Piattaforma tecnica
Piattaforma **proprietaria PHP/jQuery** con autenticazione **JWT** e notifiche real-time via **Pusher** (`channelCoupon`). Il piazzamento passa da `playCouponFast` (hook su `$.ajax`, `window.vm`). Il coupon torna con uno stato a lettera: `G`/`R` = accettato, `Q`/`A`/`M` = in riserva/in accettazione, `B`/`N`/`D`/`T` = respinto/negato.

## Velocità di piazzamento LIVE
Lato server **~13 secondi** (la riserva, stato `Q`, tipica delle quote alte) — deciso dal bookmaker e non comprimibile. L'estensione taglia solo i ritardi client (countdown e guard).

## Come funziona
Gira nel contesto pagina (MAIN world) dove ha accesso a `window.vm`, jQuery e `window.channelCoupon`. Fa hook di `$.ajax` per cronometrare `playCouponFast` e loggarne l'esito, fa patch di `vm.clickPlayCouponFast` e **disattiva il countdown / il guard `timer_started`** del sito. Aggiunge un pulsante "⚡ PIAZZA VELOCE" + hotkey Spazio, un poll rapido opzionale per la verifica di accettazione, log colorato con export `.txt` e un cronometro che parte al piazzamento e si ferma su accettazione (verde) o rifiuto (rosso).

## Cosa è stato provato / scoperto
- Rimozione countdown/guard client + poll rapido → **funziona** lato client (invio immediato).
- **Live-as-prematch** (esperimento v1.2.0: riscrive `live=0` nel payload su `playCouponFast`/`saveCoupon`/`playCouponElite` e azzera il countdown live): **FALLITO**. Il server risponde `evento_LIVE_chiuso`: ignora il flag `live=0` e riconosce l'evento come live dal suo `id_event`.
- La riserva server (stato `Q`) NON è comprimibile: è la finestra reale di accettazione del bookmaker.

## Stato
**Parziale / Funzionante lato client.** Elimina i ritardi del client ma non la riserva server. Il travestimento live→prematch è un vicolo cieco confermato.

## Come si usa
1. Chrome → `chrome://extensions` → **Modalità sviluppatore** → **Carica estensione non pacchettizzata** → cartella `betfast-extension`.
2. Apri betzone365.org / mywin365.net e fai login: compare il pannello **BetFast** in alto a destra.
3. Prepara la giocata, imposta l'importo nel pannello e premi **⚡ PIAZZA VELOCE** (o barra **Spazio**). Guarda cronometro e log per i tempi reali.
