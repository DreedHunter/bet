# Changelog — BetFast

Versionamento: `MAJOR.MINOR.PATCH`. La versione è mostrata nell'header del pannello
(`vX.Y.Z`) e scritta nel log ad ogni caricamento, così sai sempre cosa è attivo.

## 1.2.0
- **Esperimento "Manda LIVE come pre-match"** (toggle 🧪 nel pannello e nel popup):
  - riscrive il flag `live` a `0` nel payload prima dell'invio, su `playCouponFast`,
    `saveCoupon` e `playCouponElite`, sia quando il coupon è un oggetto JS
    (`events[].live`, `events[].rows[].live`) sia quando è una stringa JSON/querystring;
  - azzera il countdown live del sito (`liveCountDown`, `countDownHandler`,
    `countDownTimer`) e neutralizza `countDownPlayCouponLive`;
  - logga la risposta reale del server (`G` = accettato subito / `Q` = riserva / errore)
    per verificare se il bookmaker si fida del flag o riconosce comunque l'evento come live.
- Nota: è un test. Il server può ignorare il flag e trattare l'evento come live comunque
  (riserva `Q` o rifiuto). Provalo con importi minimi.
- Log risposta più chiaro: `logCouponResponse` distingue ACCETTATO (G/R) / IN RISERVA
  (Q/A/M) / RESPINTO (B/N/D/T) / RIFIUTATO (errorCode senza status, es.
  `evento_LIVE_chiuso`), invece di mostrare `status=undefined`.
- Banner dedicato quando il server risponde `evento_LIVE_chiuso`: segnala che il
  backend NON accetta il travestimento e ferma il cronometro.

### Fix effetti collaterali (importante)
- `killLiveCountdown` **non** sovrascrive più `countDownPlayCouponLive` in modo
  permanente: salva l'originale e lo **ripristina** quando l'esperimento viene spento
  (prima l'override restava attivo anche a toggle off finché non si ricaricava la pagina).
- `forcePrematchObj` ora considera "live" **solo** `1`/`"1"`/`true` (mai `0`/`"0"`/
  undefined), non tocca l'oggetto se il coupon è già pre-match, e **logga i dettagli**
  (id evento + valore) di ogni campo cambiato, così si vede esattamente cosa modifica.

### Esito dell'esperimento (osservato)
Il server risponde `evento_LIVE_chiuso`: **ignora il flag `live=0` del client** e
riconosce l'evento come live dal suo `id_event`. Travestire una live da pre-match non
la fa accettare; il countdown lato client viene comunque azzerato correttamente.

## 1.1.0
- Versione visibile nel pannello + registrata nel log.
- Riepilogo impostazioni ad ogni piazzamento (fire&forget / stampa-auto / stampa-subito).
- Apertura stampa via **service worker** (`chrome.windows.create`) → niente blocco popup.
- Toggle **"Apri stampa subito all'invio (anche in riserva)"**: apre la stampa a ~1s usando
  il `couponId` della risposta `Q`, senza attendere l'accettazione.

## 1.0.0
- Pannello flottante con cronometro, log colorato, export `.txt`.
- Click istantaneo (rimozione countdown/guard `timer_started`), hotkey Spazio.
- Hook `playCouponFast` + bind Pusher per l'accettazione in tempo reale.
- Fire & forget (non attendere la riserva) con tracciamento esito reale.
- Apertura automatica stampa coupon all'accettazione + pulsante manuale.
