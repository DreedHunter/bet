/* BetFast — popup: legge/scrive le impostazioni condivise in chrome.storage.local */
const DEFAULTS = { amount: '1', hotkey: true, fastPoll: 300, poll: false, nowait: false, print: true, liveAsPrematch: false, visible: true, pos: null };
const $ = (id) => document.getElementById(id);

chrome.storage.local.get('betfast', (res) => {
  const s = Object.assign({}, DEFAULTS, (res && res.betfast) || {});
  $('visible').checked = s.visible !== false;
  $('hotkey').checked = !!s.hotkey;
  $('amount').value = s.amount;
  $('poll').checked = !!s.poll;
  $('nowait').checked = !!s.nowait;
  $('print').checked = !!s.print;
  $('liveprematch').checked = !!s.liveAsPrematch;
});

$('save').addEventListener('click', () => {
  chrome.storage.local.get('betfast', (res) => {
    const cur = Object.assign({}, DEFAULTS, (res && res.betfast) || {});
    const next = Object.assign(cur, {
      visible: $('visible').checked,
      hotkey: $('hotkey').checked,
      amount: $('amount').value,
      poll: $('poll').checked,
      nowait: $('nowait').checked,
      print: $('print').checked,
      liveAsPrematch: $('liveprematch').checked
    });
    chrome.storage.local.set({ betfast: next }, () => {
      $('save').textContent = 'Salvato ✓';
      setTimeout(() => ($('save').textContent = 'Salva'), 900);
    });
  });
});
