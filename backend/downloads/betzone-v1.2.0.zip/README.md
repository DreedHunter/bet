# BetFast — estensione Chrome

Velocizza il piazzamento su **betzone365.org** / **mywin365.net** e logga tutto il flusso
(POST → riserva → accettazione via Pusher) con un cronometro.

## Cosa fa
- **Click istantaneo**: rimuove il countdown e il guard `timer_started` del sito.
- **Pulsante ⚡ PIAZZA VELOCE** + **hotkey Spazio** per piazzare senza toccare il mouse.
- **Cronometro**: parte al piazzamento, si ferma all'accettazione (verde) o al rifiuto (rosso).
- **Log colorato** in tempo reale, con export in `.txt`.
- **Poll rapido** (opzionale): accelera la verifica di accettazione per-coupon.

> Nota onesta: l'estensione elimina i ritardi **lato client**. Il tempo di **riserva/accettazione
> del bookmaker** (status `Q`, tipico delle quote alte) è deciso dal server e non è comprimibile.

## Installazione (modalità sviluppatore)
1. Apri Chrome → `chrome://extensions`.
2. Attiva **Modalità sviluppatore** (in alto a destra).
3. **Carica estensione non pacchettizzata** → seleziona la cartella `betfast-extension`.
4. Apri betzone365.org / mywin365.net: comparirà il pannello **BetFast** in alto a destra.

## Uso
- Prepara la giocata su un evento come faresti a mano.
- Imposta l'importo nel pannello e premi **⚡ PIAZZA VELOCE** (o barra **Spazio**).
- Guarda il cronometro e il log per i tempi reali.

## File
- `manifest.json` — configurazione MV3.
- `src/injected.js` — gira nel contesto pagina (MAIN): hook ajax, patch `vm`, bind Pusher.
- `src/content.js` — GUI del pannello + ponte eventi.
- `src/panel.css` — stile del pannello.
- `popup.html` / `popup.js` — impostazioni dalla toolbar.
