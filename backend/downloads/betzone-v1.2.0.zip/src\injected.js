/*
 * BetFast — injected (MAIN world)
 * Gira nel contesto della pagina: ha accesso a window.vm, jQuery ($.ajax),
 * window.channelCoupon (Pusher). Comunica col content script via DOM CustomEvent.
 *
 *  - Hook di $.ajax: cronometra playCouponFast e logga l'esito.
 *  - Patch di vm.clickPlayCouponFast + disattiva il countdown (timer_started).
 *  - Bind aggiuntivo su channelCoupon per l'accettazione via Pusher.
 *  - Ascolta comandi BETFAST_CMD (fastBet, setFastPoll, liveAsPrematch).
 *  - ESPERIMENTO liveAsPrematch: manda le giocate live come pre-match
 *    (riscrive live=0 nel payload) e azzera il countdown live, per vedere
 *    se il server le accetta subito (status G) invece di metterle in riserva (Q).
 */
(() => {
  'use strict';
  if (window.__betFastInjected) return;
  window.__betFastInjected = true;

  const STATUS = {
    G: '✅ accettato', R: '✅ accettato', Q: '⏳ in riserva',
    A: '⏳ in accettazione', M: '⏳ in accettazione',
    B: '⛔ respinta', N: '❌ negata', D: '❌ negata', T: '❌ negata'
  };
  const isOk = (s) => s === 'G' || s === 'R';
  const isKo = (s) => s === 'B' || s === 'N' || s === 'D' || s === 'T';

  let t0 = null; // istante di fire (piazzamento)

  // Esperimento: manda le giocate LIVE come se fossero PRE-MATCH.
  // Riscrive il flag `live` a 0 nel payload prima dell'invio e azzera il
  // countdown live del sito, per osservare se il server accetta subito (G).
  let liveAsPrematch = false;

  // Forza a 0 ogni campo che marca l'evento/riga come live dentro l'oggetto coupon.
  // Copre l'oggetto JS del coupon (events[].live e events[].rows[].live).
  // Considera "live" solo un valore 1/"1"/true. NON tocca 0/"0"/undefined/null.
  function isLiveFlag(v) { return v === 1 || v === '1' || v === true; }

  // Ritorna { n, changes } — n = quanti campi, changes = descrizione per il log,
  // così in fase di test si vede ESATTAMENTE cosa viene toccato (id evento + valore).
  function forcePrematchObj(coupon) {
    const out = { n: 0, changes: [] };
    if (!coupon || typeof coupon !== 'object') return out;
    if (Array.isArray(coupon.events)) {
      coupon.events.forEach(function (ev, i) {
        if (ev && isLiveFlag(ev.live)) {
          out.changes.push('ev[' + i + '] id=' + (ev.id != null ? ev.id : '?') + ' live=' + ev.live + '→0');
          ev.live = 0; out.n++;
        }
        if (ev && Array.isArray(ev.rows)) {
          ev.rows.forEach(function (r, j) {
            if (r && isLiveFlag(r.live)) {
              out.changes.push('ev[' + i + '].row[' + j + '] live=' + r.live + '→0');
              r.live = 0; out.n++;
            }
          });
        }
      });
    }
    return out;
  }

  // Alcuni build serializzano il coupon come stringa (JSON o querystring urlencoded)
  // dentro opts.data. Riscrive live=1 -> live=0 anche in quel caso.
  function forcePrematchString(s) {
    if (typeof s !== 'string') return s;
    // querystring urlencoded: ...[live]=1  oppure  ...%5Blive%5D=1
    let out = s.replace(/(\[live\]|%5Blive%5D)=1\b/g, '$1=0');
    // JSON: "live":1  oppure  "live":"1"  ->  "live":0
    // \b dopo l'1 evita di toccare "live":12 ; niente cattura per non incappare in $10/$11
    out = out.replace(/"live"(\s*:\s*)"?1"?(?=[\s,}\]])/g, function (m) {
      return m.replace(/1/, '0');
    });
    return out;
  }

  // Spegne il countdown live del sito: azzera le variabili e ferma il timer.
  // NON sovrascrive countDownPlayCouponLive in modo permanente (lo faceva prima e
  // restava alterato anche a toggle spento): salva l'originale e lo ripristina.
  let __origCountDownFn = null;
  function killLiveCountdown() {
    try { if (window.countDownHandler) window.clearTimeout(window.countDownHandler); } catch (e) {}
    try { window.liveCountDown = 0; } catch (e) {}
    try { window.countDownTimer = false; } catch (e) {}
    try { if (window.jQuery) window.jQuery('#play_live_coupon_count_down').html(0); } catch (e) {}
    if (__origCountDownFn === null && typeof window.countDownPlayCouponLive === 'function') {
      __origCountDownFn = window.countDownPlayCouponLive;   // memorizza l'originale
    }
    if (typeof window.countDownPlayCouponLive === 'function') {
      window.countDownPlayCouponLive = function () {
        try { window.liveCountDown = 0; window.countDownTimer = false; } catch (e) {}
        try { if (window.jQuery) window.jQuery('#play_live_coupon_count_down').html(0); } catch (e) {}
        // niente setTimeout: nessun conto alla rovescia
      };
    }
  }
  // Ripristina il countdown originale del sito (quando si spegne l'esperimento).
  function restoreLiveCountdown() {
    if (__origCountDownFn) {
      try { window.countDownPlayCouponLive = __origCountDownFn; } catch (e) {}
      __origCountDownFn = null;
    }
  }

  // Interpreta la risposta del server al piazzamento e la logga in modo leggibile.
  // Forme note della risposta:
  //   OK/riserva : { errorCode:"success", result:{ status:"G|Q|A|M", couponId } }
  //   errore     : { errorCode:"error"|"changedOdds", result:{ errorCode:"evento_LIVE_chiuso" | "..." } }
  function logCouponResponse(cb, action) {
    const r = (cb && cb.result) || {};
    const topErr = cb && cb.errorCode;            // "success" | "error" | "changedOdds" | ...
    const status = r.status || null;              // G/R/Q/A/M/... quando presente
    // il dettaglio d'errore sta in result.errorCode (es. "evento_LIVE_chiuso=135940156")
    const detail = (r.errorCode && r.errorCode !== '') ? r.errorCode : (topErr && topErr !== 'success' ? topErr : '');
    const label = action ? action : 'POST';

    let lvl, head;
    if (isOk(status)) { lvl = 'ok'; head = 'ACCETTATO'; }
    else if (status === 'Q' || status === 'A' || status === 'M') { lvl = 'warn'; head = 'IN RISERVA'; }
    else if (isKo(status)) { lvl = 'error'; head = 'RESPINTO'; }
    else if (detail) { lvl = 'error'; head = 'RIFIUTATO'; }   // nessuno status ma c'è un errore
    else { lvl = 'info'; head = 'sconosciuto'; }

    emit(lvl,
      '◀ Risposta ' + label + ': ' + head +
      (status ? ' (status=' + status + ' ' + (STATUS[status] || '') + ')' : '') +
      (detail ? ' — ' + detail : '') +
      (r.couponId ? ' — coupon ' + r.couponId : ''),
      { phase: 'post', status: status, coupon: r.couponId || null, errorCode: detail || null });
  }

  const emit = (level, msg, extra) => {
    document.dispatchEvent(new CustomEvent('BETFAST_LOG', {
      detail: Object.assign({
        level: level,
        msg: msg,
        elapsed: t0 != null ? (performance.now() - t0) : null,
        ts: Date.now()
      }, extra || {})
    }));
  };

  // ---- Hook jQuery.ajax ----
  function hookAjax() {
    if (window.__betFastAjaxHooked) return true;
    if (!window.jQuery || !window.jQuery.ajax) return false;
    const orig = window.jQuery.ajax;
    window.jQuery.ajax = function (opts) {
      const action = opts && opts.data && opts.data.action;
      const isPlay = action === 'playCouponFast';
      // Il piazzamento live passa per action=saveCoupon; anche quello va "smascherato".
      const isCouponPost = isPlay || action === 'saveCoupon' || action === 'playCouponElite';

      // ESPERIMENTO: riscrivi live -> 0 nel payload prima dell'invio.
      if (liveAsPrematch && isCouponPost && opts && opts.data) {
        const details = [];
        let changed = 0;
        if (opts.data.coupon && typeof opts.data.coupon === 'object') {
          const res = forcePrematchObj(opts.data.coupon);
          changed += res.n; details.push.apply(details, res.changes);
        }
        // varianti in cui il coupon è una stringa (JSON o querystring)
        ['coupon', 'data', 'payload'].forEach(function (k) {
          if (typeof opts.data[k] === 'string') {
            const before = opts.data[k];
            opts.data[k] = forcePrematchString(before);
            if (opts.data[k] !== before) { changed++; details.push('stringa opts.data.' + k); }
          }
        });
        if (typeof opts.data === 'string') {
          const before = opts.data;
          opts.data = forcePrematchString(before);
          if (opts.data !== before) { changed++; details.push('stringa opts.data'); }
        }
        killLiveCountdown();
        emit(changed > 0 ? 'warn' : 'sys',
          '🧪 liveAsPrematch (action=' + action + '): ' +
          (changed > 0 ? 'live→0 su ' + changed + ' campo/i [' + details.join(' ; ') + ']'
                       : 'nessun campo live trovato (coupon già pre-match)') +
          ' + countdown azzerato',
          { phase: 'experiment' });
      }

      if (isPlay) {
        t0 = performance.now();
        const amt = opts.data.coupon && opts.data.coupon.amount;
        emit('fire', '▶ Piazzamento inviato' + (amt != null ? ' (importo ' + amt + ')' : ''), { phase: 'fire' });
      } else if (liveAsPrematch && (action === 'saveCoupon' || action === 'playCouponElite')) {
        t0 = performance.now();
        emit('fire', '▶ Piazzamento LIVE inviato (travestito da pre-match)', { phase: 'fire' });
      }
      const jqxhr = orig.apply(this, arguments);
      // saveCoupon non passa dal ramo isPlay: logga comunque la risposta.
      if (!isPlay && liveAsPrematch && (action === 'saveCoupon' || action === 'playCouponElite') && jqxhr && jqxhr.done) {
        jqxhr.done(function (cb) { logCouponResponse(cb, action); }).fail(function () {
          emit('error', '◀ ' + action + ' fallita (rete/server)', { phase: 'post' });
        });
      }
      if (isPlay && jqxhr && jqxhr.done) {
        jqxhr.done(function (cb) { logCouponResponse(cb); }).fail(function () {
          emit('error', '◀ POST fallita (rete/server)', { phase: 'post' });
        });
      }
      return jqxhr;
    };
    window.__betFastAjaxHooked = true;
    emit('sys', 'Hook piazzamento attivo');
    return true;
  }

  // ---- Patch vm: click istantaneo + niente countdown ----
  function patchVm() {
    if (window.__betFastVmPatched) return true;
    if (!window.vm || !window.vm.coupon_option || !window.vm.coupon_fast) return false;
    try {
      window.vm.clickPlayCouponFast = function () {
        if (!(parseFloat(this.coupon_fast.amount) > 0)) {
          emit('warn', 'Importo non valido: nessun piazzamento');
          return;
        }
        this.coupon_option.timer_started = false;
        this.playCouponElite(new Date().toISOString());
      };
      try {
        Object.defineProperty(window.vm.coupon_option, 'timer_started', {
          get() { return false; },
          set() { /* ignora il lock */ },
          configurable: true
        });
      } catch (e) { /* alcuni build non lo permettono */ }
      window.__betFastVmPatched = true;
      emit('sys', 'Click istantaneo + countdown disattivato');
    } catch (e) {
      emit('warn', 'Patch vm non riuscita: ' + e.message);
    }
    return true;
  }

  // ---- Bind Pusher: accettazione in tempo reale ----
  function bindPush() {
    if (window.__betFastPushBound) return true;
    if (!window.channelCoupon || typeof window.channelCoupon.bind !== 'function') return false;
    window.channelCoupon.bind('coupon_processed', function (data) {
      try {
        const m = (data && data.message) ? JSON.parse(data.message) : null;
        if (!m) return;
        const lvl = isOk(m.stato) ? 'ok' : (isKo(m.stato) ? 'error' : 'info');
        emit(lvl, '🔔 Pusher: stato=' + m.stato + ' ' + (STATUS[m.stato] || '') +
          (m.id ? ' — id ' + m.id : ''), { phase: 'push', status: m.stato, coupon: m.id || null });
      } catch (e) { /* ignore */ }
    });
    window.__betFastPushBound = true;
    emit('sys', 'Pusher agganciato (accettazione in tempo reale)');
    return true;
  }

  // ---- Poll accettazione veloce (per-coupon, betzone) ----
  function installFastPoll(ms) {
    const FAST = Math.max(150, ms | 0 || 300);
    window.checkForPendingCouponElite = function cfpe(couponId) {
      window.jQuery.ajax({ url: 'ajax.php', data: { action: 'checkForPendingCoupon', couponId: couponId }, type: 'post', dataType: 'json' })
        .done(function (cb) {
          const st = cb && cb.result && cb.result.result && cb.result.result.status;
          if (st === 'A' || st === 'M') setTimeout(function () { cfpe(couponId); }, FAST);
          else if (isOk(st)) { emit('ok', '✅ Coupon accettato (poll)', { phase: 'poll', status: st }); if (typeof window.updateUserCredit === 'function') window.updateUserCredit(); }
          else if (st === 'S') cfpe(couponId);
          else if (isKo(st)) emit('error', '❌ Coupon rifiutato (poll): ' + st, { phase: 'poll', status: st });
        })
        .fail(function () { setTimeout(function () { cfpe(couponId); }, FAST); });
    };
    emit('sys', 'Poll accettazione accelerato a ' + FAST + ' ms');
  }

  // ---- Comandi dal content script / popup ----
  document.addEventListener('BETFAST_CMD', function (e) {
    const d = e.detail || {};
    if (d.cmd === 'fastBet') {
      if (!window.vm) { emit('warn', 'vm non pronto: prepara la giocata su un evento'); return; }
      if (d.amount != null && d.amount !== '') window.vm.coupon_fast.amount = d.amount;
      window.vm.coupon_option.timer_started = false;
      window.vm.playCouponElite(new Date().toISOString());
    } else if (d.cmd === 'setFastPoll') {
      installFastPoll(d.ms);
    } else if (d.cmd === 'liveAsPrematch') {
      liveAsPrematch = !!d.on;
      if (liveAsPrematch) killLiveCountdown();
      else restoreLiveCountdown();   // spegnendo l'esperimento ripristino il countdown del sito
      emit(liveAsPrematch ? 'warn' : 'sys',
        '🧪 Esperimento "live come pre-match": ' + (liveAsPrematch ? 'ATTIVO' : 'off — countdown del sito ripristinato') +
        (liveAsPrematch ? ' — le live verranno inviate con live=0 e senza countdown' : ''));
    } else if (d.cmd === 'ping') {
      emit('sys', 'BetFast attivo su ' + location.host);
    }
  });

  // ---- Loop di readiness ----
  let tries = 0;
  const iv = setInterval(function () {
    tries++;
    hookAjax(); patchVm(); bindPush();
    if ((window.__betFastAjaxHooked && window.__betFastVmPatched && window.__betFastPushBound) || tries > 200) {
      clearInterval(iv);
    }
  }, 300);

  emit('sys', 'BetFast pronto su ' + location.host);
})();
