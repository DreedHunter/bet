/*
 * BetFast — service worker (background)
 * Apre la finestra di stampa del coupon senza incappare nel blocco popup:
 * chrome.windows.create NON è soggetto al popup blocker come window.open.
 */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'openPrint' && msg.url) {
    chrome.windows.create(
      { url: msg.url, type: 'popup', width: 360, height: 820 },
      (win) => {
        if (chrome.runtime.lastError) {
          // fallback: apri come normale scheda
          chrome.tabs.create({ url: msg.url }, () => sendResponse({ ok: true, mode: 'tab' }));
        } else {
          sendResponse({ ok: true, mode: 'popup', id: win && win.id });
        }
      }
    );
    return true; // risposta asincrona
  }
});
