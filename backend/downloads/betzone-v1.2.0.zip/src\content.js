/*
 * BetFast — content script (ISOLATED world)
 * Costruisce la GUI (pannello flottante) e fa da ponte col MAIN world
 * via DOM CustomEvent (BETFAST_LOG in ingresso, BETFAST_CMD in uscita).
 */
(() => {
  'use strict';
  if (window.__betFastPanel) return;
  window.__betFastPanel = true;

  const DEFAULTS = { amount: '1', hotkey: true, fastPoll: 300, poll: false, nowait: false, print: true, printNow: false, liveAsPrematch: false, visible: true, pos: null };
  let settings = Object.assign({}, DEFAULTS);

  // ---------- Costruzione GUI ----------
  const panel = document.createElement('div');
  panel.id = 'betfast-panel';
  panel.innerHTML = `
    <div id="bf-header">
      <span id="bf-title"><span id="bf-dot"></span> BetFast <span id="bf-ver"></span></span>
      <div id="bf-head-actions">
        <button id="bf-collapse" title="Comprimi">–</button>
      </div>
    </div>
    <div id="bf-body">
      <div id="bf-banner" class="bf-hidden"></div>
      <div id="bf-timer-box">
        <div id="bf-timer">0.000<span class="bf-unit">s</span></div>
        <div id="bf-timer-label">tempo piazzamento</div>
      </div>

      <div id="bf-controls">
        <label class="bf-field">
          <span>Importo €</span>
          <input id="bf-amount" type="number" min="0" step="0.5" value="1" />
        </label>
        <button id="bf-bet">⚡ PIAZZA VELOCE</button>
      </div>

      <button id="bf-print-btn" class="bf-hidden">🖨️ STAMPA COUPON</button>

      <div id="bf-toggles">
        <label class="bf-toggle"><input id="bf-hotkey" type="checkbox" checked /> Hotkey <b>Spazio</b></label>
        <label class="bf-toggle"><input id="bf-poll" type="checkbox" /> Poll rapido</label>
      </div>
      <div id="bf-toggles">
        <label class="bf-toggle bf-wide"><input id="bf-nowait" type="checkbox" /> Non attendere riserva <b>(fire &amp; forget)</b></label>
      </div>
      <div id="bf-toggles">
        <label class="bf-toggle bf-wide"><input id="bf-print" type="checkbox" checked /> Apri <b>stampa</b> automatica all'accettazione</label>
      </div>
      <div id="bf-toggles">
        <label class="bf-toggle bf-wide"><input id="bf-print-now" type="checkbox" /> Apri stampa <b>subito all'invio</b> (anche in riserva)</label>
      </div>
      <div id="bf-toggles">
        <label class="bf-toggle bf-wide bf-exp"><input id="bf-live-prematch" type="checkbox" /> 🧪 <b>Manda LIVE come pre-match</b> (live=0 + no countdown)</label>
      </div>

      <div id="bf-log-head">
        <span>Log</span>
        <div>
          <button id="bf-export" title="Esporta log">⬇</button>
          <button id="bf-clear" title="Pulisci">✕</button>
        </div>
      </div>
      <div id="bf-log"></div>
    </div>
  `;
  document.documentElement.appendChild(panel);

  const $ = (sel) => panel.querySelector(sel);
  const logEl = $('#bf-log');
  const timerEl = $('#bf-timer');

  // Versione (dal manifest) mostrata in header e registrata nel log
  let VERSION = '?';
  try { VERSION = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '?'; } catch (e) {}
  const verEl = $('#bf-ver');
  if (verEl) verEl.textContent = 'v' + VERSION;
  const amountEl = $('#bf-amount');
  const hotkeyEl = $('#bf-hotkey');
  const pollEl = $('#bf-poll');
  const nowaitEl = $('#bf-nowait');
  const printEl = $('#bf-print');
  const printNowEl = $('#bf-print-now');
  const livePrematchEl = $('#bf-live-prematch');
  const printBtn = $('#bf-print-btn');
  const bannerEl = $('#bf-banner');

  // coupon inviati in fire-and-forget di cui attendo l'esito reale in background
  const pending = new Set();
  // coupon per cui ho già stampato in automatico (dedupe post G + push G)
  const printed = new Set();
  // ultimo coupon accettato, pronto per la stampa manuale col pulsante
  let lastCoupon = null;

  function printUrl(num) {
    return location.origin + '/print_coupon_v2.php?coupon=' + encodeURIComponent(num) + '&logo=false&printoriginal=true';
  }

  // Metodo A: pulsante che si illumina; il click è un gesto utente -> niente blocco popup
  function armPrint(id) {
    if (id == null) return;
    lastCoupon = String(id).replace(/^C/i, '');
    printBtn.textContent = '🖨️ STAMPA COUPON ' + lastCoupon;
    printBtn.classList.remove('bf-hidden');
    printBtn.classList.add('bf-ready');
  }

  // Apertura finestra di stampa (chiamata dal click sul pulsante = gesto utente)
  function doPrintWindow(num) {
    if (!num) return;
    const w = window.open(printUrl(num), 'CouponPrint' + num, 'width=340,height=800,scrollbars=yes');
    if (w) { try { w.focus(); } catch (e) {} addLog('sys', 'Apro stampa coupon ' + num); }
    else addLog('warn', 'Popup bloccato: consenti i popup per betzone, oppure usa la stampa automatica.');
  }

  // Metodo B: stampa silenziosa via iframe stesso dominio (nessun popup)
  function autoPrint(id) {
    const num = String(id).replace(/^C/i, '');
    if (!num || printed.has(num)) return;
    printed.add(num);
    const f = document.createElement('iframe');
    f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
    f.src = printUrl(num);
    f.onload = () => {
      try { f.contentWindow.focus(); f.contentWindow.print(); addLog('sys', 'Stampa automatica coupon ' + num); }
      catch (e) { addLog('warn', 'Auto-stampa non riuscita (' + e.message + '), usa il pulsante STAMPA.'); }
      setTimeout(() => f.remove(), 60000);
    };
    document.body.appendChild(f);
  }

  // Apertura AUTOMATICA della finestra di stampa tramite il service worker
  // (chrome.windows.create non è bloccato dal popup blocker come window.open).
  function autoOpenPrint(id) {
    const num = String(id).replace(/^C/i, '');
    if (!num || printed.has(num)) return;
    printed.add(num);
    try {
      chrome.runtime.sendMessage({ type: 'openPrint', url: printUrl(num) }, () => {
        if (chrome.runtime.lastError) {
          addLog('warn', 'Apertura auto fallita (' + chrome.runtime.lastError.message + '). Usa il pulsante STAMPA.');
          printed.delete(num);
        } else {
          addLog('sys', 'Stampa aperta automaticamente: coupon ' + num);
        }
      });
    } catch (e) {
      addLog('warn', 'sendMessage fallita: ' + e.message);
      printed.delete(num);
    }
  }

  // All'accettazione: arma sempre il pulsante e, se attivo, apre la stampa da solo
  function onAccepted(id) {
    if (id == null) return;
    armPrint(id);
    if (printEl.checked) autoOpenPrint(id);
  }

  function showBanner(text, type) {
    bannerEl.textContent = text;
    bannerEl.className = 'bf-banner-' + type;
  }
  function hideBanner() { bannerEl.className = 'bf-hidden'; }

  // ---------- Log ----------
  const logBuffer = [];
  function addLog(level, msg, elapsed) {
    const time = new Date().toLocaleTimeString('it-IT', { hour12: false }) + '.' + String(Date.now() % 1000).padStart(3, '0');
    const el = document.createElement('div');
    el.className = 'bf-line bf-' + (level || 'info');
    const elapsedTxt = (elapsed != null) ? ` <span class="bf-elapsed">(+${elapsed.toFixed(0)}ms)</span>` : '';
    el.innerHTML = `<span class="bf-ts">${time}</span> <span class="bf-msg">${escapeHtml(msg)}</span>${elapsedTxt}`;
    logEl.appendChild(el);
    logEl.scrollTop = logEl.scrollHeight;
    logBuffer.push(`${time}\t${level}\t${msg}${elapsed != null ? `\t+${elapsed.toFixed(0)}ms` : ''}`);
    while (logEl.childNodes.length > 400) logEl.removeChild(logEl.firstChild);
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // ---------- Cronometro live ----------
  let running = false, startPerf = 0, raf = 0;
  function startTimer() {
    running = true; startPerf = performance.now();
    cancelAnimationFrame(raf);
    const tick = () => {
      if (!running) return;
      const s = (performance.now() - startPerf) / 1000;
      timerEl.innerHTML = s.toFixed(3) + '<span class="bf-unit">s</span>';
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    timerEl.classList.add('bf-running');
    timerEl.classList.remove('bf-ok', 'bf-ko');
  }
  function stopTimer(state) {
    running = false;
    cancelAnimationFrame(raf);
    timerEl.classList.remove('bf-running', 'bf-ok', 'bf-ko', 'bf-sent');
    if (state === 'ok') timerEl.classList.add('bf-ok');
    if (state === 'ko') timerEl.classList.add('bf-ko');
    if (state === 'sent') timerEl.classList.add('bf-sent');
  }

  // ---------- Eventi dal MAIN world ----------
  const isOk = (s) => s === 'G' || s === 'R';
  const isKo = (s) => s === 'B' || s === 'N' || s === 'D' || s === 'T';

  document.addEventListener('BETFAST_LOG', (e) => {
    const d = e.detail || {};
    addLog(d.level, d.msg, d.elapsed);

    if (d.phase === 'fire') {
      startTimer(); hideBanner();
      printBtn.classList.add('bf-hidden'); printBtn.classList.remove('bf-ready');
      addLog('sys', 'Impostazioni → fire&forget=' + (nowaitEl.checked ? 'ON' : 'off') +
        ' | stampa-auto(G)=' + (printEl.checked ? 'ON' : 'off') +
        ' | stampa-subito(invio)=' + (printNowEl.checked ? 'ON' : 'off'));
    }

    if (d.phase === 'post') {
      if (isKo(d.status)) {
        stopTimer('ko');
        showBanner('⛔ Piazzamento respinto', 'ko');
      } else if (isOk(d.status)) {
        stopTimer('ok');
        showBanner('✅ Accettato subito', 'ok');
        onAccepted(d.coupon);
      } else if (d.status === 'Q') {
        if (nowaitEl.checked) {
          // FIRE & FORGET: non attendo la riserva, ma traccio l'esito reale
          stopTimer('sent');
          if (d.coupon) pending.add(String(d.coupon));
          showBanner('↪ Inviato (coupon ' + (d.coupon || '?') + ') — attendo esito reale…', 'sent');
          addLog('sys', 'Fire & forget: non attendo la riserva. L\u2019esito reale arriverà via Pusher.');
        }
        // Coupon gia disponibile in riserva: arma il pulsante e, se richiesto, apri subito
        armPrint(d.coupon);
        if (printNowEl.checked && d.coupon) {
          addLog('warn', 'Stampa aperta in RISERVA: il coupon potrebbe non essere ancora accettato.');
          autoOpenPrint(d.coupon);
        }
      } else if (d.errorCode) {
        // Nessuno status ma un errore esplicito (es. evento_LIVE_chiuso): rifiuto immediato.
        stopTimer('ko');
        const isLiveClosed = /LIVE_chiuso|evento_LIVE/i.test(d.errorCode);
        showBanner((isLiveClosed
          ? '⛔ Evento LIVE chiuso/sospeso — il server NON accetta il travestimento'
          : '⛔ Rifiutato: ' + d.errorCode), 'ko');
      }
    }

    if (d.phase === 'push' || d.phase === 'poll') {
      const id = d.coupon != null ? String(d.coupon) : null;
      if (isOk(d.status)) {
        stopTimer('ok');
        if (id && pending.has(id)) { pending.delete(id); showBanner('✅ Coupon ' + id + ' ACCETTATO (esito reale)', 'ok'); }
        else showBanner('✅ Accettato', 'ok');
        onAccepted(id);
      } else if (isKo(d.status)) {
        stopTimer('ko');
        if (id && pending.has(id)) {
          pending.delete(id);
          showBanner('⚠️ ATTENZIONE: coupon ' + id + ' RIFIUTATO dal bookmaker — NON è una giocata valida', 'warn');
          addLog('error', 'La giocata inviata in fire & forget è stata RIFIUTATA lato server: ' + d.status);
        } else {
          showBanner('❌ Rifiutato: ' + d.status, 'ko');
        }
      }
    }
  });

  function sendCmd(detail) {
    document.dispatchEvent(new CustomEvent('BETFAST_CMD', { detail }));
  }

  // ---------- Azioni UI ----------
  $('#bf-bet').addEventListener('click', () => {
    sendCmd({ cmd: 'fastBet', amount: amountEl.value });
  });
  printBtn.addEventListener('click', () => doPrintWindow(lastCoupon));
  $('#bf-clear').addEventListener('click', () => { logEl.innerHTML = ''; logBuffer.length = 0; });
  $('#bf-export').addEventListener('click', () => {
    const blob = new Blob([logBuffer.join('\n')], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'betfast-log-' + new Date().toISOString().replace(/[:.]/g, '-') + '.txt';
    a.click();
    URL.revokeObjectURL(a.href);
  });
  $('#bf-collapse').addEventListener('click', () => {
    panel.classList.toggle('bf-collapsed');
    $('#bf-collapse').textContent = panel.classList.contains('bf-collapsed') ? '+' : '–';
  });

  amountEl.addEventListener('change', () => saveSettings({ amount: amountEl.value }));
  hotkeyEl.addEventListener('change', () => saveSettings({ hotkey: hotkeyEl.checked }));
  nowaitEl.addEventListener('change', () => saveSettings({ nowait: nowaitEl.checked }));
  printEl.addEventListener('change', () => saveSettings({ print: printEl.checked }));
  printNowEl.addEventListener('change', () => saveSettings({ printNow: printNowEl.checked }));
  livePrematchEl.addEventListener('change', () => {
    saveSettings({ liveAsPrematch: livePrematchEl.checked });
    sendCmd({ cmd: 'liveAsPrematch', on: livePrematchEl.checked });
  });
  pollEl.addEventListener('change', () => {
    saveSettings({ poll: pollEl.checked });
    if (pollEl.checked) sendCmd({ cmd: 'setFastPoll', ms: settings.fastPoll });
  });

  // ---------- Hotkey (Spazio) ----------
  window.addEventListener('keydown', (e) => {
    if (!hotkeyEl.checked) return;
    const tag = (document.activeElement && document.activeElement.tagName) || '';
    if (/INPUT|TEXTAREA|SELECT/.test(tag)) return;
    if (e.code === 'Space') {
      e.preventDefault();
      flash($('#bf-bet'));
      sendCmd({ cmd: 'fastBet', amount: amountEl.value });
    }
  });
  function flash(btn) { btn.classList.add('bf-flash'); setTimeout(() => btn.classList.remove('bf-flash'), 180); }

  // ---------- Drag ----------
  (function makeDraggable() {
    const header = $('#bf-header');
    let sx, sy, ox, oy, dragging = false;
    header.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return;
      dragging = true;
      const r = panel.getBoundingClientRect();
      sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top;
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
      e.preventDefault();
    });
    function onMove(e) {
      if (!dragging) return;
      const x = Math.max(0, Math.min(window.innerWidth - 60, ox + e.clientX - sx));
      const y = Math.max(0, Math.min(window.innerHeight - 30, oy + e.clientY - sy));
      panel.style.left = x + 'px';
      panel.style.top = y + 'px';
      panel.style.right = 'auto';
    }
    function onUp() {
      dragging = false;
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      saveSettings({ pos: { left: panel.style.left, top: panel.style.top } });
    }
  })();

  // ---------- Persistenza (chrome.storage) ----------
  function saveSettings(patch) {
    settings = Object.assign(settings, patch);
    try { chrome.storage.local.set({ betfast: settings }); } catch (e) {}
  }
  function applySettings(s) {
    settings = Object.assign({}, DEFAULTS, s || {});
    amountEl.value = settings.amount;
    hotkeyEl.checked = !!settings.hotkey;
    pollEl.checked = !!settings.poll;
    nowaitEl.checked = !!settings.nowait;
    printEl.checked = !!settings.print;
    printNowEl.checked = !!settings.printNow;
    livePrematchEl.checked = !!settings.liveAsPrematch;
    panel.style.display = settings.visible === false ? 'none' : '';
    if (settings.pos && settings.pos.left) {
      panel.style.left = settings.pos.left;
      panel.style.top = settings.pos.top;
      panel.style.right = 'auto';
    }
    if (settings.poll) sendCmd({ cmd: 'setFastPoll', ms: settings.fastPoll });
    if (settings.liveAsPrematch) sendCmd({ cmd: 'liveAsPrematch', on: true });
  }
  try {
    chrome.storage.local.get('betfast', (res) => applySettings(res && res.betfast));
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.betfast) {
        const s = changes.betfast.newValue || {};
        // aggiorna solo visibilità e importo dal popup, senza rompere il resto
        if (typeof s.visible !== 'undefined') panel.style.display = s.visible === false ? 'none' : '';
        if (typeof s.amount !== 'undefined') amountEl.value = s.amount;
        if (typeof s.hotkey !== 'undefined') hotkeyEl.checked = !!s.hotkey;
        if (typeof s.nowait !== 'undefined') nowaitEl.checked = !!s.nowait;
        if (typeof s.print !== 'undefined') printEl.checked = !!s.print;
        settings = Object.assign(settings, s);
      }
    });
  } catch (e) {}

  addLog('sys', 'Pannello BetFast v' + VERSION + ' caricato su ' + location.host, null);
  sendCmd({ cmd: 'ping' });
})();
