# BetNewEra24 Fast Bet (v1.0) — Documentazione

## Cos'è
Estensione Chrome per **BetNewEra24** (betnewera24.live) che punta ad azzerare, nella UI, l'attesa di accettazione del coupon. È un **mock lato UI**, non ancora confermato funzionante.

## Piattaforma tecnica
Frontend **React**, backend su `api.xcodetec.com`. Flusso di piazzamento:
- `POST /api/coupon/play` → il coupon nasce in stato "G" (In Progress) con `acceptance:true`, `played:true`. La bet è già registrata sul server.
- L'app fa **polling ogni 4s** su `GET /api/coupon/check/{id}` finché la risposta ha `acceptance:false` → allora ferma lo spinner e mostra il coupon accettato.

## Velocità di piazzamento LIVE
**~14 secondi** (3-4 cicli di polling da 4s ciascuno). Tempo reale non ancora confermato con uno sniff su giocata reale con credito.

## Come funziona
L'estensione intercetta la prima risposta di `/coupon/check/{id}` e forza `acceptance:false` + `played:true` (più `running:true`). Il gate dell'app React è `acceptance || !played`: con questi valori il polling si ferma e lo spinner sparisce all'istante → 0 secondi di attesa nella UI. Modifica solo i due flag che l'app guarda, lascia il resto della risposta invariato. Intercetta le chiamate `fetch` (l'app usa axios/fetch). Toggle ON/OFF in localStorage.

## Cosa è stato provato / scoperto
- Individuato il flusso `play` → polling `check` ogni 4s e il gate React `acceptance || !played`.
- **Mock non confermato** su giocata reale (serviva credito/login).
- Onestà: mock **lato UI**. Nella risposta vera di `/play` c'è `acceptance:false` → il server deve comunque accettare nei suoi ~14s. Se in quel tempo la quota scade o l'evento matura (gol sui live), rifiuta/rimborsa lo stesso. Il mock nasconde l'attesa, non elimina il betdelay.

## Stato
**In analisi.** Meccanismo plausibile ma non verificato su una giocata reale.

## Come si usa
1. Chrome → `chrome://extensions` → **Modalità sviluppatore** → **Carica estensione non pacchettizzata** → cartella `betnewera24_fast_bet`.
2. Apri betnewera24.live con un account provvisto di credito e prepara una giocata.
3. Piazza: se il mock funziona, lo spinner di accettazione sparisce subito. Controlla sempre lo storico per l'esito reale.
