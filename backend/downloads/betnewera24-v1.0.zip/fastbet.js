(function () {
  "use strict";

  // ─────────────────────────────────────────────────────────────────────────
  // BetNewEra24 Fast Bet v1.0 — MAIN world.
  //
  // COME FUNZIONA IL PIAZZAMENTO SU BETNEWERA24 (backend api.xcodetec.com):
  //   1. POST /api/coupon/play → il coupon nasce in stato "G" (In Progress) con
  //      { acceptance: true, played: true }. La bet è REGISTRATA sul server.
  //   2. L'app React fa POLLING ogni 4s su GET /api/coupon/check/{id} finché la
  //      risposta ha { acceptance: false } → allora ferma lo spinner e mostra il
  //      coupon come accettato. Quei ~14 secondi sono 3-4 cicli di polling.
  //
  // IL MOCK (questa estensione):
  //   Intercetta la PRIMA risposta di /coupon/check/{id} e forza acceptance:false
  //   + played:true, così l'app crede subito che il coupon è accettato → 0 secondi
  //   di attesa nella UI. Il gate reale dell'app è `acceptance || !played`
  //   (verificato nel codice React): con acceptance:false+played:true, il polling
  //   si ferma e lo spinner sparisce all'istante.
  //
  // ⚠️ ONESTÀ: questo è un MOCK LATO UI. Il server continua a validare il coupon
  //   nei suoi ~14 secondi reali (nella risposta vera di /play c'è acceptance:false
  //   → il server DEVE ancora accettare). Se in quel tempo la quota scade o l'evento
  //   matura (gol sui live), il server RIFIUTA/RIMBORSA lo stesso, e lo scopri dopo.
  //   Il mock NASCONDE l'attesa, non elimina il betdelay del server.
  // ─────────────────────────────────────────────────────────────────────────

  const CHECK_RE = /\/api\/coupon\/check\/([A-Za-z0-9]+)/;
  const PLAY_RE  = /\/api\/coupon\/play\b/;

  // stato: attivo/disattivo (persistito in localStorage, default ON)
  const LS_MOCK = "bne24_mock";
  let mockEnabled = true;
  try { mockEnabled = localStorage.getItem(LS_MOCK) !== "0"; } catch (e) {}

  // coupon "in attesa" che abbiamo già velocizzato (per non rifare due volte + telemetria)
  const spedUp = new Set();

  // trasforma un oggetto risposta di /coupon/check per farlo apparire ACCETTATO.
  // Modifica SOLO i due flag che l'app guarda (acceptance/played), lascia il resto.
  function forceAccepted(obj) {
    try {
      if (!obj || !obj.data) return obj;
      const d = obj.data;
      // gate dell'app React: esce dal polling quando (acceptance || !played)
      d.acceptance = false;   // ← ferma lo spinner e il polling
      d.played = true;
      d.running = true;
      // stato leggibile (best-effort: se c'è coupon_state, mostralo "accettato")
      if (d.coupon_state && typeof d.coupon_state === "object") {
        // non conosciamo il letter-code "accettato" preciso; lasciamo lo stato ma
        // togliamo l'attesa. Se serve, l'etichetta si affina dopo un test reale.
      }
      return obj;
    } catch (e) { return obj; }
  }

  const t0Map = new Map();   // couponId → t0 (per misurare i ms risparmiati, telemetria futura)

  // ───────────────────── intercetta FETCH (l'app usa axios/fetch) ─────────────────────
  const _fetch = window.fetch;
  window.fetch = function (input, init) {
    let url = "";
    try { url = typeof input === "string" ? input : (input && input.url) || ""; } catch (e) {}

    // segna l'istante del play (per capire quanto tempo l'app avrebbe atteso)
    try { if (PLAY_RE.test(url)) t0Map.set("last", performance.now()); } catch (e) {}

    const p = _fetch.apply(this, arguments);

    // mock solo su /coupon/check e solo se attivo
    if (!mockEnabled) return p;
    let m = null;
    try { m = url.match(CHECK_RE); } catch (e) {}
    if (!m) return p;

    const couponId = m[1];
    return p.then(async (res) => {
      try {
        // leggiamo il body senza consumarlo per l'app: clone
        const clone = res.clone();
        const data = await clone.json().catch(() => null);
        if (!data || !data.data) return res;
        // se il server ha già accettato, non serve mockare (lascia passare il reale)
        if (data.data.acceptance === false) return res;
        // ALTRIMENTI: forziamo "accettato" → costruiamo una nuova Response
        const faked = forceAccepted(data);
        if (!spedUp.has(couponId)) {
          spedUp.add(couponId);
          const t0 = t0Map.get("last");
          const ms = t0 ? Math.round(performance.now() - t0) : null;
          console.log(`%c[BNE24 FastBet]%c coupon ${couponId} → accettazione MOCKATA (spinner azzerato${ms!=null?`, dopo ${ms}ms dal play`:""})`,
            "color:#fff;background:#0a7d2c;padding:1px 5px;border-radius:3px;font-weight:bold", "color:inherit");
          console.log("   ⚠️ mock lato UI: il server valida comunque, verifica lo storico per l'esito reale");
        }
        const body = JSON.stringify(faked);
        return new Response(body, {
          status: res.status,
          statusText: res.statusText,
          headers: res.headers
        });
      } catch (e) { return res; }
    });
  };

  // ───────────────────── intercetta anche XHR (per sicurezza) ─────────────────────
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this._bne24url = url;
    return _open.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (mockEnabled && this._bne24url && CHECK_RE.test(this._bne24url)) {
        const xhr = this;
        this.addEventListener("readystatechange", function () {
          if (xhr.readyState !== 4) return;
          try {
            const data = JSON.parse(xhr.responseText);
            if (data && data.data && data.data.acceptance !== false) {
              const faked = JSON.stringify(forceAccepted(data));
              // sovrascriviamo responseText/response con getter (come per Goldbet)
              Object.defineProperty(xhr, "responseText", { get: () => faked });
              Object.defineProperty(xhr, "response", { get: () => faked });
            }
          } catch (e) {}
        });
      }
    } catch (e) {}
    return _send.apply(this, arguments);
  };

  // ───────────────────── mini toggle in pagina (ON/OFF) ─────────────────────
  // Un piccolo badge fisso in basso a destra per attivare/disattivare il mock.
  function addToggle() {
    try {
      if (document.getElementById("bne24-fastbet-badge")) return;
      const b = document.createElement("div");
      b.id = "bne24-fastbet-badge";
      b.style.cssText = [
        "position:fixed", "bottom:14px", "right:14px", "z-index:2147483647",
        "font:700 11px -apple-system,Segoe UI,sans-serif", "padding:8px 12px",
        "border-radius:20px", "cursor:pointer", "user-select:none",
        "box-shadow:0 3px 12px rgba(0,0,0,.35)", "transition:.2s"
      ].join(";");
      function paint() {
        b.textContent = mockEnabled ? "⚡ Fast Bet ON" : "Fast Bet OFF";
        b.style.background = mockEnabled ? "#0a7d2c" : "#444";
        b.style.color = "#fff";
      }
      b.addEventListener("click", () => {
        mockEnabled = !mockEnabled;
        try { localStorage.setItem(LS_MOCK, mockEnabled ? "1" : "0"); } catch (e) {}
        paint();
      });
      paint();
      (document.body || document.documentElement).appendChild(b);
    } catch (e) {}
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", addToggle, { once: true });
  } else { addToggle(); }
  // ri-aggiungi se React ripulisce il DOM
  setInterval(addToggle, 3000);

  console.log("%c[BNE24 FastBet v1.0]%c attivo — intercetto /coupon/check per azzerare l'attesa di accettazione",
    "color:#fff;background:#0a7d2c;padding:1px 5px;border-radius:3px;font-weight:bold", "color:inherit");
})();
