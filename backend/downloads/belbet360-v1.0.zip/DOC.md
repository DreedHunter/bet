# BelBet360 Fast Bet (v1.0) — Documentazione

## Cos'è
Estensione Chrome per **BelBet360** (belbet360.org) che punta ad azzerare, nella UI, l'attesa di approvazione del coupon. È un **mock lato UI**, non ancora confermato funzionante.

## Piattaforma tecnica
Backend **PHP + jQuery**, chiamate form-encoded verso `ajax.php` (header `X-Requested-With`). Dopo il piazzamento l'app fa **polling** su `POST ajax.php` con body `action=checkForCouponApproval` finché il coupon non è approvato. In attesa la risposta è `no_coupon_approval` / `result:false`. Dal `getBetInfo` del sito: `bet_timeout_live=10`, `bet_timeout=120` → attesa live ~10s (il betdelay), prematch fino a 120s.

## Velocità di piazzamento LIVE
Attesa dichiarata **~10 secondi** sul live (`bet_timeout_live=10`); fino a ~120s sul prematch. Tempo reale sul campo non ancora misurato con uno sniff completo (serviva un account con credito e login).

## Come funziona
L'estensione intercetta la risposta di `checkForCouponApproval`: quando è in attesa (`no_coupon_approval`), la **trasforma in stato approvato** (`coupon_approved`, `result:true`, `approved:true`). L'app crede subito che il coupon sia approvato e ferma spinner e polling → 0 secondi nella UI. L'`action` è riconosciuta dal body form-encoded della chiamata, non dall'URL. Toggle ON/OFF persistito in localStorage.

## Cosa è stato provato / scoperto
- Individuato il polling `checkForCouponApproval` e la forma della risposta "in attesa".
- **Mock non confermato**: la risposta reale nel caso "approvato" non è ancora stata catturata (serviva credito/login), quindi `forceApproved()` ricostruisce la forma più probabile. Se al primo test lo spinner non sparisce, va catturata la risposta reale e affinata la funzione.
- Onestà: mock **lato UI**. Il server valida comunque nei suoi ~10s reali; se in quel tempo la quota si muove o l'evento matura (gol), rifiuta/rimborsa lo stesso. Il mock nasconde l'attesa, non elimina il betdelay.

## Stato
**In analisi.** Meccanismo plausibile ma non verificato su una giocata reale.

## Come si usa
1. Chrome → `chrome://extensions` → **Modalità sviluppatore** → **Carica estensione non pacchettizzata** → cartella `belbet360_fast_bet`.
2. Apri belbet360.org con un account provvisto di credito e prepara una giocata.
3. Piazza: se il mock funziona, lo spinner di approvazione sparisce subito. Controlla sempre lo storico per l'esito reale.
