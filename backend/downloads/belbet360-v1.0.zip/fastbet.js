(function () {
  "use strict";

  // ─────────────────────────────────────────────────────────────────────────
  // BelBet360 Fast Bet v1.0 — MAIN world.
  //
  // COME FUNZIONA IL PIAZZAMENTO SU BELBET360 (belbet360.org, backend PHP):
  //   Sistema jQuery + PHP (ajax.php), chiamate form-encoded (X-Requested-With).
  //   Dopo aver piazzato, l'app fa POLLING su:
  //       POST ajax.php  con body  action=checkForCouponApproval
  //   finché il coupon non viene APPROVATO. Durante l'attesa la risposta è:
  //       { "errorCode":"success", "result":{ "errorCode":"no_coupon_approval",
  //                                            "result":false } }
  //   Dal getBetInfo del sito: bet_timeout_live=10, bet_timeout=120 → l'attesa live
  //   è ~10 secondi (il betdelay di BelBet360), prematch fino a 120s.
  //
  // IL MOCK (questa estensione):
  //   Intercetta la risposta di checkForCouponApproval e, quando è "no_coupon_approval"
  //   (in attesa), la trasforma in uno stato APPROVATO → l'app crede subito che il
  //   coupon sia approvato e ferma il polling/spinner. 0 secondi nella UI.
  //
  // ⚠️ ONESTÀ: mock LATO UI. Il server valida comunque nei suoi ~10s reali
  //   (bet_timeout_live). Se in quel tempo la quota si muove o l'evento matura (gol),
  //   il server RIFIUTA/RIMBORSA lo stesso, e lo scopri dopo. Il mock NASCONDE
  //   l'attesa, non elimina il betdelay del server. Controlla sempre lo storico.
  //
  // ⚙️ DA RITOCCARE dopo il primo test reale: non ho ancora catturato la risposta
  //   di checkForCouponApproval nel caso APPROVATO (serviva credito). Ho ricostruito
  //   la forma più probabile (result:true / approved). Se al primo test lo spinner
  //   non sparisce, cattura la risposta "approvato" reale e si affina forceApproved().
  // ─────────────────────────────────────────────────────────────────────────

  const LS_MOCK = "bb360_mock";
  let mockEnabled = true;
  try { mockEnabled = localStorage.getItem(LS_MOCK) !== "0"; } catch (e) {}

  const t0Map = new Map();   // per misurare i ms risparmiati (telemetria)
  let approvedCount = 0;

  // riconosce la chiamata di attesa approvazione. L'action è nel BODY (form-encoded),
  // non nell'URL, quindi la rileviamo dal body inviato in send().
  function isApprovalBody(body) {
    try {
      const s = (body == null ? "" : String(body));
      return /(^|&)action=checkForCouponApproval(&|$)/.test(s);
    } catch (e) { return false; }
  }

  // trasforma la risposta "in attesa" in "APPROVATO".
  // Struttura di partenza (in attesa): {errorCode:"success", result:{errorCode:"no_coupon_approval", result:false}}
  // La trasformiamo in un esito positivo: result diventa true e togliamo il flag
  // "no_coupon_approval". Best-effort: se la risposta reale dell'approvato ha campi
  // aggiuntivi (es. couponId, stato), si aggiungono qui dopo il primo test.
  function forceApproved(obj) {
    try {
      if (!obj || typeof obj !== "object") return obj;
      const r = obj.result;
      if (r && typeof r === "object" && r.errorCode === "no_coupon_approval") {
        // era in attesa → forziamo approvato
        r.errorCode = "coupon_approved";
        r.result = true;
        r.approved = true;
        approvedCount++;
        const t0 = t0Map.get("last");
        const ms = t0 ? Math.round(performance.now() - t0) : null;
        console.log(`%c[BB360 FastBet]%c coupon APPROVATO (mock) — attesa azzerata${ms!=null?` (dopo ${ms}ms)`:""}`,
          "color:#fff;background:#0a7d2c;padding:1px 5px;border-radius:3px;font-weight:bold", "color:inherit");
        console.log("   ⚠️ mock lato UI: il server valida comunque (bet_timeout_live=10s). Verifica lo storico per l'esito reale.");
      }
      return obj;
    } catch (e) { return obj; }
  }

  // ───────────────────── intercetta XHR (jQuery $.ajax usa XHR) ─────────────────────
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    this._bb360url = url || "";
    return _open.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function (body) {
    try {
      // l'endpoint di attesa è ajax.php con action=checkForCouponApproval nel body
      const isApproval = this._bb360url && /ajax\.php/i.test(this._bb360url) && isApprovalBody(body);
      // segna anche l'ultimo play (per la telemetria dei ms): euristica su action di gioco
      try {
        const s = (body == null ? "" : String(body));
        if (/action=(play|insertCoupon|placeCoupon|makeCoupon|bet)/i.test(s)) t0Map.set("last", performance.now());
      } catch (e) {}

      if (mockEnabled && isApproval) {
        const xhr = this;
        this.addEventListener("readystatechange", function () {
          if (xhr.readyState !== 4) return;
          try {
            const data = JSON.parse(xhr.responseText);
            // mocka SOLO se è ancora in attesa (no_coupon_approval)
            const faked = forceApproved(data);
            const s = JSON.stringify(faked);
            // sovrascriviamo responseText/response con getter (come per Goldbet)
            Object.defineProperty(xhr, "responseText", { get: () => s });
            Object.defineProperty(xhr, "response", { get: () => s });
          } catch (e) {}
        });
      }
    } catch (e) {}
    return _send.apply(this, arguments);
  };

  // ───────────────────── intercetta anche FETCH (per sicurezza) ─────────────────────
  const _fetch = window.fetch;
  if (typeof _fetch === "function") {
    window.fetch = function (input, init) {
      let url = "";
      try { url = typeof input === "string" ? input : (input && input.url) || ""; } catch (e) {}
      const bodyStr = (init && init.body) ? String(init.body) : "";
      const p = _fetch.apply(this, arguments);
      if (!mockEnabled) return p;
      if (!/ajax\.php/i.test(url) || !isApprovalBody(bodyStr)) return p;
      return p.then(async (res) => {
        try {
          const data = await res.clone().json().catch(() => null);
          if (!data) return res;
          const faked = forceApproved(data);
          return new Response(JSON.stringify(faked), {
            status: res.status, statusText: res.statusText, headers: res.headers
          });
        } catch (e) { return res; }
      });
    };
  }

  // ───────────────────── toggle ON/OFF in pagina ─────────────────────
  function addToggle() {
    try {
      if (document.getElementById("bb360-fastbet-badge")) return;
      const b = document.createElement("div");
      b.id = "bb360-fastbet-badge";
      b.style.cssText = [
        "position:fixed", "bottom:14px", "right:14px", "z-index:2147483647",
        "font:700 11px -apple-system,Segoe UI,sans-serif", "padding:8px 12px",
        "border-radius:20px", "cursor:pointer", "user-select:none",
        "box-shadow:0 3px 12px rgba(0,0,0,.35)", "transition:.2s"
      ].join(";");
      function paint() {
        b.textContent = mockEnabled ? "⚡ Fast Bet ON" : "Fast Bet OFF";
        b.style.background = mockEnabled ? "#0a7d2c" : "#444";
        b.style.color = "#fff";
      }
      b.addEventListener("click", () => {
        mockEnabled = !mockEnabled;
        try { localStorage.setItem(LS_MOCK, mockEnabled ? "1" : "0"); } catch (e) {}
        paint();
      });
      paint();
      (document.body || document.documentElement).appendChild(b);
    } catch (e) {}
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", addToggle, { once: true });
  } else { addToggle(); }
  setInterval(addToggle, 3000);

  console.log("%c[BB360 FastBet v1.0]%c attivo — intercetto checkForCouponApproval per azzerare l'attesa di approvazione",
    "color:#fff;background:#0a7d2c;padding:1px 5px;border-radius:3px;font-weight:bold", "color:inherit");
})();
