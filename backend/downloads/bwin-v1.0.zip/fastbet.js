(function () {
  "use strict";

  // ═══════════════════════════════════════════════════════════════════════════
  // Bwin Fast Bet v1.0 — MAIN world. MODALITÀ AUTO-CLICK DOM.
  //
  // SCOPO: piazzare in un gesto su Bwin (piattaforma Entain, frontend Angular).
  //   - CLICK su una quota → aggiunge al carrello, scrive il tuo importo, clicca
  //     "Piazza scommessa" da solo.
  //   - HOTKEY Casa/Ospite → nel mercato aperto della partita, Casa = 1ª quota,
  //     Ospite = ultima quota (Bwin mostra i nomi squadra/1-X-2, non "Casa/Ospite").
  //
  // PERCHÉ AUTO-CLICK: il piazzamento Bwin (POST placebet/place → ~4s →
  //   querystatus) è "pending" fino al querystatus (risk Entain), NON mockabile.
  //   Costruire il place a mano è fragile (payload firmato con 'sign'). Simulando
  //   i click reali è il SITO a costruire il payload corretto.
  //
  // ⚠️ Parte una GIOCATA VERA. L'attesa ~4s dopo il "Piazza scommessa" è del server
  //   (risk Entain), NON riducibile. Qui velocizziamo i TUOI gesti.
  // ═══════════════════════════════════════════════════════════════════════════

  const LS_STAKE      = "bwfb_stake";
  const LS_ENABLED    = "bwfb_enabled";
  const LS_KEY_CASA   = "bwfb_key_casa";
  const LS_KEY_OSPITE = "bwfb_key_ospite";

  let stake   = 2.0;
  let enabled = true;
  let running = false;
  let keyCasa = null, keyOspite = null, recKey = null;

  try { const s = parseFloat(localStorage.getItem(LS_STAKE)); if (s > 0) stake = s; } catch (e) {}
  try { enabled = localStorage.getItem(LS_ENABLED) !== "0"; } catch (e) {}
  try { keyCasa = localStorage.getItem(LS_KEY_CASA) || null; } catch (e) {}
  try { keyOspite = localStorage.getItem(LS_KEY_OSPITE) || null; } catch (e) {}

  // ───────────────────── utility ─────────────────────
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  function waitFor(fn, timeout = 3000, step = 40) {
    return new Promise((resolve) => {
      const t0 = performance.now();
      const check = () => {
        let el = null; try { el = fn(); } catch (e) {}
        if (el) return resolve(el);
        if (performance.now() - t0 > timeout) return resolve(null);
        setTimeout(check, step);
      };
      check();
    });
  }

  // click reale (mousedown→mouseup→click): Angular ignora un click() sintetico.
  function realClick(el) {
    if (!el) return false;
    try {
      const r = el.getBoundingClientRect();
      const opts = { bubbles: true, cancelable: true, view: window,
                     clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
      el.dispatchEvent(new MouseEvent("mousedown", opts));
      el.dispatchEvent(new MouseEvent("mouseup", opts));
      el.dispatchEvent(new MouseEvent("click", opts));
      return true;
    } catch (e) { try { el.click(); return true; } catch (e2) { return false; } }
  }

  // scrive in un input Angular col NATIVE value setter (altrimenti il modello interno
  // resta vuoto e il "Piazza scommessa" usa importo 0/vecchio).
  function setAngularInput(el, value) {
    try {
      const proto = Object.getPrototypeOf(el);
      const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value") &&
                           Object.getOwnPropertyDescriptor(proto, "value").set;
      if (nativeSetter) nativeSetter.call(el, value); else el.value = value;
      el.dispatchEvent(new Event("input",  { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }));
    } catch (e) {
      try { el.value = value; el.dispatchEvent(new Event("input", { bubbles: true })); } catch (e2) {}
    }
  }

  // ───────────────────── selettori Bwin ─────────────────────
  // quota cliccabile: .option-pick (contiene .name = esito, .value.option-value = quota).
  // il click va sull'.option-indicator interno (dove Bwin registra il tap).
  function quotaFromTarget(el) {
    if (!el || !el.closest) return null;
    return el.closest(".option-pick") || null;
  }
  function clickTargetOfQuota(q) {
    return q.querySelector(".option-indicator") || q;
  }
  function quotaLabel(q) {
    try {
      const n = q.querySelector(".name"); const v = q.querySelector(".value, .option-value");
      return ((n && n.textContent) || "quota").trim() + (v ? " @" + v.textContent.trim() : "");
    } catch (e) { return "quota"; }
  }

  // campo importo del carrello (schedina)
  function findStakeInput() {
    const sels = [
      "input.stake-input-value",
      "input[msvalidatestakeinput]",
      '.stake-container input[type="text"]',
      '.betslip input[placeholder="Puntata"]',
      'input[placeholder="Puntata"]'
    ];
    for (const s of sels) {
      const list = document.querySelectorAll(s);
      for (const el of list) if (el && el.offsetParent !== null) return el;
      if (list.length) return list[0];
    }
    return null;
  }
  // pulsante "Piazza scommessa"
  function findPlaceButton() {
    let b = document.querySelector("button.place-button, .betslip-place-button button, button.ds-btn-filled-success");
    if (b) return b;
    const btns = document.querySelectorAll("button");
    for (const x of btns) {
      const t = (x.textContent || "").trim().toLowerCase();
      if (t.includes("piazza scommessa") || t.startsWith("piazza")) return x;
    }
    return null;
  }
  function betslipHasPick() {
    return document.querySelectorAll(".betslip .single-bet-pick, .betslip-digital-bet-pick, bs-single-bet-linear").length > 0
        || !!findStakeInput();
  }

  // ───────────────────── sequenza auto-play (dopo che la quota è nel carrello) ─────
  async function autoPlay(label) {
    if (running) return;
    running = true;
    const printable = stake.toFixed(2).replace(".", ",");
    try {
      toast(`▶ Aggiungo «${label}»…`, "info", 8000);
      // 1) aspetta che la schedina si popoli e compaia il campo importo
      let stakeEl = await waitFor(() => (betslipHasPick() ? findStakeInput() : null), 5000);
      if (!stakeEl) {
        toast("Schedina non pronta (campo importo non trovato). Guarda la console (F12).", "warn", 8000);
        console.warn("[Bwin FastBet] no stake input. betslip picks:",
          document.querySelectorAll(".betslip-digital-bet-pick, bs-single-bet-linear").length,
          "candidati:", document.querySelectorAll("input.stake-input-value, input[placeholder=Puntata]"));
        return;
      }
      // 2) scrivi l'importo
      await sleep(80);
      realClick(stakeEl); await sleep(40);
      setAngularInput(stakeEl, printable);
      await sleep(150);
      if ((stakeEl.value || "").replace(".", ",") !== printable) { setAngularInput(stakeEl, printable); await sleep(120); }
      // 3) clicca "Piazza scommessa"
      const btn = await waitFor(() => {
        const b = findPlaceButton();
        if (b && (b.disabled || b.classList.contains("disabled") || b.getAttribute("aria-disabled") === "true")) return null;
        return b;
      }, 2500);
      if (!btn) { toast("Pulsante «Piazza scommessa» non attivo. Importo inserito: premi tu.", "warn", 7000); return; }
      toast(`▶ Piazzo ${printable}€ su «${label}»…`, "info", 12000);
      realClick(btn);
      toast(`Inviata — attesa server (~4s). Controlla la conferma sul sito.`, "ok", 9000);
    } catch (e) {
      toast("Errore durante la giocata rapida.", "warn", 5000);
    } finally {
      setTimeout(() => { running = false; }, 900);
    }
  }

  // ───────────────────── hotkey: Casa=1ª, Ospite=ultima nel mercato aperto ─────────
  // trova il mercato VISIBILE con opzioni e prende la prima/ultima quota giocabile.
  function firstVisibleMarketPicks() {
    const groups = document.querySelectorAll(".option-group-container, .option-panel, ms-option-group");
    for (const g of groups) {
      if (g.offsetParent === null) continue;   // solo visibili
      const picks = [...g.querySelectorAll(".option-pick")].filter(p => {
        // scarta le opzioni bloccate/nascoste
        if (p.offsetParent === null) return false;
        if (p.closest(".option-hidden") || p.closest(".lock") || p.querySelector(".option-group-lock-icon")) return false;
        return true;
      });
      if (picks.length >= 2) return picks;
    }
    // fallback: tutte le option-pick visibili in pagina
    const all = [...document.querySelectorAll(".option-pick")].filter(p => p.offsetParent !== null);
    return all.length >= 2 ? all : null;
  }
  function playSide(which) {   // "casa" | "ospite"
    if (running) return;
    const picks = firstVisibleMarketPicks();
    if (!picks) { toast(`Nessun mercato con quote visibile. Apri un mercato della partita.`, "warn", 5000); return; }
    const q = which === "casa" ? picks[0] : picks[picks.length - 1];
    const label = quotaLabel(q);
    realClick(clickTargetOfQuota(q));   // aggiunge al carrello
    autoPlay(label);
  }

  // ───────────────────── CLICK su quota = auto-play ─────────────────────
  // NON blocchiamo il click nativo (deve aggiungere la quota al carrello). Partiamo
  // in parallelo con autoPlay che aspetta la schedina.
  document.addEventListener("click", function (e) {
    if (!enabled || recKey) return;
    if (e.target && e.target.closest && e.target.closest("#bwfb-panel")) return;
    const q = quotaFromTarget(e.target);
    if (!q) return;
    autoPlay(quotaLabel(q));
  }, false);

  // ───────────────────── hotkey listener ─────────────────────
  document.addEventListener("keydown", function (e) {
    if (recKey) {
      e.preventDefault();
      const which = recKey;
      if (which === "casa")   { keyCasa = e.key;   try { localStorage.setItem(LS_KEY_CASA, keyCasa); } catch (er) {} }
      if (which === "ospite") { keyOspite = e.key; try { localStorage.setItem(LS_KEY_OSPITE, keyOspite); } catch (er) {} }
      recKey = null; paintPanel();
      toast(`Tasto ${which === "casa" ? "CASA" : "OSPITE"} registrato`, "ok", 2500);
      return;
    }
    if (!enabled) return;
    const tag = (e.target && e.target.tagName) || "";
    if (tag === "INPUT" || tag === "TEXTAREA" || (e.target && e.target.isContentEditable)) return;
    if (keyCasa && e.key === keyCasa)          { e.preventDefault(); playSide("casa"); }
    else if (keyOspite && e.key === keyOspite) { e.preventDefault(); playSide("ospite"); }
  }, true);

  // ───────────────────── PANNELLO (nero/oro) ─────────────────────
  const T = { accent: "#d4af37", bg: "#0b0b0d", box: "#16161a", border: "#2a2a30", ok: "#1a9e5f" };

  function ensurePanel() {
    if (document.getElementById("bwfb-panel")) return;
    const style = document.createElement("style");
    style.textContent = `
      #bwfb-panel{position:fixed;right:16px;bottom:16px;z-index:2147483647;width:236px;
        font:13px/1.4 -apple-system,Segoe UI,sans-serif;color:#fff;background:${T.bg};
        border:1px solid ${T.border};border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.55);overflow:hidden}
      #bwfb-panel .hd{display:flex;align-items:center;justify-content:space-between;padding:11px 13px;
        background:linear-gradient(135deg,#000 0%,#1a1a1e 55%,${T.accent} 160%);color:${T.accent};
        font-weight:800;border-bottom:1px solid ${T.accent}55}
      #bwfb-panel .hd small{opacity:.85;font-weight:600;color:${T.accent}}
      #bwfb-panel .bd{padding:12px 13px;display:flex;flex-direction:column;gap:10px}
      #bwfb-panel .row{display:flex;align-items:center;justify-content:space-between;gap:8px;
        background:${T.box};border:1px solid ${T.border};border-radius:9px;padding:9px 11px}
      #bwfb-panel .lbl{font-weight:700}
      #bwfb-panel input#bwfb-stake{width:88px;padding:7px 9px;border-radius:7px;border:1px solid ${T.border};
        background:${T.bg};color:${T.accent};font-weight:800;text-align:right;font-size:15px}
      #bwfb-panel .sw{position:relative;width:44px;height:24px;border-radius:24px;background:#444;cursor:pointer;transition:.2s;flex:none}
      #bwfb-panel .sw.on{background:${T.ok}}
      #bwfb-panel .sw::after{content:"";position:absolute;top:2px;left:2px;width:20px;height:20px;border-radius:50%;background:#fff;transition:.2s}
      #bwfb-panel .sw.on::after{left:22px}
      #bwfb-panel .keyrow .kl{font-weight:700;flex:1}
      #bwfb-panel .keybtn{cursor:pointer;border:1px solid ${T.border};background:${T.box};color:#fff;
        border-radius:8px;padding:6px 10px;font-weight:800;font-size:12px;min-width:74px;text-align:center}
      #bwfb-panel .keybtn:hover{border-color:${T.accent}}
      #bwfb-panel .keybtn.rec{background:${T.accent};border-color:${T.accent};color:#000}
      #bwfb-panel .hint{font-size:11.5px;opacity:.82;text-align:center;line-height:1.35}
      #bwfb-panel .hint b{color:${T.accent}}
      #bwfb-toast{position:fixed;right:16px;bottom:230px;z-index:2147483647;max-width:290px;
        font:13px/1.4 -apple-system,Segoe UI,sans-serif;color:#fff;padding:11px 14px;border-radius:10px;
        box-shadow:0 6px 20px rgba(0,0,0,.5);display:none;font-weight:600}
    `;
    document.head.appendChild(style);

    const p = document.createElement("div");
    p.id = "bwfb-panel";
    p.innerHTML = `
      <div class="hd"><span>⚡ Bwin Fast Bet</span><small>v1.0</small></div>
      <div class="bd">
        <div class="row"><span class="lbl">Fast Bet</span><div class="sw" id="bwfb-sw"></div></div>
        <div class="row"><span class="lbl">Importo (€)</span><input type="number" id="bwfb-stake" min="0.05" step="0.05"></div>
        <div class="row keyrow"><span class="kl">🏠 Casa</span><div class="keybtn" id="bwfb-keycasa">registra</div></div>
        <div class="row keyrow"><span class="kl">✈️ Ospite</span><div class="keybtn" id="bwfb-keyosp">registra</div></div>
        <div class="hint" id="bwfb-hint"></div>
      </div>`;
    (document.body || document.documentElement).appendChild(p);

    const stakeInput = p.querySelector("#bwfb-stake");
    stakeInput.value = stake;
    stakeInput.addEventListener("input", () => {
      const v = parseFloat(stakeInput.value);
      if (v > 0) { stake = v; try { localStorage.setItem(LS_STAKE, String(v)); } catch (e) {} paintPanel(); }
    });
    p.querySelector("#bwfb-sw").addEventListener("click", () => {
      enabled = !enabled; try { localStorage.setItem(LS_ENABLED, enabled ? "1" : "0"); } catch (er) {}
      paintPanel();
    });
    p.querySelector("#bwfb-keycasa").addEventListener("click", () => { recKey = "casa"; paintPanel(); toast("Premi un tasto per CASA…", "info", 4000); });
    p.querySelector("#bwfb-keyosp").addEventListener("click", () => { recKey = "ospite"; paintPanel(); toast("Premi un tasto per OSPITE…", "info", 4000); });
    paintPanel();
  }

  function paintPanel() {
    const p = document.getElementById("bwfb-panel");
    if (!p) return;
    const sw = p.querySelector("#bwfb-sw"); if (sw) sw.classList.toggle("on", enabled);
    const kc = p.querySelector("#bwfb-keycasa");
    if (kc) { kc.textContent = recKey === "casa" ? "premi…" : keyLabel(keyCasa); kc.classList.toggle("rec", recKey === "casa"); }
    const ko = p.querySelector("#bwfb-keyosp");
    if (ko) { ko.textContent = recKey === "ospite" ? "premi…" : keyLabel(keyOspite); ko.classList.toggle("rec", recKey === "ospite"); }
    const hint = p.querySelector("#bwfb-hint");
    if (hint) hint.innerHTML = `<b>Clicca una quota</b> o premi Casa/Ospite<br>per giocare ${stake.toFixed(2).replace(".", ",")}€ (Casa=1ª, Ospite=ultima).`;
  }

  function keyLabel(k) {
    if (!k) return "(nessuno)";
    if (k === " ") return "Spazio";
    if (k === "ArrowUp") return "↑"; if (k === "ArrowDown") return "↓";
    if (k === "ArrowLeft") return "←"; if (k === "ArrowRight") return "→";
    return k.length === 1 ? k.toUpperCase() : k;
  }

  // ───────────────────── toast ─────────────────────
  let toastTimer = null;
  function toast(msg, kind, ms) {
    try {
      let t = document.getElementById("bwfb-toast");
      if (!t) { t = document.createElement("div"); t.id = "bwfb-toast"; (document.body||document.documentElement).appendChild(t); }
      const col = kind === "ok" ? "#0a7d2c" : kind === "warn" ? "#c0182b" : kind === "info" ? "#1a1a1e" : "#333";
      t.style.background = col; t.style.border = kind === "info" ? "1px solid #d4af37" : "none";
      t.style.display = "block"; t.innerHTML = msg;
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => { t.style.display = "none"; }, ms || 3500);
    } catch (e) {}
  }

  function boot() { ensurePanel(); setInterval(ensurePanel, 3000); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, { once: true });
  else boot();

  console.log("%c[Bwin FastBet v1.0]%c click su una quota o hotkey Casa/Ospite per giocare col tuo importo",
    "color:#000;background:#d4af37;padding:1px 6px;border-radius:3px;font-weight:bold", "color:inherit");
})();
