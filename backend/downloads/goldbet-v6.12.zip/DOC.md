# Goldbet Fast Bet (v6.x) — Documentazione

## Cos'è
Versione **singola** dell'estensione Fast Bet dedicata al solo **Goldbet**. È il precursore dell'estensione unificata "Lottomatica Group": stessa tecnica di piazzamento, ma limitata a un unico bookmaker. La cartella `goldbet_fast_bet_v6.4` è anche la copia usata come backup/base di release (manifest v6.12).

## Piattaforma tecnica
GAD / piattaforma Lottomatica in **Angular**, endpoint `/api/sport/...`. Endpoint chiave del piazzamento:
- `POST /api/sport/book/insertBet` — registra la scommessa e restituisce già il `couponCode`.
- `pendingBet` — passo di conferma successivo, in realtà solo polling estetico.
- `GET /api/sport/live/getDetailsEventLive/1/<evtId>` — quota fresca per il retry su quota scaduta.

## Velocità di piazzamento LIVE
**~2,4 secondi** (dai ~7,4s originali del sito, circa -67%). Circa 1230 ms di `insertBet` sono server-side e non riducibili.

## Come funziona
`insertBet` restituisce già il `couponCode` alla prima chiamata: la scommessa è di fatto registrata subito. Il passo `pendingBet` era solo un polling estetico. L'estensione intercetta `pendingBet` e **mocka la conferma** (`statusCode:"P"`), tagliando l'attesa fittizia. Include gate di licenza, GUI a overlay (Shadow DOM), telemetria tab e scommesse verso il backend, hotkey e vincolo sull'account Goldbet autorizzato.

## Cosa è stato provato / scoperto
- L'attesa di ~5s dopo l'insertBet era **polling finto**: il `couponCode` era già pronto, `pendingBet` solo estetico → mock → **funziona**, tempo ~2,4s.
- Il `couponCode` NON è generabile lato client (contiene un contatore globale di tutte le bet, range 120M).
- Retry automatico su **errore 41** (quota scaduta): recupera la quota fresca da `getDetailsEventLive` e ripiazza.
- Vincolo account: il plugin si apre solo se lo username Goldbet loggato è nella lista autorizzata della licenza.

## Stato
**Funzionante.** Superato in produzione dall'estensione unificata `lottomatica_group_fast_bet` (che aggiunge multibook, guardia anti-storno e re-login), ma la tecnica base è identica e valida.

## Come si usa
1. Chrome → `chrome://extensions` → **Modalità sviluppatore** → **Carica estensione non pacchettizzata** → cartella `goldbet_fast_bet_v6.4`.
2. Login su goldbet.it.
3. Login con la licenza nell'overlay dell'estensione (email + password backend). Il plugin si attiva se licenza attiva e username autorizzato.
4. Prepara e piazza la giocata normalmente; la conferma arriva istantanea.
