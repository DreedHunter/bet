(function () {
  "use strict";

  // Eurobet Fast Bet v1.0 — MAIN world, GUI overlay (Shadow DOM)
  //
  // ARCHITETTURA EUROBET (dalle catture reali):
  //   POST https://www.eurobet.it/sport-sale-service/internal-services/bet
  //   → UNA chiamata bloccante. Sulla SINGOLA LIVE dura ~12s (delay statale ADM),
  //     poi ritorna l'esito con "idAams" (ticket) e "code":1 = accettata.
  //   Sulla MULTIPLA di più eventi il delay sparisce (come William Hill).
  //   Payload chiave: bet.betDataList[].live (true/false), bet.timestampClient.
  //
  // Il mock NON serve (la conferma è dentro la stessa chiamata, non un passo dopo).
  // Il delay live è imposto dal totalizzatore, non riducibile dal client — ma le
  // strade sotto sono TEST per verificarlo coi tuoi occhi. La leva reale è la multipla.

  const BET_RX = /\/sport-sale-service\/internal-services\/bet(\?|$)/;

  // ─── cattura chunk JS con la logica scommessa (per analisi) ───
  // Marcatori SPECIFICI del codice di piazzamento (NON "betslip"/"wager" che matchano
  // anche UI e telemetria Dynatrace). Cerchiamo l'endpoint e i campi esatti del body.
  const JS_MARKERS = ["WagerService", "betDataList", "timestampClient", "acceptChangedOdd",
                      "acceptOddToValue", "sport-sale-service", "internal-services", "clientTransactionId"];
  // esclusioni: se il file è chiaramente Dynatrace/telemetria, scartalo
  const JS_EXCLUDE = ["dynatrace", "dtrum", "ruxitagent", "@dynatrace"];
  const capturedJs = new Map();   // url → { code, size, markers }
  function maybeCaptureJs(url, code) {
    try {
      if (!code || typeof code !== "string" || code.length < 200) return;
      if (capturedJs.has(url)) return;
      // scarta telemetria di terze parti
      const head = code.slice(0, 3000).toLowerCase();
      if (JS_EXCLUDE.some(x => head.indexOf(x) !== -1) || /dynatrace/i.test(url)) return;
      const hits = JS_MARKERS.filter(m => code.indexOf(m) !== -1);
      // cattura se ha i marcatori specifici, OPPURE se è il chunk 75086/5086 (id modulo betslip)
      const isBetChunk = /(^|\/)(5086|75086|2990|6399|6747|2729|5007|8937|8768|8384)[-.]/.test(url);
      if (!hits.length && !isBetChunk) return;
      capturedJs.set(url, { code, size: code.length, markers: hits.length ? hits : ["chunk-betslip:" + url.match(/(\d{3,5})[-.]/)?.[1]] });
      if (ui) ui.onJsCaptured(url, capturedJs.get(url).markers, capturedJs.size);
    } catch (e) {}
  }

  // ───────────────────────── stato / toggle ─────────────────────────
  let ui = null;
  let tPrematch = false;   // live:true → false (manda una live come prematch)
  let tBackdate = false;   // timestampClient − BACKDATE_MS
  let tMulti    = false;   // ripeti la chiamata N volte con ts sfalsati
  let tOdd      = false;   // acceptChangedOdd = 2 (accetta qualsiasi variazione quota)
  const BACKDATE_MS = 12000;   // di quanto spostare indietro il timestamp
  const MULTI_CALLS = 5;       // quante chiamate ripetute
  const MULTI_STEP_MS = 3000;  // "distanza" simulata tra i ts delle chiamate ripetute

  const LS = { P: "ebfb_prematch", B: "ebfb_backdate", M: "ebfb_multi", O: "ebfb_odd", LOG: "ebfb_log" };
  let log = [];
  try {
    tPrematch = localStorage.getItem(LS.P) === "1";
    tBackdate = localStorage.getItem(LS.B) === "1";
    tMulti    = localStorage.getItem(LS.M) === "1";
    tOdd      = localStorage.getItem(LS.O) === "1";
    log = JSON.parse(localStorage.getItem(LS.LOG) || "[]");
  } catch (e) {}
  function saveState() {
    try {
      localStorage.setItem(LS.P, tPrematch ? "1" : "0");
      localStorage.setItem(LS.B, tBackdate ? "1" : "0");
      localStorage.setItem(LS.M, tMulti ? "1" : "0");
      localStorage.setItem(LS.O, tOdd ? "1" : "0");
      localStorage.setItem(LS.LOG, JSON.stringify(log.slice(0, 15)));
    } catch (e) {}
  }

  // ───────────────────── manipolazione payload ─────────────────────
  // ogni funzione riceve/ritorna l'oggetto JS del body (parse/stringify gestiti fuori)
  function applyPrematch(payload) {
    let changed = false;
    (function walk(o) {
      if (!o || typeof o !== "object") return;
      for (const k of Object.keys(o)) {
        if (k === "live" && o[k] === true) { o[k] = false; changed = true; }
        else if (o[k] && typeof o[k] === "object") walk(o[k]);
      }
    })(payload);
    return changed;
  }
  function applyBackdate(payload, deltaMs) {
    let changed = false;
    (function walk(o) {
      if (!o || typeof o !== "object") return;
      for (const k of Object.keys(o)) {
        if (/timestampClient|timestamp|creationTime/i.test(k) && typeof o[k] === "number" && o[k] > 1e12) {
          o[k] = o[k] - deltaMs; changed = true;
        } else if (o[k] && typeof o[k] === "object") walk(o[k]);
      }
    })(payload);
    return changed;
  }
  function applyOdd(payload) {
    let changed = false;
    (function walk(o) {
      if (!o || typeof o !== "object") return;
      for (const k of Object.keys(o)) {
        if (k === "acceptChangedOdd") { o[k] = 2; changed = true; }
        else if (o[k] && typeof o[k] === "object") walk(o[k]);
      }
    })(payload);
    return changed;
  }

  // ───────────────────── XHR hook ─────────────────────
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;
  let capturedHeaders = {};
  const _setHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
    try { if (/^(content-type|authorization|x-|accept)$/i.test(k)) capturedHeaders[k] = v; } catch (e) {}
    return _setHeader.apply(this, [k, v]);
  };

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._ebUrl = url; this._ebMethod = method;
    return _open.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function (body) {
    const url = this._ebUrl || "";
    if (BET_RX.test(url) && (this._ebMethod || "").toUpperCase() === "POST") {
      // prova a manipolare il payload secondo i toggle attivi
      let obj = null;
      try { obj = JSON.parse(body); } catch (e) {}
      if (obj) {
        const applied = [];
        if (tPrematch && applyPrematch(obj)) applied.push("live→prematch");
        if (tBackdate && applyBackdate(obj, BACKDATE_MS)) applied.push("ts −" + (BACKDATE_MS / 1000) + "s");
        if (tOdd && applyOdd(obj)) applied.push("acceptOdd=2");
        if (applied.length) { body = JSON.stringify(obj); if (ui) ui.onApplied(applied); }

        // STRADA "multi-call": manda la chiamata N volte con ts sfalsati, in parallelo,
        // per vedere se il server conta le chiamate/tempo dal ts che gli mandiamo noi.
        if (tMulti) {
          fireMultiCalls(url, obj, capturedHeaders);
          if (ui) ui.onMulti(MULTI_CALLS);
        }
      }

      const t0 = performance.now();
      if (ui) ui.onBetStart();
      this.addEventListener("load", function () {
        const ms = Math.round(performance.now() - t0);
        let ok = false, ticket = null, code = null;
        try {
          const data = JSON.parse(this.responseText);
          code = data && data.code;
          ticket = findKey(data, "idAams");
          ok = !!ticket && code === 1;
        } catch (e) {}
        addLog(ms, ok, ticket, code);
        if (ui) ui.onBetDone(ms, ok, ticket, code);
      });
    }
    return _send.apply(this, [body, ...(arguments.length > 1 ? [].slice.call(arguments, 1) : [])]);
  };

  // ─── intercetta il caricamento dei chunk JS (fetch + <script>) e li cattura ───
  const _fetch = window.fetch;
  window.fetch = function (input, init) {
    const url = typeof input === "string" ? input : (input && input.url) || "";
    const p = _fetch.apply(this, arguments);
    if (/\.js(\?|$)/.test(url)) {
      p.then(r => { try { r.clone().text().then(t => maybeCaptureJs(url, t)); } catch (e) {} }).catch(() => {});
    }
    return p;
  };

  // Scarica TUTTI i .js della pagina (sono in cache, costo ~0) e li passa al filtro.
  // Aggressivo di proposito: non filtra sull'URL, filtra sul CONTENUTO. Così prende
  // anche i chunk già caricati prima dell'estensione.
  const scannedUrls = new Set();
  let scannedCount = 0;
  function scanScripts() {
    try {
      const urls = new Set();
      // 1) tutti gli <script src>
      for (const s of document.scripts) { if (s.src) urls.add(s.src); }
      // 2) tutti i chunk noti alla webpack chunk-map di Next.js (anche non ancora nel DOM)
      collectWebpackChunks(urls);
      for (const src of urls) {
        if (!/\.js(\?|$)/.test(src) || scannedUrls.has(src)) continue;
        scannedUrls.add(src);
        scannedCount++;
        _fetch(src).then(r => r.text()).then(t => maybeCaptureJs(src, t)).catch(() => {});
      }
      if (ui) ui.onJsScan(scannedCount, capturedJs.size);
    } catch (e) {}
  }

  // ricava gli URL di TUTTI i chunk dalla mappa webpack di Next.js (window.__NEXT_P / webpack)
  function collectWebpackChunks(urls) {
    try {
      // Next.js espone la funzione di public path + chunk map su window.webpackChunk_N_E
      const wp = window.webpackChunk_N_E || window.webpackJsonp;
      // costruisci gli URL dei chunk static/chunks/*.js dal manifest se presente
      const base = location.origin + "/_next/static/chunks/";
      // prova a leggere gli id chunk dai <link rel=preload/prefetch> e <script>
      document.querySelectorAll('link[rel="preload"][as="script"],link[rel="prefetch"]').forEach(l => {
        if (l.href && /\.js(\?|$)/.test(l.href)) urls.add(l.href);
      });
      // fallback: se c'è __BUILD_MANIFEST con la lista dei file, usala
      const bm = window.__BUILD_MANIFEST;
      if (bm && typeof bm === "object") {
        for (const k of Object.keys(bm)) {
          const arr = bm[k];
          if (Array.isArray(arr)) arr.forEach(f => { if (/\.js$/.test(f)) urls.add(location.origin + "/_next/" + f); });
        }
      }
    } catch (e) {}
  }
  setInterval(scanScripts, 1500);
  scanScripts();

  // scarica tutti i JS catturati come file (uno .txt con dentro tutti i chunk rilevanti)
  function downloadCapturedJs() {
    if (!capturedJs.size) { if (ui) ui.onJsNone(); return; }
    let out = "// Eurobet — chunk JS con logica scommessa catturati dall'estensione\n";
    out += "// marcatori cercati: " + JS_MARKERS.join(", ") + "\n\n";
    for (const [url, info] of capturedJs) {
      out += "\n" + "=".repeat(80) + "\n";
      out += "// URL: " + url + "\n";
      out += "// dimensione: " + info.size + " byte · marcatori: " + info.markers.join(", ") + "\n";
      out += "=".repeat(80) + "\n";
      out += info.code + "\n";
    }
    const blob = new Blob([out], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "eurobet_betslip_chunks.txt";
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(a.href);
  }

  // manda MULTI_CALLS copie della /bet, ognuna con timestampClient sfalsato di MULTI_STEP_MS
  function fireMultiCalls(url, baseObj, headers) {
    for (let i = 1; i < MULTI_CALLS; i++) {
      const clone = JSON.parse(JSON.stringify(baseObj));
      // sposta il ts indietro di i*step, così sembrano chiamate distanziate nel tempo
      applyBackdate(clone, i * MULTI_STEP_MS);
      const h = Object.assign({ "Content-Type": "application/json" }, headers);
      fetch(url, { method: "POST", headers: h, body: JSON.stringify(clone), credentials: "include" })
        .then(r => r.json()).then(d => {
          const tk = findKey(d, "idAams");
          if (ui) ui.onMultiResult(i, d && d.code, tk);
        }).catch(() => {});
    }
  }

  function findKey(o, key) {
    let res = null;
    (function walk(x) {
      if (res != null || !x || typeof x !== "object") return;
      for (const k of Object.keys(x)) {
        if (res != null) return;
        if (k === key && x[k] != null && x[k] !== "") { res = x[k]; return; }
        if (x[k] && typeof x[k] === "object") walk(x[k]);
      }
    })(o);
    return res;
  }

  function addLog(ms, ok, ticket, code) {
    log.unshift({ orario: new Date().toTimeString().slice(0, 8), ms, ok, ticket: ticket || null, code });
    if (log.length > 15) log.pop();
    saveState();
    if (ui) ui.renderLog();
  }

  // ───────────────────────────── GUI ───────────────────────────
  function buildUI() {
    const host = document.createElement("div");
    host.id = "ebfb-host";
    host.style.cssText = "position:fixed!important;top:0!important;right:0!important;z-index:2147483647!important;width:0;height:0;";
    (document.body || document.documentElement).appendChild(host);
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        :host { all: initial; }
        * { box-sizing:border-box; margin:0; padding:0; font-family:-apple-system,"Segoe UI",system-ui,sans-serif; }
        .wrap { position:fixed; top:14px; right:14px; width:290px; z-index:2147483647; pointer-events:auto;
          background:#1a1030; color:#efe8ff; border:1px solid #3d2a6b; border-radius:14px;
          box-shadow:0 14px 44px rgba(0,0,0,.6); overflow:hidden; }
        .wrap.min { height:50px; } .wrap.min .body { display:none; }
        .head { display:flex; align-items:center; gap:10px; padding:13px 14px; cursor:move;
          background:linear-gradient(135deg,#1a1030,#26184a); border-bottom:1px solid #3d2a6b; user-select:none; }
        .logo { width:30px; height:30px; border-radius:8px; background:#a06bff; color:#1a1030;
          display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:900; }
        .title { font-size:14px; font-weight:800; color:#fff; flex:1; line-height:1.05; }
        .title small { display:block; font-size:9px; color:#a06bff; font-weight:700; letter-spacing:.5px; }
        .hbtn { width:24px; height:24px; border-radius:6px; border:1px solid #3d2a6b; background:#241640;
          color:#8a76bf; cursor:pointer; font-size:12px; display:flex; align-items:center; justify-content:center; }
        .body { padding:14px; }
        .crono-box { background:#241640; border:1px solid #3d2a6b; border-radius:12px; padding:18px; text-align:center; }
        .crono-label { font-size:9px; color:#8a76bf; text-transform:uppercase; letter-spacing:2px; margin-bottom:8px; }
        .crono-val { font-size:42px; font-weight:800; font-variant-numeric:tabular-nums; color:#a06bff; line-height:1; }
        .crono-val .u { font-size:15px; color:#8a76bf; margin-left:5px; }
        .crono-val.run { color:#ffd84d; } .crono-val.err { color:#e85d5d; }
        .crono-detail { font-size:10px; color:#8a76bf; margin-top:9px; min-height:13px; }
        .tog { display:flex; align-items:center; justify-content:space-between; margin-top:9px;
          background:#241640; border:1px solid #3d2a6b; border-radius:10px; padding:9px 12px; }
        .tog span { font-size:12px; font-weight:700; color:#fff; }
        .tog small { display:block; font-size:9px; color:#8a76bf; font-weight:400; }
        .sw { position:relative; width:42px; height:23px; flex-shrink:0; }
        .sw input { display:none; }
        .sl { position:absolute; inset:0; background:#3d2a6b; border-radius:23px; cursor:pointer; transition:.3s; }
        .sl::before { content:""; position:absolute; width:16px; height:16px; left:4px; top:3px;
          background:#8a76bf; border-radius:50%; transition:.3s; }
        input:checked + .sl { background:#a06bff; }
        input:checked + .sl::before { transform:translateX(19px); background:#1a1030; }
        .loghead { display:flex; justify-content:space-between; align-items:center; margin:14px 0 7px; }
        .loghead span { font-size:9px; color:#8a76bf; text-transform:uppercase; letter-spacing:1px; }
        .loghead button { font-size:9px; background:#241640; color:#8a76bf; border:1px solid #3d2a6b;
          padding:3px 9px; border-radius:5px; cursor:pointer; }
        .log-list { display:flex; flex-direction:column; gap:4px; max-height:170px; overflow-y:auto; }
        .li { background:#241640; border:1px solid #3d2a6b; border-radius:7px; padding:7px 10px;
          display:grid; grid-template-columns:50px 1fr 40px; align-items:center; font-size:11px; gap:6px; }
        .li .o { color:#8a76bf; font-size:10px; } .li .t { color:#fff; text-align:right; font-weight:800; }
        .li .b { font-size:8px; font-weight:800; padding:2px 4px; border-radius:3px; text-align:center; }
        .li .b.ok { background:rgba(160,107,255,.2); color:#a06bff; }
        .li .b.ko { background:rgba(232,93,93,.16); color:#e85d5d; }
        .empty { text-align:center; color:#3d2a6b; font-size:11px; padding:14px 0; }
        .note { font-size:9px; color:#8a76bf; margin-top:8px; line-height:1.3; }
        .jsbox { margin-top:12px; background:#241640; border:1px solid #3d2a6b; border-radius:10px; padding:10px; }
        .jsinfo { font-size:11px; color:#efe8ff; margin-bottom:8px; } .jsinfo b { color:#a06bff; }
        .jsbtn { width:100%; padding:9px; border-radius:8px; border:none; background:#a06bff; color:#1a1030;
          font-weight:800; font-size:12px; cursor:pointer; } .jsbtn:hover { filter:brightness(1.1); }
        .jsbtn:disabled { opacity:.5; cursor:default; }
      </style>
      <div class="wrap" id="wrap">
        <div class="head" id="head">
          <div class="logo">⚡</div>
          <div class="title">EUROBET FAST BET<small>v1.3 · cattura mirata</small></div>
          <div class="hbtn" id="min">—</div>
        </div>
        <div class="body">
          <div class="crono-box">
            <div class="crono-label">ultima giocata</div>
            <div class="crono-val" id="crono">--</div>
            <div class="crono-detail" id="cdet">in attesa di una scommessa…</div>
          </div>

          <div class="tog"><div><span>Live → prematch</span><small>live:true → false</small></div>
            <label class="sw"><input type="checkbox" id="tP"><span class="sl"></span></label></div>
          <div class="tog"><div><span>Timestamp −12s</span><small>sposta timestampClient indietro</small></div>
            <label class="sw"><input type="checkbox" id="tB"><span class="sl"></span></label></div>
          <div class="tog"><div><span>Multi-call ×5</span><small>5 chiamate con ts sfalsati</small></div>
            <label class="sw"><input type="checkbox" id="tM"><span class="sl"></span></label></div>
          <div class="tog"><div><span>Accetta variazione quota</span><small>acceptChangedOdd=2</small></div>
            <label class="sw"><input type="checkbox" id="tO"><span class="sl"></span></label></div>

          <div class="note" id="note"></div>

          <div class="jsbox" id="jsbox">
            <div class="jsinfo" id="jsinfo">📥 chunk JS betslip catturati: <b>0</b></div>
            <button class="jsbtn" id="jsdl">Scarica JS catturati</button>
          </div>

          <div class="loghead"><span>ultime giocate</span><button id="clr">Pulisci</button></div>
          <div class="log-list" id="loglist"><div class="empty">Nessuna giocata</div></div>
        </div>
      </div>`;

    const $ = (s) => root.querySelector(s);
    const wrap = $("#wrap"), crono = $("#crono"), cdet = $("#cdet"), note = $("#note"), loglist = $("#loglist");

    function bind(id, get, set) {
      const el = $(id); el.checked = get();
      el.addEventListener("change", () => { set(el.checked); saveState(); });
    }
    bind("#tP", () => tPrematch, v => tPrematch = v);
    bind("#tB", () => tBackdate, v => tBackdate = v);
    bind("#tM", () => tMulti, v => tMulti = v);
    bind("#tO", () => tOdd, v => tOdd = v);

    $("#min").addEventListener("click", () => {
      wrap.classList.toggle("min");
      $("#min").textContent = wrap.classList.contains("min") ? "▢" : "—";
    });
    $("#clr").addEventListener("click", () => { log = []; saveState(); renderLog(); });
    $("#jsdl").addEventListener("click", () => downloadCapturedJs());

    (function () {
      const head = $("#head"); let drag = false, sx = 0, sy = 0, ox = 0, oy = 0;
      head.addEventListener("mousedown", (e) => {
        if (e.target.id === "min") return;
        drag = true; const r = wrap.getBoundingClientRect();
        sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top;
        wrap.style.right = "auto"; wrap.style.left = ox + "px"; wrap.style.top = oy + "px"; e.preventDefault();
      });
      window.addEventListener("mousemove", (e) => {
        if (!drag) return;
        wrap.style.left = (ox + e.clientX - sx) + "px";
        wrap.style.top = Math.max(0, oy + e.clientY - sy) + "px";
      });
      window.addEventListener("mouseup", () => drag = false);
    })();

    function renderLog() {
      if (!log.length) { loglist.innerHTML = '<div class="empty">Nessuna giocata</div>'; return; }
      loglist.innerHTML = log.map(e => `
        <div class="li" title="code ${e.code == null ? "?" : e.code}${e.ticket ? " · " + e.ticket : ""}">
          <span class="o">${e.orario}</span>
          <span class="t">${e.ms}ms</span>
          <span class="b ${e.ok ? "ok" : "ko"}">${e.ok ? "OK" : "KO"}</span>
        </div>`).join("");
    }

    const jsinfo = $("#jsinfo");
    ui = {
      onJsCaptured(url, markers, count) {
        jsinfo.innerHTML = "📥 chunk betslip catturati: <b>" + count + "</b>";
      },
      onJsScan(scanned, captured) {
        // mostra quanti .js sono stati letti (diagnostica): se scanned>0 e captured=0,
        // significa che la logica bet non è in quei file (delay lato server).
        jsinfo.innerHTML = "📥 catturati: <b>" + captured + "</b> · scansionati: " + scanned + " .js";
      },
      onJsNone() { jsinfo.innerHTML = "⚠️ 0 catturati — apri la schedina, prepara una giocata, poi riprova"; },
      onApplied(list) { note.innerHTML = "🔧 applicato: " + list.join(" · "); },
      onMulti(n) { note.innerHTML += (note.innerHTML ? " · " : "") + "📡 " + n + " chiamate parallele"; },
      onMultiResult(i, code, ticket) {
        note.innerHTML += ` · call#${i}:${code == null ? "?" : code}${ticket ? "✓" : ""}`;
      },
      onBetStart() { crono.className = "crono-val run"; cdet.textContent = "scommessa inviata…"; },
      onBetDone(ms, ok, ticket, code) {
        crono.innerHTML = ms + '<span class="u">ms</span>';
        crono.className = "crono-val" + (ok ? "" : " err");
        cdet.textContent = ok
          ? `✓ ACCETTATA in ${ms}ms${ticket ? " · " + ticket : ""}`
          : `✕ code ${code == null ? "?" : code} — non accettata`;
        renderLog();
      },
      renderLog
    };
    renderLog();
  }

  let built = false;
  function tryBuild() { if (built || !document.body) return built; try { buildUI(); built = true; } catch (e) {} return built; }
  function init() {
    if (tryBuild()) return;
    document.addEventListener("DOMContentLoaded", tryBuild, { once: true });
    try { const o = new MutationObserver(() => { if (tryBuild()) o.disconnect(); });
      o.observe(document.documentElement, { childList: true, subtree: true }); } catch (e) {}
    let n = 0; const iv = setInterval(() => { if (tryBuild() || ++n > 40) clearInterval(iv); }, 250);
  }
  init();
})();
