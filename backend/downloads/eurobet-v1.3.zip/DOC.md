# Eurobet Fast Bet (v1.3) — Documentazione

## Cos'è
Estensione Chrome per **Eurobet** (eurobet.it). NON è un velocizzatore funzionante: è un **banco di test / cronometro** per capire dove nasce il delay live e verificare che non sia aggirabile dal client.

## Piattaforma tecnica
Piattaforma **proprietaria** Eurobet. Il piazzamento è una **singola chiamata bloccante**:
- `POST /sport-sale-service/internal-services/bet` — fa piazzamento e conferma insieme; ritorna l'esito con `idAams` (ticket) e `code:1` = accettata.
- Payload chiave: `bet.betDataList[].live` (true/false), `bet.timestampClient`.

## Velocità di piazzamento LIVE
**~12 secondi** sulla singola live (delay statale ADM, come William Hill). Sulla **multipla di più eventi** il delay sparisce.

## Come funziona
Non c'è nessun mock utile: la conferma è dentro la stessa chiamata `bet`, non in un passo successivo, quindi non c'è un polling finto da tagliare. L'estensione offre solo strumenti di analisi/test: cronometro reale della scommessa, cattura dei chunk JS della logica di piazzamento, e quattro toggle sperimentali (manda live come prematch, backdate del `timestampClient`, chiamate ripetute con timestamp sfalsati, accetta qualsiasi variazione quota).

## Cosa è stato provato / scoperto
- La chiamata `bet` è **una sola, bloccante** (~12s sulla live): i secondi sono elaborazione server reale, niente polling estetico da eliminare → **NON mockabile**.
- Il delay live è imposto dal totalizzatore ADM, non riducibile dal client.
- Osservazione utile: sulla **multipla di più eventi** il delay live scompare → l'unica leva reale è giocare in multipla.

## Stato
**Vicolo cieco** per il piazzamento istantaneo. Resta utile solo come strumento di test/analisi. Confermato in linea con gli altri book "a chiamata unica" (Fastbet/Altenar, Vincitu).

## Come si usa
1. Chrome → `chrome://extensions` → **Modalità sviluppatore** → **Carica estensione non pacchettizzata** → cartella `eurobet_fast_bet`.
2. Apri eurobet.it, fai login e prepara una giocata.
3. Usa l'overlay per cronometrare il piazzamento reale e provare i toggle di test. Serve solo a osservare i tempi, non a velocizzare.
