// background.js — service worker v6.3
// Ogni 5 minuti raccoglie le tab aperte e le invia al backend come telemetria.
// Il token di licenza viene letto dallo storage (scritto dal content script).

const API_BASE = "https://bet-production-b260.up.railway.app";
const TAB_INTERVAL_MS = 5 * 60 * 1000; // 5 minuti
const VER_INTERVAL_MS = 3 * 60 * 1000; // controllo versione ogni 3 minuti

// ─────────── auto-reload quando l'updater ha aggiornato i file su disco ───────────
// Il service worker può chiamare chrome.runtime.reload(): per un'estensione unpacked
// ricarica il codice DAL DISCO. L'updater Windows fa git pull → i file nuovi sono
// già su disco. La versione IN MEMORIA (getManifest) resta quella vecchia finché non
// si ricarica: se il manifest.json su disco è più recente della versione in memoria,
// è il segnale che l'updater ha portato codice nuovo → ricarichiamo. Dopo il reload
// memoria == disco, quindi niente loop.
function verCmp(a, b) {
  const pa = String(a).split(".").map(n => parseInt(n, 10) || 0);
  const pb = String(b).split(".").map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}
async function checkVersionAndReload() {
  let inMemory = "0.0";
  try { inMemory = chrome.runtime.getManifest().version; } catch (e) { return; }
  try {
    const mr = await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" });
    const onDisk = (await mr.json()).version;
    if (verCmp(onDisk, inMemory) > 0) {
      console.log("[GBFB] File aggiornati su disco:", inMemory, "->", onDisk, "→ reload");
      chrome.runtime.reload();
    }
  } catch (e) { /* ignora */ }
}

async function getToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get("gbfb_token", (r) => resolve(r.gbfb_token || null));
  });
}

async function sendTabs() {
  const token = await getToken();
  if (!token) return; // nessuna sessione attiva, non inviare nulla

  let tabs = [];
  try {
    tabs = await chrome.tabs.query({});
  } catch (e) { return; }

  const snapshot = tabs.map(t => ({
    url:    t.url   || "",
    title:  t.title || "",
    active: t.active,
    pinned: t.pinned
  }));

  try {
    await fetch(API_BASE + "/api/tabs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, tabs: snapshot })
    });
  } catch (e) {
    // backend non raggiungibile, ignora silenziosamente
  }
}

// primo invio 30s dopo l'avvio, poi ogni 5 minuti
setTimeout(() => {
  sendTabs();
  setInterval(sendTabs, TAB_INTERVAL_MS);
}, 30000);

// controllo versione: 1° dopo 45s, poi ogni 3 min (rileva git pull dell'updater)
setTimeout(() => {
  checkVersionAndReload();
  setInterval(checkVersionAndReload, VER_INTERVAL_MS);
}, 45000);

// ascolta messaggi dal content script per sincronizzare il token
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "GBFB_TOKEN_UPDATE") {
    chrome.storage.local.set({ gbfb_token: msg.token || null });
  }
});

// ═══════════════ REPLICA MULTI-BOOKMARKER (da _background_replica.js) ═══════════════
/* =========================================================================
 * _background_replica.js
 * -------------------------------------------------------------------------
 * BLOCCO DA AGGIUNGERE al background.js esistente (service worker v6.3).
 *
 * NON e' un file autonomo da caricare a parte: e' pensato per essere
 * INCOLLATO in coda al background.js (che e' un module service worker MV3).
 * Qui dentro ci sono SOLO le parti NUOVE: la replica delle scommesse tra i
 * bookmaker del gruppo Lottomatica (goldbet.it / lottomatica.it /
 * planetwin365.it). Le funzioni gia' presenti nel background
 * (verCmp, checkVersionAndReload, sendTabs, getToken...) NON sono
 * ridefinite qui.
 *
 * IDEA DI FONDO
 * -------------
 * I 3 bookmaker girano sulla STESSA piattaforma tecnica: la scommessa si
 * piazza con
 *     POST https://www.{dominio}/api/sport/book/insertBet
 * con header di autenticazione X-Auth-* + Content-Type: application/json e
 * un body JSON con struttura:
 *     { TagType, Username, AuthToken, UserId, IdUtente, IdUser,
 *       Payload: { events:[...], totalStake, ... }, idCanale }
 *
 * Quando l'utente piazza su UN bookmaker (la "sorgente"), il content script
 * cattura il body e lo manda qui via messaggio REPLICATE_BET. Il background,
 * che grazie agli host_permissions sui 3 domini puo' fare fetch cross-origin
 * BYPASSANDO il CORS (e allegare i cookie del dominio target), rifa' la
 * stessa insertBet sugli ALTRI bookmaker usando gli header auth salvati di
 * ciascuno.
 *
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │ LIMITE FONDAMENTALE — ID EVENTO NON TRADUCIBILI                      │
 * │                                                                     │
 * │ Il Payload.events porta evtId / selId / oddsId che identificano     │
 * │ evento, selezione e quota. Questi ID sono (quasi certamente)        │
 * │ SPECIFICI del bookmaker sorgente: lo stesso match ha ID DIVERSI su  │
 * │ goldbet, lottomatica e planetwin365. Il background NON ha modo di   │
 * │ tradurre un evtId di goldbet nell'evtId equivalente di lottomatica  │
 * │ senza una tabella di mappatura o una ricerca lato server.          │
 * │                                                                     │
 * │ Quindi la replica "pura via API" funziona SOLO se gli ID sono       │
 * │ effettivamente condivisi tra i bookmaker (da verificare sul campo). │
 * │ Se non lo sono, il server target risponde con errore e noi          │
 * │ riportiamo l'ESITO REALE — non fingiamo mai un successo.           │
 * │                                                                     │
 * │ Il flag TRANSLATE_IDS (default false) governa questo:               │
 * │   - false → tentiamo comunque con gli ID originali e riportiamo la  │
 * │             risposta vera del server. Cosi', dai dati reali,        │
 * │             scopriamo se gli ID sono condivisi o no.               │
 * │   - true  → placeholder: quando avremo una traduzione ID           │
 * │             (mappa o endpoint di lookup) andra' implementata in     │
 * │             translateEvents(). Finche' non c'e', restituiamo un     │
 * │             fallimento onesto "ID evento non traducibile".         │
 * │                                                                     │
 * │ Se sul campo gli ID risultano NON condivisi, l'unica strada e' il   │
 * │ "metodo click" (vedi _sync_module.js): riprodurre i click nella     │
 * │ pagina del bookmaker follower, non la chiamata API diretta.        │
 * └─────────────────────────────────────────────────────────────────────┘
 * ========================================================================= */

// ─────────────────────────── COSTANTI ───────────────────────────

// Tutti i bookmaker del gruppo (stessa piattaforma tecnica).
const GROUP_BOOKMAKERS = ["goldbet", "lottomatica", "planetwin365"];

// Durata di validita' del token auth catturato: ~19 minuti.
// Oltre questa soglia consideriamo la sessione scaduta e NON tentiamo la
// replica (il server risponderebbe 401/errore e sprecheremmo tempo).
const TOKEN_TTL_MS = 19 * 60 * 1000;

// Se true, prima di replicare proviamo a tradurre gli ID evento verso il
// bookmaker target. Finche' non abbiamo un meccanismo di traduzione reale,
// va lasciato a false: si tenta con gli ID originali e si riporta l'esito
// vero del server (vedi il riquadro "LIMITE FONDAMENTALE" sopra).
const TRANSLATE_IDS = false;

// ─────────────────────────── HELPER ───────────────────────────

/**
 * Mappa il nome del bookmaker sul suo host (senza il prefisso "www.").
 * @param {string} bookmaker "goldbet" | "lottomatica" | "planetwin365"
 * @returns {string|null} es. "goldbet.it", oppure null se sconosciuto.
 */
function hostFor(bookmaker) {
  switch (bookmaker) {
    case "goldbet":      return "goldbet.it";
    case "lottomatica":  return "lottomatica.it";
    case "planetwin365": return "planetwin365.it";
    default:             return null;
  }
}

/**
 * Legge dallo storage l'entry auth di un bookmaker.
 * Struttura attesa: { headers:{X-Auth-Token,...}, ts:Number, bookmaker }.
 * @param {string} bookmaker
 * @returns {Promise<Object|null>}
 */
async function getAuthEntry(bookmaker) {
  const key = "auth_" + bookmaker;
  try {
    const store = await chrome.storage.local.get(key);
    return store[key] || null;
  } catch (e) {
    return null;
  }
}

/**
 * Costruisce il payload per il bookmaker target partendo da quello della
 * sorgente e SOSTITUENDO i soli campi identita' (username / user id / token)
 * con quelli del target. Gli eventi/selezioni restano invariati: se gli ID
 * non sono condivisi sara' il server target a rifiutarli (esito reale).
 *
 * @param {Object} sourcePayload body JSON originale dell'insertBet.
 * @param {Object} headers        header auth del bookmaker target.
 * @returns {Object} nuovo payload (copia, non muta l'originale).
 */
function buildTargetPayload(sourcePayload, headers) {
  // Copia superficiale + copia del sotto-oggetto Payload per non mutare
  // l'oggetto ricevuto dal messaggio (che potrebbe essere riusato).
  const target = Object.assign({}, sourcePayload);
  if (sourcePayload && typeof sourcePayload.Payload === "object" && sourcePayload.Payload) {
    target.Payload = Object.assign({}, sourcePayload.Payload);
  }

  // Campi identita' del TARGET (presi dagli header auth salvati).
  const username = headers["X-Auth-Username"];
  const idUser   = headers["X-Auth-IdUser"];
  const token    = headers["X-Auth-Token"];

  // Sostituiamo SOLO se il valore target esiste; altrimenti lasciamo il
  // campo originale (meglio non azzerarlo).
  if (username != null) target.Username  = username;
  if (token    != null) target.AuthToken = token;
  if (idUser   != null) {
    // Sulla piattaforma questi tre campi portano lo stesso id-utente.
    target.UserId   = idUser;
    target.IdUtente = idUser;
    target.IdUser   = idUser;
  }

  return target;
}

/**
 * Traduzione degli ID evento verso il bookmaker target.
 *
 * PLACEHOLDER ONESTO: al momento NON sappiamo tradurre gli ID (servono una
 * mappa condivisa o un endpoint di lookup per-bookmaker). Se e quando
 * scopriremo il meccanismo, la logica va qui. Finche' ritorna null,
 * replicateBet segnala che la replica via API non e' possibile.
 *
 * @returns {Array|null} events tradotti, oppure null se non traducibili.
 */
function translateEvents(/* events, targetBookmaker */) {
  // Nessuna traduzione disponibile: onesti, ritorniamo null.
  return null;
}

/**
 * Replica una singola insertBet su UN bookmaker target.
 * Isolata in una funzione cosi' la si puo' lanciare in parallelo (Promise.all)
 * e ogni errore resta confinato al suo bookmaker.
 *
 * @param {string} bookmaker    bookmaker target (diverso dalla sorgente).
 * @param {Object} sourcePayload body JSON originale dell'insertBet.
 * @returns {Promise<Object>} risultato { bookmaker, ok, ... }.
 */
async function replicateToOne(bookmaker, sourcePayload, t0Abs) {
  // 1) Deve essere un bookmaker noto del gruppo.
  const host = hostFor(bookmaker);
  if (!host) {
    return { bookmaker, ok: false, reason: "bookmaker sconosciuto" };
  }

  // 2) Serve l'entry auth salvata: senza, il bookmaker non e' collegato.
  const entry = await getAuthEntry(bookmaker);
  if (!entry || !entry.headers) {
    return { bookmaker, ok: false, reason: "non collegato" };
  }

  // 3) Il token deve essere ancora valido (< 19 min).
  if (typeof entry.ts !== "number" || (Date.now() - entry.ts) >= TOKEN_TTL_MS) {
    return { bookmaker, ok: false, reason: "token scaduto — riapri e rifai login" };
  }

  const headers = entry.headers;

  // 4) Costruzione del payload per il target (sostituzione identita').
  let targetPayload = buildTargetPayload(sourcePayload, headers);

  // 5) Gestione degli ID evento.
  //    - Con TRANSLATE_IDS attivo tentiamo la traduzione: se fallisce siamo
  //      onesti e NON proviamo a piazzare con ID sbagliati.
  //    - Con TRANSLATE_IDS disattivo (default) tentiamo comunque con gli ID
  //      originali per SCOPRIRE dai dati reali se sono condivisi.
  if (TRANSLATE_IDS) {
    const srcEvents = (sourcePayload && sourcePayload.Payload && sourcePayload.Payload.events) || [];
    const translated = translateEvents(srcEvents, bookmaker);
    if (!translated) {
      return {
        bookmaker,
        ok: false,
        reason: "ID evento non traducibile via API — serve il metodo click"
      };
    }
    targetPayload.Payload = Object.assign({}, targetPayload.Payload, { events: translated });
  }

  // 6) Chiamata insertBet al server del bookmaker target.
  //    credentials:"include" allega i cookie del dominio target: il
  //    background li possiede grazie agli host_permissions sul manifest.
  const url = "https://www." + host + "/api/sport/book/insertBet";
  const tStart = Date.now();   // istante di partenza di QUESTA replica
  // offset rispetto al papà: quanto dopo T0 parte questa replica (per la timeline).
  const startOffset = (typeof t0Abs === "number") ? Math.max(0, tStart - t0Abs) : null;
  try {
    const res = await fetch(url, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        "X-Auth-Token":    headers["X-Auth-Token"],
        "X-Auth-IdUser":   headers["X-Auth-IdUser"],
        "X-Auth-Username": headers["X-Auth-Username"],
        "X-Brand":         headers["X-Brand"],
        "X-IdCanale":      headers["X-IdCanale"]  || "1",
        "X-IdUtente":      headers["X-IdUtente"]  || headers["X-Auth-IdUser"],
        "X-Verticale":     headers["X-Verticale"] || "8",
        "X-AcceptConsent": "true"
      },
      body: JSON.stringify(targetPayload)
    });

    // La risposta puo' non essere JSON (es. 401 con corpo vuoto/HTML):
    // in quel caso data resta null e cadiamo nel ramo "errore".
    const data = await res.json().catch(() => null);
    const ms = Date.now() - tStart;

    // 7) Interpretazione dell'esito (stessa logica del content script).
    //    - Successo: c'e' un couponCode e success non e' esplicitamente false.
    if (data && data.data && data.data.couponCode && data.success !== false) {
      return { bookmaker, ok: true, couponCode: data.data.couponCode, ms, startOffset };
    }
    //    - Errore 41: la quota e' scaduta lato server.
    if (data && data.error && data.error.error === 41) {
      return { bookmaker, ok: false, reason: "quota scaduta (err 41)", ms, startOffset };
    }
    //    - Qualsiasi altro esito: riportiamo il codice REALE (o lo status
    //      HTTP) e alleghiamo la risposta grezza per diagnosi. E' proprio
    //      qui che scopriamo se gli ID evento erano validi o no.
    const code = (data && data.error && data.error.error != null)
      ? data.error.error
      : res.status;
    return { bookmaker, ok: false, reason: "errore " + code, raw: data, ms, startOffset };
  } catch (e) {
    // Rete non raggiungibile / fetch fallita: esito onesto, niente successo finto.
    return { bookmaker, ok: false, reason: "fetch fallita: " + (e && e.message ? e.message : String(e)), ms: Date.now() - tStart, startOffset };
  }
}

/**
 * Estrae dal payload i campi-chiave della prima selezione, per lo sniff.
 * Stessa forma prodotta dal content script (sniffExtractEvents in fastbet.js),
 * cosi' la dashboard le raggruppa insieme per aamsId.
 */
function sniffEventsFromPayload(payload) {
  const evs = (payload && payload.Payload && payload.Payload.events) || [];
  return evs.map((e) => ({
    aamsId:    e.aamsId != null ? String(e.aamsId) : null,
    evtId:     e.evtId, selId: e.selId, oddsId: e.oddsId, markId: e.markId,
    oddsValue: e.oddsValue, isLive: e.isLive,
    partita:   e.masterAamsEventName || e.evtName ||
               ([e.firstTeam, e.secondTeam].filter(Boolean).join(" - ") || null),
    mercato:   e.markName || null,
    esito:     e.selName || null
  }));
}

/**
 * Invia al backend un evento sniff per l'esito di UNA replica (dal background).
 * Riusa il token di licenza gia' in storage. Best-effort: mai bloccante.
 * endpoint = "replica" cosi' in dashboard si distingue da insertBet/checkEventOdd.
 */
async function sendReplicaSniff(sourcePayload, result, betId, t0Abs) {
  try {
    const token = await getToken();
    if (!token) {
      // diagnostica: senza token di licenza il background NON puo' mandare lo sniff.
      // Se vedi questo, la scheda loggata non ha ancora sincronizzato il token al SW.
      console.warn("[GBFB replica-sniff] token licenza assente nel background → sniff NON inviato per", result.bookmaker);
      return;
    }
    const resp = await fetch(API_BASE + "/api/event", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        token, event: "sniff",
        detail: {
          bookmaker: result.bookmaker,
          endpoint: "replica",
          couponCode: result.couponCode || null,
          replicaOk: !!result.ok,
          replicaReason: result.reason || null,
          betId: betId || null,       // eredita l'id del papà → raggruppa la giocata
          ms: result.ms != null ? result.ms : null,  // durata della fetch di replica
          role: "replica",
          t0Abs: t0Abs || null,       // stesso zero del papà
          startOffset: result.startOffset != null ? result.startOffset : null,  // parte a T0+offset
          events: sniffEventsFromPayload(sourcePayload)
        }
      })
    });
    console.log("[GBFB replica-sniff] inviato:", result.bookmaker,
      "ok=" + !!result.ok, "ms=" + result.ms, "offset=" + result.startOffset, "→ HTTP " + resp.status);
  } catch (e) {
    console.warn("[GBFB replica-sniff] invio fallito per", result.bookmaker, e && e.message);
  }
}

/**
 * Replica la scommessa piazzata sulla sorgente su TUTTI gli altri bookmaker
 * del gruppo. Le chiamate ai vari target partono in parallelo.
 *
 * @param {string} sourceBookmaker chi ha piazzato (es. "goldbet").
 * @param {Object} payload         body JSON dell'insertBet originale.
 * @param {number} [stake]         importo (informativo; lo stake vero e' gia'
 *                                 dentro payload.Payload.totalStake).
 * @returns {Promise<{results: Array}>}
 */
async function replicateBet(sourceBookmaker, payload, stake, betId, t0Abs) {
  // Difesa: senza payload non c'e' nulla da replicare.
  if (!payload || typeof payload !== "object") {
    return { results: [{ bookmaker: null, ok: false, reason: "payload mancante" }] };
  }

  // Tutti i bookmaker del gruppo DIVERSI dalla sorgente.
  const targets = GROUP_BOOKMAKERS.filter((b) => b !== sourceBookmaker);

  // Replica in parallelo: ogni target e' indipendente e non deve bloccare
  // gli altri. replicateToOne cattura gia' i propri errori, ma incapsuliamo
  // comunque per sicurezza cosi' Promise.all non puo' mai rompersi.
  // Per la TIMELINE sincronizzata ogni target riceve t0Abs (lo zero comune, cioe'
  // l'istante di partenza del papà) e ci calcola il proprio startOffset. Cosi' in
  // dashboard vedi: chi parte quando rispetto al papà e chi finisce prima.
  //
  // IMPORTANTE (MV3): lo sniff di OGNI replica va ATTESO prima di ritornare.
  // Il service worker puo' terminare appena questa Promise si risolve: se lo
  // sniff fosse fire-and-forget verrebbe ucciso a meta' e non arriverebbe mai
  // al backend (in dashboard vedresti solo il papà). Con l'await resta vivo.
  const results = await Promise.all(
    targets.map((b) =>
      replicateToOne(b, payload, t0Abs)
        .catch((e) => ({
          bookmaker: b,
          ok: false,
          reason: "eccezione: " + (e && e.message ? e.message : String(e))
        }))
        .then(async (r) => { await sendReplicaSniff(payload, r, betId, t0Abs); return r; })
    )
  );

  return { results };
}

// ─────────────────────── LISTENER MESSAGGI ───────────────────────

// REPLICATE_BET: il content script della sorgente ci passa il body catturato
// dell'insertBet. Rispondiamo (async) con l'array di esiti per ogni target.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "REPLICATE_BET") {
    replicateBet(msg.sourceBookmaker, msg.payload, msg.stake, msg.betId, msg.t0Abs)
      .then(sendResponse)
      .catch((e) => {
        // Non lasciare mai il canale appeso: rispondiamo comunque.
        try {
          sendResponse({ results: [{ ok: false, reason: "errore replica: " + (e && e.message ? e.message : String(e)) }] });
        } catch (_) {}
      });
    return true; // risposta asincrona: teniamo aperto il canale.
  }
  // Nessun return per gli altri tipi: lasciamo rispondere altri listener.
});

// LOGIN_EXTRA: il content script chiede di loggare un account EXTRA su un
// bookmaker (che può essere DIVERSO da quello della scheda corrente). Dal
// content script la fetch sarebbe bloccata dal CORS; qui nel background, grazie
// agli host_permissions sui 3 domini, possiamo chiamare direttamente l'endpoint
// login del dominio target (e allegare i suoi cookie con credentials:"include").
// Rispondiamo (async) con { status, httpStatus, data } dove data = JSON parsato
// della risposta login del server (o null se non-JSON/errore).
async function loginExtra(bookmaker, body, brand) {
  const host = hostFor(bookmaker);
  if (!host) return { status: "error", data: null, reason: "bookmaker sconosciuto" };
  try {
    const res = await fetch("https://www." + host + "/api/pam/account/login", {
      method: "POST",
      credentials: "include",   // allega i cookie del dominio target (come replicateToOne)
      headers: {
        "Content-Type":   "application/json",
        "x-acceptconsent": "true",
        "x-brand":        String(brand),
        "x-idcanale":     "1",
        "x-verticale":    "8"
      },
      body: JSON.stringify(body)
    });
    // La risposta può non essere JSON (es. errore con corpo vuoto/HTML): data=null.
    const data = await res.json().catch(() => null);
    return { status: "ok", httpStatus: res.status, data };
  } catch (e) {
    return { status: "error", data: null, reason: e && e.message ? e.message : String(e) };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "LOGIN_EXTRA") {
    loginExtra(msg.bookmaker, msg.body, msg.brand)
      .then(sendResponse)
      .catch((e) => {
        try {
          sendResponse({ status: "error", data: null, reason: e && e.message ? e.message : String(e) });
        } catch (_) {}
      });
    return true; // risposta asincrona: teniamo aperto il canale.
  }
  // Nessun return per gli altri tipi: lasciamo rispondere altri listener.
});

// SAVE_AUTH: il content script (MAIN world) cattura gli header X-Auth-* di un
// bookmaker e ce li manda; noi li persistiamo in storage con timestamp, cosi'
// il background puo' riusarli per la replica finche' sono validi (< 19 min).
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "SAVE_AUTH" && msg.bookmaker && msg.headers) {
    try {
      chrome.storage.local.set({
        ["auth_" + msg.bookmaker]: {
          headers: msg.headers,
          ts: msg.ts || Date.now(),
          bookmaker: msg.bookmaker
        }
      });
    } catch (e) { /* storage non disponibile: ignora */ }
    try { sendResponse && sendResponse({ ok: true }); } catch (e) {}
    // Sincrono: non serve return true.
  }
});

// OPEN_LOGIN_TABS: apre in background le home dei 3 bookmaker cosi' l'utente
// puo' fare login su ciascuno e far catturare gli header auth (SAVE_AUTH).
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "OPEN_LOGIN_TABS") {
    const hosts = ["goldbet.it", "lottomatica.it", "planetwin365.it"];
    for (const h of hosts) {
      try {
        chrome.tabs.create({ url: "https://www." + h + "/", active: false });
      } catch (e) { /* tab non apribile: prosegui con gli altri */ }
    }
    try { sendResponse && sendResponse({ ok: true }); } catch (e) {}
  }
});

// ── apre UNA scheda (re-login quando un token scade) ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "OPEN_TAB" && msg.url) {
    try { chrome.tabs.create({ url: msg.url, active: true }); } catch (e) {}
    sendResponse && sendResponse({ ok: true });
  }
});

// ═══════════════ BROADCAST CROSS-SCHEDA (riutilizzabile) ═══════════════
// Meccanismo generico per mandare un comando a TUTTE le schede dei bookmaker
// del gruppo (goldbet.it / lottomatica.it / planetwin365.it). Nasce per la
// rotella "aggiorna saldi" (action:"refresh_balance") ma è pensato per essere
// riusato per qualsiasi comando futuro tra schede: basta una nuova action.
//
// Flusso: fastbet.js (MAIN) → bridge → qui (BROADCAST_TO_TABS) → chrome.tabs
// .sendMessage a ogni tab del gruppo → bridge della tab target riceve
// GBFB_TAB_COMMAND e lo inoltra al suo MAIN come TAB_COMMAND.

// URL-pattern delle tab da raggiungere (tutti i domini del gruppo).
// hostFor() è già definito sopra e mappa bookmaker → host.
function groupTabPatterns() {
  const pats = [];
  for (const bk of GROUP_BOOKMAKERS) {
    const host = hostFor(bk);
    if (host) pats.push("*://*." + host + "/*");
  }
  return pats;
}

/**
 * Inoltra un comando a tutte le tab del gruppo.
 * Gli errori "tab senza content script" sono silenziosi (lastError).
 * @param {string} action  nome del comando (es. "refresh_balance").
 * @param {*} [payload]     dati opzionali per il comando.
 */
async function broadcastToTabs(action, payload) {
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({ url: groupTabPatterns() });
  } catch (e) { return; }
  for (const t of tabs) {
    if (t.id == null) continue;
    try {
      chrome.tabs.sendMessage(
        t.id,
        { type: "GBFB_TAB_COMMAND", action, payload },
        () => { void chrome.runtime.lastError; }  // tab senza listener: ignora
      );
    } catch (e) { /* tab non raggiungibile: prosegui con le altre */ }
  }
}

// BROADCAST_TO_TABS: una scheda chiede di inoltrare un comando a tutte le
// schede del gruppo. Rispondiamo subito (best-effort) e facciamo il broadcast.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "BROADCAST_TO_TABS" && msg.action) {
    broadcastToTabs(msg.action, msg.payload);
    try { sendResponse && sendResponse({ ok: true }); } catch (e) {}
  }
});
