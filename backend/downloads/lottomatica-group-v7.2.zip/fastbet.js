(function () {
  "use strict";

  // Goldbet Fast Bet v6.5 — MAIN world, GUI a overlay (Shadow DOM)
  // Intercetta insertBet/pendingBet e mocka la conferma pendingBet.
  // Gate di licenza: funziona solo se l'utente è loggato e attivo sul backend.
  // Novità v6.3: telemetria tab ogni 5 min via background service worker.
  // Novità v6.4: retry automatico su error 41 (quota scaduta) — recupera la
  //              quota fresca da getDetailsEventLive e ripiazza la scommessa.
  // Novità v6.5: vincolo account Goldbet — il plugin si apre SOLO se lo username
  //              loggato su Goldbet è nella lista autorizzata della licenza.
  // Novità v6.6: telemetria scommesse dettagliata — importo, quote, vincita
  //              potenziale, coupon, esito (piazzata / errore 41 con motivo).
  // Novità v6.7: log arricchito con partita, squadre, mercato ed esito di ogni
  //              selezione (letti dal payload insertBet).
  // Novità v6.8: fallback nome partita dallo slug URL + sport/torneo quando il
  //              payload non contiene i nomi (evita il "?" nel log).
  // Novità v6.9: manda la versione anche al login (per il gating legacy lato server).

  // ───────────────────────── licenza ─────────────────────────
  const API_BASE   = "https://bet-production-b260.up.railway.app";
  const APP_VERSION = "7.2";  // ⚠️ bumpare INSIEME al manifest.json a ogni release

  // ─────────────── rilevamento bookmaker dal dominio corrente ───────────────
  // Il plugin è unico e gira su goldbet.it / lottomatica.it / planetwin365.it.
  // Bookmaker, URL API e tema GUI derivano tutti dall'hostname.
  const HOST = location.hostname.replace(/^www\./, "");
  const BK_MAP = {
    "goldbet.it":      { bk: "goldbet",      name: "GOLDBET",      theme: "gold"   },
    "lottomatica.it":  { bk: "lottomatica",  name: "LOTTOMATICA",  theme: "red"    },
    "planetwin365.it": { bk: "planetwin365", name: "PLANETWIN365", theme: "green"  }
  };
  const SITE = BK_MAP[HOST] || BK_MAP["goldbet.it"];  // fallback goldbet
  const BOOKMAKER = SITE.bk;

  // ─────────────── palette GUI per tema (dal dominio) ───────────────
  // La GUI overlay usa questi colori invece di quelli Goldbet hardcoded.
  // I colori di STATO funzionali (verde-ok #6fd36f, rosso-errore #e85d5d,
  // blu #6fa8ff) restano invariati su tutti i temi: sono segnali, non branding.
  const THEMES = {
    gold:  { bg:"#0A1B4E", bg2:"#122356", box:"#0e2050", border:"#1c3270", boxAlt:"#16264f", accent:"rgb(255,204,0)", accentDim:"rgba(255,204,0,.13)", accentShadow:"rgba(255,204,0,.35)", txt:"#e8ecf7", muted:"#6c7aa8", logoTxt:"#0A1B4E" },
    red:   { bg:"#1a0f14", bg2:"#2a1218", box:"#2a1218", border:"#4a1f28", boxAlt:"#3a1a22", accent:"#e2001a", accentDim:"rgba(226,0,26,.15)", accentShadow:"rgba(226,0,26,.45)", txt:"#f3e8ea", muted:"#b08a92", logoTxt:"#fff" },
    green: { bg:"#0d1410", bg2:"#14201a", box:"#14201a", border:"#1f4a30", boxAlt:"#1a2e22", accent:"#00c853", accentDim:"rgba(0,200,83,.15)", accentShadow:"rgba(0,200,83,.45)", txt:"#e8f5ec", muted:"#7fae90", logoTxt:"#0d1410" }
  };
  const T = THEMES[SITE.theme] || THEMES.gold;
  const API_ORIGIN = location.origin;  // es. https://www.goldbet.it — usato per insertBet ecc.
  // la "famiglia" per la sincronizzazione tra schede (tutti gli host del gruppo)
  const GROUP_HOSTS = { "goldbet": "www.goldbet.it", "lottomatica": "www.lottomatica.it", "planetwin365": "www.planetwin365.it" };
  const LS_TOKEN   = "gbfb_token";
  const LS_EMAIL   = "gbfb_email";
  let licToken     = null;
  let licEmail     = null;
  let licActive    = false;
  try {
    licToken = localStorage.getItem(LS_TOKEN);
    licEmail = localStorage.getItem(LS_EMAIL);
  } catch (e) {}

  // ───────────────── account Goldbet (username dal DOM) ─────────────────
  // L'header Goldbet mostra il nome utente in <div class="utente">…<div>NOME</div></div>.
  // Se l'elemento non c'è, l'utente non ha fatto il login su Goldbet.
  let gbUser = null;
  function readGbUser() {
    try {
      const box = document.querySelector(".utente");
      if (!box) return null;
      for (const d of box.querySelectorAll(":scope > div")) {
        if (d.querySelector("a, i, button, input")) continue;
        const t = (d.textContent || "").trim();
        if (t) return t;
      }
    } catch (e) {}
    return null;
  }

  // notifica il background service worker quando il token cambia
  function syncTokenToBackground(token) {
    try {
      chrome.runtime.sendMessage({ type: "GBFB_TOKEN_UPDATE", token: token || null });
    } catch (e) {}
  }

  async function apiLogin(email, password) {
    const r = await fetch(API_BASE + "/api/login", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, gbUser, version: APP_VERSION, bookmaker: BOOKMAKER })
    });
    return r.json();
  }
  async function apiCheck(token) {
    try {
      const r = await fetch(API_BASE + "/api/check", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, version: APP_VERSION, gbUser, bookmaker: BOOKMAKER })
      });
      return r.json();
    } catch (e) { return { ok: false, offline: true }; }
  }
  function apiEvent(event, detail) {
    if (!licToken) return;
    fetch(API_BASE + "/api/event", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: licToken, event, detail })
    }).catch(() => {});
  }
  function saveLicense() {
    try {
      if (licToken) localStorage.setItem(LS_TOKEN, licToken); else localStorage.removeItem(LS_TOKEN);
      if (licEmail) localStorage.setItem(LS_EMAIL, licEmail); else localStorage.removeItem(LS_EMAIL);
    } catch (e) {}
    syncTokenToBackground(licToken);
  }
  function doLogout() {
    if (licToken) fetch(API_BASE + "/api/logout", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: licToken })
    }).catch(() => {});
    licToken = null; licEmail = null; licActive = false;
    saveLicense();
  }

  // esegue i comandi remoti ricevuti dal backend
  function handleCommands(cmds) {
    for (const c of cmds) {
      try {
        if (c.type === "logout") {
          doLogout();
          if (ui && ui.showLogin) ui.showLogin("Disconnesso dall'amministratore", "warn");
        } else if (c.type === "message") {
          const txt = c.payload && c.payload.text ? c.payload.text : "Messaggio dall'amministratore";
          alert(txt);
        }
        // altri tipi (config, ecc.) verranno gestiti in futuro
      } catch (e) {}
    }
  }

  // mostra un banner di aggiornamento (una sola volta per sessione di pagina)
  let updateBannerShown = false;
  function showUpdateBanner(update) {
    if (updateBannerShown) return;
    updateBannerShown = true;
    try {
      if (update.mandatory) licActive = false;  // blocca l'uso finché non aggiorna
      const bar = document.createElement("div");
      bar.id = "gbfb-update-bar";
      bar.style.cssText = [
        "position:fixed", "top:0", "left:0", "right:0", "z-index:2147483647",
        "background:" + T.accent, "color:" + T.logoTxt, "font:700 13px -apple-system,Segoe UI,sans-serif",
        "padding:10px 16px", "display:flex", "align-items:center", "gap:12px",
        "box-shadow:0 2px 12px rgba(0,0,0,.3)"
      ].join(";");
      const msg = update.mandatory
        ? `⚠️ Aggiornamento OBBLIGATORIO alla v${update.version || update.latest} — Fast Bet è bloccato finché non aggiorni.`
        : `⬆️ Disponibile Fast Bet v${update.version || update.latest}.`;
      const changelog = update.changelog ? ` — ${update.changelog}` : "";
      bar.innerHTML =
        `<span style="flex:1">${msg}${changelog}</span>` +
        (update.download_url ? `<a href="${update.download_url}" target="_blank" style="background:${T.bg};color:#fff;padding:6px 12px;border-radius:6px;text-decoration:none">Scarica</a>` : "") +
        (update.mandatory ? "" : `<span id="gbfb-update-x" style="cursor:pointer;font-size:18px;padding:0 4px">×</span>`);
      document.documentElement.appendChild(bar);
      const x = bar.querySelector("#gbfb-update-x");
      if (x) x.addEventListener("click", () => bar.remove());
    } catch (e) {}
  }

  // ───────────────────────────── stato ─────────────────────────────
  let mockEnabled = false;
  let couponCode  = null;
  let stake       = 1.0;
  let t0 = 0, t1 = 0;
  let pendingXhr  = null;
  const aamsTicketID = "df07ea0613304e9e910b";

  // contesto dell'ultima scommessa (per la telemetria dettagliata)
  let betCtx = null;
  let lastRetryAttempt = 0;

  // Goldbet a volte manda le quote come interi x100 (185 = 1.85)
  function normOdd(v) {
    const n = parseFloat(String(v).replace(",", "."));
    if (!isFinite(n) || n <= 0) return null;
    return n >= 101 ? +(n / 100).toFixed(2) : n;
  }

  // ricostruisce il nome partita dallo slug dell'URL Goldbet quando il payload
  // non lo contiene. Es. ".../calcio/mondiali/norvegia-francia" → "Norvegia-Francia".
  function partitaDaUrl() {
    try {
      const seg = location.pathname.split("/").filter(Boolean).pop() || "";
      const slug = seg.split("?")[0];
      if (!slug || !slug.includes("-")) return null;
      return slug.split("-")
        .map(w => w ? w[0].toUpperCase() + w.slice(1) : w)
        .join(" ")
        .replace(/\bVs\b/i, "-");
    } catch (e) { return null; }
  }

  const nz = (v) => { const s = (v == null ? "" : String(v)).trim(); return s || null; };

  // estrae dal payload insertBet: importo, quote, quota totale, vincita potenziale,
  // e per ogni selezione partita/squadre/mercato/esito.
  // Struttura reale: { Payload: { totalStake, events: [{ oddsValue, selName,
  //   markName, evtName / masterAamsEventName, firstTeam, secondTeam, sportName, tName }] } }
  function parseBetCtx(body) {
    try {
      const p = JSON.parse(body);
      const payload = p?.Payload || p?.request?.Payload || {};
      const events = payload.events || [];
      const urlPartita = partitaDaUrl();
      const quote = [];
      const selezioni = events.map(e => {
        const q = normOdd(e.oddsValue);
        if (q) quote.push(q);
        const first = nz(e.firstTeam), second = nz(e.secondTeam);
        const partita = nz(e.masterAamsEventName) || nz(e.evtName) ||
          ([first, second].filter(Boolean).join(" - ") || null) ||
          (events.length === 1 ? urlPartita : null);  // fallback URL solo per la singola
        return {
          partita,
          firstTeam: first,
          secondTeam: second,
          mercato: nz(e.markName),   // es. "Prossimo Gol 1° Tempo"
          esito: nz(e.selName),      // es. "Casa" / "Over 2.5"
          quota: q,
          sport: nz(e.sportName),
          torneo: nz(e.tName)
        };
      });
      const quotaTot = quote.length ? +quote.reduce((a, q) => a * q, 1).toFixed(2) : null;
      const stk = payload.totalStake || 0;
      return {
        stake: stk,
        quote,
        quotaTot,
        vincita: quotaTot ? +(quotaTot * stk).toFixed(2) : null,
        nSel: events.length,
        selezioni
      };
    } catch (e) { return null; }
  }

  // telemetria: scommessa rifiutata (errore server / quota scaduta non recuperata)
  function logBetError(code, motivo, tentativi = 0) {
    apiEvent("bet_errore", {
      esito: "rifiutata", code, motivo, tentativi,
      stake,
      quote: (betCtx && betCtx.quote) || [],
      quotaTot: betCtx ? betCtx.quotaTot : null,
      vincita: betCtx ? betCtx.vincita : null,
      selezioni: (betCtx && betCtx.selezioni) || []
    });
  }

  // auth headers catturati dalla prima XHR autenticata — usati dal monitor SMK
  let globalAuthHeaders = {};

  // ───────────────── replica di gruppo (multibook) ─────────────────
  // Cattura completa degli header di auth (tutti gli "X-*") da inviare al bridge
  // ISOLATED, che li persiste in chrome.storage. Il background li riusa per
  // replicare la stessa scommessa sugli altri bookmaker del gruppo.
  // Tutto best-effort: mai rompere una richiesta del sito.
  let capturedAuthHeaders = {};   // { "X-Auth-Token": "...", "X-Brand": "1", ... }
  let lastAuthSave = 0;           // throttle: al massimo un SAVE_AUTH ogni 30s
  const AUTH_SAVE_THROTTLE_MS = 30000;

  // stato "replica di gruppo attiva" — gestito dalla GUI (menu multibook).
  // DEFAULT: disattivato (solo il bookmaker corrente funziona).
  const LS_GROUP_REPLICA    = "gbfb_group_replica";  // "1" = attivo
  const LS_ACTIVE_BOOKMAKERS = "gbfb_active_bks";     // JSON array es. ["lottomatica","planetwin365"]
  function isGroupReplicaEnabled() {
    try { return localStorage.getItem(LS_GROUP_REPLICA) === "1"; } catch (e) { return false; }
  }
  function getActiveExtraBookmakers() {
    try { return JSON.parse(localStorage.getItem(LS_ACTIVE_BOOKMAKERS) || "[]"); } catch (e) { return []; }
  }

  // invia gli header di auth catturati al bridge (throttlato), appena abbiamo
  // almeno X-Auth-Token + X-Auth-IdUser. Chiamata dall'hook setRequestHeader.
  function maybeSaveAuth() {
    try {
      if (!capturedAuthHeaders["X-Auth-Token"] || !capturedAuthHeaders["X-Auth-IdUser"]) return;
      const now = Date.now();
      if (now - lastAuthSave < AUTH_SAVE_THROTTLE_MS) return;
      lastAuthSave = now;
      window.postMessage({
        source: "gbfb", type: "SAVE_AUTH",
        bookmaker: BOOKMAKER,
        headers: capturedAuthHeaders,
        allHeaders: capturedAuthHeaders,
        userAgent: navigator.userAgent,
        ts: now
      }, "*");
    } catch (e) {}
  }

  // ───────────────── helper richiesta-risposta col bridge ─────────────────
  // Usata dalla GUI per leggere stato auth / domini custom ecc. Risolve null
  // dopo 3s se il bridge non risponde.
  let __bridgeReqId = 0;
  function bridgeRequest(type, extra) {
    return new Promise((resolve) => {
      const req = ++__bridgeReqId;
      const timer = setTimeout(() => { window.removeEventListener("message", onResp); resolve(null); }, 3000);
      function onResp(ev) {
        if (ev.source !== window) return;
        const m = ev.data;
        if (!m || m.source !== "gbfb-bridge" || m.__res !== req) return;
        clearTimeout(timer); window.removeEventListener("message", onResp); resolve(m);
      }
      window.addEventListener("message", onResp);
      window.postMessage(Object.assign({ source: "gbfb", type, __req: req }, extra || {}), "*");
    });
  }

  // ───────────────── risultati della replica dal bridge/background ─────────────────
  // Il background risponde con un array { bookmaker, ok, reason/couponCode }.
  window.addEventListener("message", (ev) => {
    if (ev.source !== window) return;
    const m = ev.data;
    if (!m || m.source !== "gbfb-bridge" || !m.results) return;
    try {
      for (const r of m.results) {
        const txt = r.ok
          ? ("✓ replicato su " + r.bookmaker + " (" + (r.couponCode || "") + ")")
          : ("✕ " + r.bookmaker + ": " + r.reason);
        if (typeof ui !== "undefined" && ui && ui.onReplicaResult) ui.onReplicaResult(r);
        console.log("[GBFB replica]", txt);
      }
    } catch (e) {}
  });

  // marketIdLong dell'ultima selezione aggiunta al coupon — es. "3826;21669;44806;0;0"
  // se null, monitora tutti i mercati dell'evento
  let watchedMarketIdLong = null;

  // ───────────────────── monitor SMK (sospensione mercati) ─────────────────────
  // Legge il DOM della pagina ogni 1s — nessuna chiamata di rete.
  // ATTENZIONE: le classi .red / .green sulle quote indicano solo la DIREZIONE
  // del movimento quota (scesa/salita), NON la sospensione. Una quota può essere
  // rossa ed essere perfettamente giocabile.
  //
  // La quota NON giocabile (quella che causa l'errore 41) ha la classe "lucchetto"
  // (o "disabled") sul div .item — Goldbet ci mette l'icona del lucchetto.
  // Selettore reale: .item.lucchetto  oppure  .item.disabled

  let smkTimer = null;

  // ─── tracking durata sospensioni (rosso→verde) ───
  let smkState     = "gray";   // stato corrente: gray | green | red
  let smkRedStart  = 0;        // performance.now() di inizio sospensione
  let smkRedNames  = [];       // selezioni che erano bloccate in questa sospensione
  let smkEvtId     = null;     // eid dell'evento monitorato
  // storico delle sospensioni concluse: { orario, durata(ms), sel, eid }
  let smkLog = [];
  const LS_SMKLOG = "gbfb_smklog";
  try { smkLog = JSON.parse(localStorage.getItem(LS_SMKLOG) || "[]"); } catch (e) {}
  function saveSmkLog() {
    try { localStorage.setItem(LS_SMKLOG, JSON.stringify(smkLog)); } catch (e) {}
  }

  function isItemLocked(el) {
    return el.classList.contains("lucchetto") || el.classList.contains("disabled");
  }

  function currentEvtId() {
    const m = window.location.search.match(/[?&]eid=(\d+)/);
    return m ? m[1] : null;
  }

  // registra una transizione di stato e misura la durata del rosso
  function onSmkTransition(newState, lockedNames) {
    const now = performance.now();
    if (newState === "red" && smkState !== "red") {
      // inizio sospensione
      smkRedStart = now;
      smkRedNames = lockedNames.slice();
      smkEvtId    = currentEvtId();
    } else if (newState === "green" && smkState === "red") {
      // fine sospensione → calcola durata
      const durata = Math.round(now - smkRedStart);
      smkLog.unshift({
        orario: new Date().toTimeString().slice(0, 8),
        durata,
        sel: (smkRedNames.length ? smkRedNames.join(", ") : "—"),
        eid: smkEvtId || currentEvtId()
      });
      if (smkLog.length > 50) smkLog.pop();
      saveSmkLog();
      if (ui) ui.onSmkClosed(smkLog[0]);
    }
    smkState = newState;
  }

  function pollSmk() {
    try {
      // trova il mercato Prossimo Gol nel DOM (aggiorna ad ogni poll — può cambiare)
      const mktId = findProssimoGolMarket();
      if (!mktId) {
        if (smkState === "red") onSmkTransition("green", []); // chiudi eventuale sospensione aperta
        smkState = "gray";
        if (ui) ui.setSmk("gray", []);
        return;
      }
      watchedMarketIdLong = mktId;
      const scope = `[data-marketidlong='${mktId}']`;

      const items = document.querySelectorAll(scope + " .item.item-hover");
      if (!items.length) {
        if (smkState === "red") onSmkTransition("green", []);
        smkState = "gray";
        if (ui) ui.setSmk("gray", []);
        return;
      }

      // nomi delle selezioni BLOCCATE (lucchetto) — sono quelle che danno errore 41
      const locked = [...items]
        .filter(isItemLocked)
        .map(el => el.querySelector(".item--mercato")?.textContent?.trim() || "?");

      const newState = locked.length > 0 ? "red" : "green";
      onSmkTransition(newState, locked);
      if (ui) ui.setSmk(newState, locked);
    } catch (e) {
      if (ui) ui.setSmk("gray", []);
    }
  }

  function startSmkMonitor() {
    if (smkTimer) return;
    // aspetta che Angular abbia renderizzato almeno una quota prima di partire
    const kick = () => {
      if (document.querySelector(".item.item-hover")) {
        smkTimer = setInterval(pollSmk, 100); // 100ms per misure precise
        pollSmk();
      } else {
        setTimeout(kick, 300);
      }
    };
    kick();
  }

  let log = [];
  let cronoTimer = null;
  let ui = null;

  const LS_MOCK  = "gbfb_mock";
  const LS_LOG   = "gbfb_log";
  const LS_STAKE = "gbfb_stake";
  let fastStake = 1;  // importo Giocata Rapida (€), default 1

  // ───────────────────── hotkey da tastiera ─────────────────────
  // L'utente assegna un tasto a "prossimo gol CASA" e uno a "prossimo gol
  // OSPITE". Su una pagina evento live, premendo il tasto il plugin clicca
  // automaticamente la quota corrispondente (la aggiunge al carrello). Con la
  // Giocata Rapida attiva permette di bettare velocissimo da tastiera.
  const LS_KEY_CASA   = "gbfb_key_casa";
  const LS_KEY_OSPITE = "gbfb_key_ospite";
  const LS_HOTKEY     = "gbfb_hotkey";
  let keyCasa = null, keyOspite = null;   // valore di event.key ("q", "a", " ", …)
  let hotkeyEnabled = false;              // il toggle è attivo?
  let recordingFor = null;                // 'casa' | 'ospite' | null (modalità REC)

  try {
    mockEnabled = localStorage.getItem(LS_MOCK) === "1";
    log = JSON.parse(localStorage.getItem(LS_LOG) || "[]");
    const s = parseFloat(localStorage.getItem(LS_STAKE));
    if (s > 0) fastStake = s;
    keyCasa   = localStorage.getItem(LS_KEY_CASA)   || null;
    keyOspite = localStorage.getItem(LS_KEY_OSPITE) || null;
    hotkeyEnabled = localStorage.getItem(LS_HOTKEY) === "1";
  } catch (e) {}

  function saveState() {
    try {
      localStorage.setItem(LS_MOCK, mockEnabled ? "1" : "0");
      localStorage.setItem(LS_LOG, JSON.stringify(log));
    } catch (e) {}
  }

  // ───────────────────── intercettore XHR (mock) ───────────────────
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._url = url;
    this._method = method;
    this._headers = {};
    return _open.apply(this, [method, url, ...rest]);
  };

  const _setRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
    if (this._headers) this._headers[k] = v;
    // salva gli auth headers Goldbet globalmente per il monitor SMK
    if (k && k.startsWith("X-Auth") && v) globalAuthHeaders[k] = v;
    // cattura COMPLETA per la replica di gruppo: tutti gli header "X-*" (X-Auth-Token,
    // X-Auth-IdUser, X-Brand, X-IdCanale, X-Verticale, X-AcceptConsent, ...). Appena
    // abbiamo i due essenziali, invia (throttlato) al bridge per la persistenza.
    try {
      if (k && v && k.startsWith("X-")) {
        capturedAuthHeaders[k] = v;
        maybeSaveAuth();
      }
    } catch (e) {}
    return _setRequestHeader.apply(this, [k, v]);
  };

  // ─── cache dell'ultimo getDetailsEventLive (per non rifare la fetch ad ogni selezione) ───
  let _detailsCache = { evtId: null, ts: 0, data: null };

  async function getEventDetails(evtId, authHeaders) {
    const now = performance.now();
    // riusa la cache se è dello stesso evento e fresca (< 800ms)
    if (_detailsCache.evtId === evtId && _detailsCache.data && (now - _detailsCache.ts) < 800) {
      return _detailsCache.data;
    }
    try {
      const r = await fetch(
        API_ORIGIN + "/api/sport/live/getDetailsEventLive/1/" + evtId,
        { method: "GET", headers: authHeaders }
      );
      const data = await r.json();
      _detailsCache = { evtId, ts: now, data };
      return data;
    } catch (e) { return null; }
  }

  // Recupera lo stato aggiornato di una selezione da getDetailsEventLive.
  // Chiavi abbreviate: si=selId, oi=oddsId, ov=oddsValue, ms=stato(1=attiva), mi=markId, smk=mercato sospeso.
  // Ritorna:
  //   { status: "ok",       oddsId, oddsValue, markId }  → quota viva, si può ritentare
  //   { status: "retired" }                              → quota azzerata/ritirata (oi:0 o ov:0) → 41 NON bypassabile
  //   { status: "suspended" }                            → mercato col lucchetto (smk:true)
  //   { status: "notfound" }                             → selezione non presente nei dati
  async function probeSelection(evtId, selId, authHeaders) {
    const data = await getEventDetails(evtId, authHeaders);
    if (!data) return { status: "notfound" };
    const mktWbD = data.mktWbD || {};
    for (const mktKey of Object.keys(mktWbD)) {
      const mkt = mktWbD[mktKey];
      const msGroups = mkt.ms || {};
      for (const grpKey of Object.keys(msGroups)) {
        const asl = msGroups[grpKey]?.asl || [];
        for (const sel of asl) {
          if (sel.si !== selId) continue;
          // trovata la selezione
          if (mkt.smk) return { status: "suspended" };
          if (!sel.oi || !sel.ov || sel.ms !== 1) return { status: "retired" };
          return { status: "ok", oddsId: sel.oi, oddsValue: String(sel.ov), markId: sel.mi };
        }
      }
    }
    return { status: "notfound" };
  }

  // ═══════════════════ SNIFF & LOG MULTI-BOOKMAKER ═══════════════════
  // Cattura passiva di insertBet / checkEventOdd per confrontare gli ID
  // (aamsId, evtId, selId, oddsId, markId) tra i 3 bookmaker del gruppo.
  // OBIETTIVO: capire se gli ID sono condivisi (→ replica senza traduzione)
  // o se serve una mappa di traduzione basata su aamsId (codice palinsesto ADM).
  //
  // Ogni cattura viene:
  //   1) salvata in localStorage locale (per bookmaker): gbfb_sniff
  //   2) inviata al bridge → chrome.storage (chiave sniff_<bookmaker>) così
  //      tutte e 3 le schede confluiscono in un unico store aggregato.
  // Esporti tutto con gbfbSniff() dalla console di QUALSIASI scheda.
  const LS_SNIFF = "gbfb_sniff";
  let sniffLog = [];
  try { sniffLog = JSON.parse(localStorage.getItem(LS_SNIFF) || "[]"); } catch (e) {}

  // betId: id univoco di UNA giocata (il "papà"). Lega la piazzata sorgente alle
  // sue repliche cross-book, così la dashboard le raggruppa per giocata (non per
  // aamsId) e mostra i ms di ciascun book. Generato all'insertBet sorgente.
  let currentBetId = null;
  function newBetId() {
    // deterministico e univoco: bookmaker + t0 arrotondato + un contatore locale
    return BOOKMAKER + "-" + Math.round(performance.now()) + "-" + (sniffLog.length);
  }

  // estrae i soli campi-chiave dagli eventi di un payload insertBet/checkEventOdd.
  // Struttura reale: { Payload: { events:[...] } } (insertBet) oppure
  //                  { events:[...] } (checkEventOdd).
  function sniffExtractEvents(parsed) {
    const evs = parsed?.Payload?.events || parsed?.events || [];
    return evs.map(e => ({
      aamsId:    e.aamsId != null ? String(e.aamsId) : null,
      evtId:     e.evtId,
      selId:     e.selId,
      oddsId:    e.oddsId,
      markId:    e.markId,
      oddsValue: e.oddsValue,
      isLive:    e.isLive,
      // nomi (presenti solo nel Logger, non nell'insertBet snello — best effort)
      partita:   e.masterAamsEventName || e.evtName ||
                 ([e.firstTeam, e.secondTeam].filter(Boolean).join(" - ") || null),
      mercato:   e.markName || null,
      esito:     e.selName || null
    }));
  }

  // registra una cattura sniff.
  // endpoint = "insertBet" | "checkEventOdd" | "logger"
  // meta (opzionale): { betId, ms, role } — betId lega la giocata alle repliche,
  //   ms = durata insertBet, role = "papa" (sorgente) | "replica".
  function sniffBet(endpoint, body, respText, meta) {
    try {
      let parsed = null;
      try { parsed = JSON.parse(body); } catch (e) { return; }
      const events = sniffExtractEvents(parsed);
      if (!events.length) return;

      // couponCode dalla risposta (solo insertBet), best effort
      let couponCode = null;
      try {
        const r = respText ? JSON.parse(respText) : null;
        couponCode = r?.data?.couponCode || null;
      } catch (e) {}

      const m = meta || {};
      const entry = {
        bookmaker: BOOKMAKER,
        host: HOST,
        endpoint,
        ts: Date.now(),
        orario: new Date().toISOString(),
        totalStake: parsed?.Payload?.totalStake ?? parsed?.Payload?.groupCombs?.combsInfo?.[0]?.stake ?? null,
        couponCode,
        betId: m.betId || null,
        ms: m.ms != null ? m.ms : null,
        role: m.role || null,
        events
      };

      // 1) locale (ultime 50 catture)
      sniffLog.unshift(entry);
      if (sniffLog.length > 50) sniffLog.pop();
      try { localStorage.setItem(LS_SNIFF, JSON.stringify(sniffLog)); } catch (e) {}

      // 2) aggregato cross-scheda via bridge → chrome.storage
      try {
        window.postMessage({ source: "gbfb", type: "SNIFF_SAVE", bookmaker: BOOKMAKER, entry }, "*");
      } catch (e) {}

      // 2b) telemetria → backend (per la dashboard admin: sniff per account).
      // apiEvent è no-op se non loggato; mandiamo bookmaker/endpoint/couponCode + eventi.
      try {
        apiEvent("sniff", {
          bookmaker: BOOKMAKER, endpoint, couponCode,
          totalStake: entry.totalStake,
          betId: entry.betId, ms: entry.ms, role: entry.role,
          events
        });
      } catch (e) {}

      // 3) log leggibile in console (compatto, una riga per evento)
      for (const ev of events) {
        console.log(
          `%c[SNIFF ${BOOKMAKER}]%c ${endpoint} | aamsId=${ev.aamsId} evtId=${ev.evtId} selId=${ev.selId} oddsId=${ev.oddsId} markId=${ev.markId} | ${ev.partita || "?"} → ${ev.esito || "?"} @${ev.oddsValue}`,
          "color:#fff;background:#c8102e;padding:1px 4px;border-radius:3px;font-weight:bold", "color:inherit"
        );
      }
    } catch (e) {}
  }

  // Comando console: esporta TUTTE le catture (di tutti i bookmaker, aggregate
  // dal bridge). Stampa un confronto per aamsId così vedi subito se gli ID
  // interni coincidono tra bookmaker. Ritorna anche i dati grezzi.
  window.gbfbSniff = function () {
    return new Promise((resolve) => {
      const done = (agg) => {
        const all = agg || [];
        // raggruppa per aamsId
        const byAams = {};
        for (const e of all) {
          for (const ev of (e.events || [])) {
            const k = ev.aamsId || "(no-aams)";
            (byAams[k] = byAams[k] || []).push({ bk: e.bookmaker, ...ev });
          }
        }
        console.log("%c════ CONFRONTO SNIFF MULTI-BOOKMAKER ════", "color:#c8102e;font-weight:bold;font-size:14px");
        for (const aams of Object.keys(byAams)) {
          const rows = byAams[aams];
          const bks = [...new Set(rows.map(r => r.bk))];
          console.log(`%caamsId ${aams}%c — presente su: ${bks.join(", ")}`, "font-weight:bold;color:#0a1b4e", "color:#666");
          console.table(rows.map(r => ({ bookmaker: r.bk, evtId: r.evtId, selId: r.selId, oddsId: r.oddsId, markId: r.markId, esito: r.esito, quota: r.oddsValue })));
          // verdetto rapido: gli evtId coincidono tra bookmaker?
          if (bks.length > 1) {
            const evtIds = [...new Set(rows.map(r => r.evtId))];
            const selIds = [...new Set(rows.map(r => r.selId))];
            console.log(
              `   → evtId ${evtIds.length === 1 ? "IDENTICO ✅ (replica senza traduzione)" : "DIVERSO ❌ (serve traduzione via aamsId)"} | ` +
              `selId ${selIds.length === 1 ? "IDENTICO ✅" : "DIVERSO ❌"}`
            );
          }
        }
        console.log("%cJSON completo copiabile qui sotto:", "color:#666");
        console.log(JSON.stringify(all, null, 2));
        resolve(all);
      };
      // chiedi al bridge l'aggregato di tutti i bookmaker; fallback al solo locale
      let answered = false;
      const req = "sniffexp_" + Date.now();
      const onResp = (ev) => {
        if (ev.source !== window) return;
        const m = ev.data;
        if (!m || m.source !== "gbfb-bridge" || m.__sniffres !== req) return;
        answered = true;
        window.removeEventListener("message", onResp);
        done(m.all);
      };
      window.addEventListener("message", onResp);
      window.postMessage({ source: "gbfb", type: "SNIFF_EXPORT", __sniffreq: req }, "*");
      setTimeout(() => { if (!answered) { window.removeEventListener("message", onResp); done(sniffLog); } }, 1500);
    });
  };

  // Comando console: azzera tutte le catture (locale + aggregato).
  window.gbfbSniffClear = function () {
    sniffLog = [];
    try { localStorage.removeItem(LS_SNIFF); } catch (e) {}
    try { window.postMessage({ source: "gbfb", type: "SNIFF_CLEAR" }, "*"); } catch (e) {}
    console.log("[SNIFF] catture azzerate");
  };

  // Esegue un insertBet con un payload aggiornato. onDone(success, data, logged):
  // logged=true se fireMockPending ha già registrato la giocata nel log.
  function doInsert(payload, headers, onDone) {
    const xhr = new XMLHttpRequest();
    _open.call(xhr, "POST", API_ORIGIN + "/api/sport/book/insertBet", true);
    for (const [k, v] of Object.entries(headers)) {
      try { xhr.setRequestHeader(k, v); } catch (e) {}
    }
    xhr.addEventListener("load", function () {
      try {
        const data = JSON.parse(this.responseText);
        if (data?.data?.couponCode && data?.success !== false) {
          couponCode = data.data.couponCode;
          t1 = performance.now();
          let logged = false;
          if (mockEnabled && pendingXhr) logged = !!fireMockPending();
          onDone(true, data, logged);
        } else {
          onDone(false, data, false);
        }
      } catch (e) { onDone(false, null, false); }
    });
    xhr.addEventListener("error", () => onDone(false, null, false));
    _send.call(xhr, JSON.stringify(payload));
  }

  // Retry intelligente: aggiorna le quote scadute SOLO se ancora vive, altrimenti si ferma
  // subito distinguendo il motivo (ritirata pre-gol vs mercato sospeso).
  // maxAttempts evita loop infiniti se il server continua a invalidare la quota.
  function retryInsertBet(originalBody, expiredSelections, headers, attempt = 1) {
    let payload;
    try { payload = JSON.parse(originalBody); } catch (e) { return; }
    const events = payload?.Payload?.events || [];
    if (!events.length) {
      logBetError(41, "errore interno nel coupon", attempt - 1);
      if (ui) ui.onRetryFailed("payload");
      return;
    }

    const MAX_ATTEMPTS = 3;

    // sonda in parallelo lo stato attuale di ogni selezione scaduta
    const probes = expiredSelections.map(async (exp) => {
      const evt = events.find(e => e.selId === exp.selectionId || e.oddsId === exp.oddId);
      if (!evt) return { evt: null, probe: { status: "notfound" } };
      const probe = await probeSelection(evt.evtId, evt.selId, headers);
      return { evt, probe };
    });

    Promise.all(probes).then(results => {
      // se anche una sola selezione è ritirata o sospesa → inutile insistere
      const retired   = results.find(r => r.probe.status === "retired");
      const suspended = results.find(r => r.probe.status === "suspended");
      if (suspended) {
        logBetError(41, "mercato sospeso (lucchetto)", attempt - 1);
        if (ui) ui.onRetryFailed("suspended");
        return;
      }
      if (retired) {
        logBetError(41, "quota ritirata dal bookmaker", attempt - 1);
        if (ui) ui.onRetryFailed("retired");
        return;
      }

      // tutte vive → aggiorna oddsId/oddsValue/markId
      let updated = false;
      for (const { evt, probe } of results) {
        if (!evt || probe.status !== "ok") continue;
        evt.oddsId    = probe.oddsId;
        evt.oddsValue = probe.oddsValue;
        if (probe.markId) evt.markId = probe.markId;
        updated = true;
      }
      if (!updated) {
        logBetError(41, "selezione non più presente nei mercati live", attempt - 1);
        if (ui) ui.onRetryFailed("notfound");
        return;
      }

      if (ui) ui.onRetrying(attempt);

      lastRetryAttempt = attempt;
      doInsert(payload, headers, (ok, data, logged) => {
        if (ok) {
          if (ui) ui.onRetryOk();
          if (!logged) {
            // senza mock non arriverà nessun pendingBet per il retry: logga qui l'esito
            const t2 = performance.now();
            addLog(Math.round(t1 - t0), 0, Math.round(t2 - t0), false);
          }
          return;
        }
        // fallito di nuovo: se è ancora 41 e abbiamo tentativi, riprova con quota più fresca
        if (data?.error?.error === 41 && data?.error?.expiredSelections?.length && attempt < MAX_ATTEMPTS) {
          _detailsCache.ts = 0; // invalida cache per forzare fetch fresca
          retryInsertBet(JSON.stringify(payload), data.error.expiredSelections, headers, attempt + 1);
        } else {
          logBetError(data?.error?.error ?? 41, "quota non più disponibile dopo i retry", attempt);
          if (ui) ui.onRetryFailed("server");
        }
      });
    });
  }

  XMLHttpRequest.prototype.send = function (body) {

    if (this._url && this._url.includes("/api/sport/book/insertBet")) {
      t0 = performance.now(); t1 = 0;
      couponCode = null; pendingXhr = null;
      betCtx = parseBetCtx(body);
      stake = (betCtx && betCtx.stake) || 1.0;
      lastRetryAttempt = 0;
      currentBetId = newBetId();   // id della giocata (il "papà") — legherà le repliche
      if (ui) ui.startCrono(Date.now());

      const capturedHeaders = this._headers || {};
      const _body = body;
      const _betId = currentBetId;
      const _tStart = t0;

      // SNIFF: cattura insertBet appena arriva la risposta. role="papa" perché è la
      // giocata sorgente; ms = durata reale della insertBet (round-trip al server).
      this.addEventListener("load", function () {
        try {
          const ms = Math.round(performance.now() - _tStart);
          sniffBet("insertBet", _body, this.responseText, { betId: _betId, ms, role: "papa" });
        } catch (e) {}
      });

      this.addEventListener("load", function () {
        try {
          const data = JSON.parse(this.responseText);
          if (data?.data?.couponCode && data?.success !== false) {
            // successo normale
            couponCode = data.data.couponCode;
            t1 = performance.now();
            if (mockEnabled && pendingXhr) fireMockPending();
            // replica di gruppo: se attiva, chiedi al bridge di rigiocare la
            // stessa scommessa sugli altri bookmaker selezionati nel menu multibook.
            if (isGroupReplicaEnabled()) {
              try {
                const originalBody = JSON.parse(_body);
                window.postMessage({
                  source: "gbfb", type: "REPLICATE_BET",
                  sourceBookmaker: BOOKMAKER,
                  payload: originalBody,
                  stake: (betCtx && betCtx.stake) || 1,
                  betId: _betId,   // id del papà: le repliche erediteranno questo per raggrupparsi
                  extraDomains: getActiveExtraBookmakers()
                }, "*");
              } catch (e) {}
            }
          } else if (data?.error?.error === 41 && data?.error?.expiredSelections?.length) {
            // quota scaduta → retry intelligente (distingue recuperabile vs ritirata)
            retryInsertBet(_body, data.error.expiredSelections, capturedHeaders);
          } else if (data?.success === false) {
            // altro errore → logga e mostra il codice
            logBetError(data?.error?.error ?? null, "rifiutata dal server", 0);
            if (ui) ui.onRetryFailed("err" + (data?.error?.error ?? "?"));
          }
        } catch (e) {}
      });
      return _send.apply(this, [body]);
    }

    if (this._url && this._url.includes("/api/sport/book/pendingBet")) {
      if (mockEnabled && licActive) {
        pendingXhr = this;
        if (couponCode && t1 > 0) fireMockPending();
        return;
      }
      this.addEventListener("load", function () {
        try {
          const t2 = performance.now();
          const totale = t0 ? Math.round(t2 - t0) : 0;
          const insert = t1 ? Math.round(t1 - t0) : 0;
          const pend   = t1 ? Math.round(t2 - t1) : 0;
          addLog(insert, pend, totale, false);
        } catch (e) {}
      });
      return _send.apply(this, [body]);
    }

    // SNIFF checkEventOdd: la validazione-quota pre-piazzamento. Contiene già
    // aamsId/evtId/selId/oddsId/markId — utilissima per il confronto ID anche
    // SENZA piazzare davvero (basta aggiungere la selezione al carrello).
    if (this._url && this._url.includes("/api/sport/book/checkEventOdd")) {
      const _b = body;
      this.addEventListener("load", function () {
        try { sniffBet("checkEventOdd", _b, this.responseText); } catch (e) {}
      });
      return _send.apply(this, [body]);
    }

    // SNIFF Logger/Log: NON piazza nulla, ma è l'UNICO payload che porta i NOMI
    // (partita/mercato/esito) insieme agli ID. Lo sniffo per arricchire le catture
    // con il nome leggibile della partita. Il body è annidato/escaped, lo srotolo.
    if (this._url && this._url.includes("/api/games/Logger/Log")) {
      const _b = body;
      this.addEventListener("load", function () {
        try {
          const outer = JSON.parse(_b);
          const mid = JSON.parse(outer.Message);          // stringa JSON escaped
          const data = JSON.parse(mid.Data);              // altra stringa JSON escaped
          const req = data.request;                       // { Payload:{ events:[...] } }
          if (req) sniffBet("logger", JSON.stringify(req), null);
        } catch (e) {}
      });
      return _send.apply(this, [body]);
    }

    return _send.apply(this, [body]);
  };

  function fireMockPending() {
    if (!pendingXhr || !couponCode || !t1) return false;
    const mockBody = JSON.stringify({
      couponCode, aamsTicketID,
      couponDate: new Date().toISOString(),
      stake, confirmedStake: stake,
      statusCode: "P", isPending: false,
      couponTypeEnum: 0, potentialWin: 0.0, idCouponStatus: 0
    });
    Object.defineProperty(pendingXhr, "status",       { get: () => 200 });
    Object.defineProperty(pendingXhr, "readyState",   { get: () => 4 });
    Object.defineProperty(pendingXhr, "responseText", { get: () => mockBody });
    Object.defineProperty(pendingXhr, "response",     { get: () => mockBody });

    const t2 = performance.now();
    pendingXhr.dispatchEvent(new Event("readystatechange"));
    pendingXhr.dispatchEvent(new Event("load"));

    const totale = Math.round(t2 - t0);
    const insert = Math.round(t1 - t0);
    const pend   = Math.round(t2 - t1);
    addLog(insert, pend, totale, true);

    pendingXhr = null;
    couponCode = null;
    return true;
  }

  function addLog(insert, pend, totale, isMock) {
    log.unshift({
      orario: new Date().toTimeString().slice(0, 8),
      stake, insert, pend, totale, mock: isMock
    });
    if (log.length > 10) log.pop();
    saveState();
    if (ui) ui.onNewBet(log[0]);
    apiEvent("bet", {
      esito: "piazzata",
      stake,
      quote: (betCtx && betCtx.quote) || [],
      quotaTot: betCtx ? betCtx.quotaTot : null,
      vincita: betCtx ? betCtx.vincita : null,
      selezioni: (betCtx && betCtx.selezioni) || [],
      coupon: couponCode || null,
      retry: lastRetryAttempt || 0,
      insert, pend, totale, mock: isMock
    });
  }

  // trova il data-marketidlong del mercato "Prossimo Gol" cercando per nome nel DOM
  function findProssimoGolMarket() {
    const headers = document.querySelectorAll(".market-name, .market__name, .mn, [class*='market-title'], [class*='marketName']");
    for (const el of headers) {
      if (el.textContent.trim().toLowerCase().includes("prossimo gol")) {
        const mktEl = el.closest("[data-marketidlong]");
        if (mktEl) return mktEl.dataset.marketidlong;
      }
    }
    // fallback: cerca negli elementi che contengono Casa/Nessun Gol/Ospite come gruppo
    const allMkts = document.querySelectorAll("[data-marketidlong]");
    for (const mkt of allMkts) {
      const texts = [...mkt.querySelectorAll(".item--mercato")].map(e => e.textContent.trim().toLowerCase());
      if (texts.includes("casa") && texts.includes("ospite") && texts.includes("nessun gol")) {
        return mkt.dataset.marketidlong;
      }
    }
    return null;
  }

  // connection prewarming
  function prewarm() {
    fetch(API_ORIGIN + "/", { method: "HEAD", mode: "no-cors", cache: "no-store" }).catch(() => {});
  }
  prewarm();
  setInterval(prewarm, 25000);

  // click "umano" completo: mousedown→mouseup→click con coordinate reali. Angular
  // registra così l'interazione (un semplice .click() sintetico spesso non basta:
  // accende la grafica ma non lo stato interno del componente). Ritorna true se ha
  // cliccato qualcosa (per l'uso in catena: realClick(a) || realClick(b)).
  function realClick(el) {
    if (!el) return false;
    try {
      const r = el.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const opts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy };
      el.dispatchEvent(new PointerEvent("pointerdown", opts));
      el.dispatchEvent(new MouseEvent("mousedown", opts));
      el.dispatchEvent(new PointerEvent("pointerup", opts));
      el.dispatchEvent(new MouseEvent("mouseup", opts));
      el.dispatchEvent(new MouseEvent("click", opts));
      return true;
    } catch (e) {
      try { el.click(); return true; } catch (e2) { return false; }
    }
  }

  // ─────────────────── giocata rapida sempre attiva (1€) ───────────────────
  // Il sito Goldbet ha un toggle "Giocata Rapida": lo teniamo SEMPRE attivo e
  // forziamo l'importo a 1€. Angular ri-renderizza il componente, quindi la
  // funzione va richiamata periodicamente. Tutto in try/catch: se il toggle non
  // è in pagina esce senza errori e non tocca nulla del resto del plugin.
  function ensureFastPlay() {
    try {
      // 1) trova il checkbox del toggle "Giocata Rapida" (più selettori robusti)
      const checkbox =
        document.querySelector('.fast-play .fast-play-toggle input[type="checkbox"]') ||
        document.querySelector('.fast-play input[type="checkbox"]') ||
        document.querySelector('.fast-play-toggle input[type="checkbox"]') ||
        document.querySelector('app-scommesse-toggle input[type="checkbox"]');

      // se il toggle non è in pagina, esci silenziosamente
      if (!checkbox) return;

      // 2) se non è attivo, attivalo con una sequenza mouse REALE (Angular non
      //    registra un click() sintetico: l'UI si accende ma lo stato interno resta
      //    spento). realClick simula mousedown→mouseup→click come un utente vero,
      //    sullo slider/label che è l'elemento realmente cliccabile.
      if (!checkbox.checked) {
        const label  = checkbox.closest("label.toggle") ||
                       checkbox.closest(".fast-play-toggle") ||
                       checkbox.closest("label");
        const slider = (label && label.querySelector(".slider")) ||
                       document.querySelector(".fast-play .slider");
        // ordine di preferenza: slider (quello che l'utente vede/clicca) → label → checkbox
        realClick(slider) || realClick(label) || realClick(checkbox);
      }

      // 3) imposta l'importo a 1€ (solo se vuoto o diverso da "1")
      const amount =
        document.querySelector('.inputSelect euro-input input[type="text"]') ||
        document.querySelector('.inputSelect input[type="text"]') ||
        document.querySelector('.inputSelect .showCaret') ||
        document.querySelector('.fast-play euro-input input');

      if (amount) {
        const cur = (amount.value || "").trim();
        const target = String(fastStake);
        if (cur !== target) {
          amount.value = target;
          amount.dispatchEvent(new Event("input",  { bubbles: true }));
          amount.dispatchEvent(new Event("change", { bubbles: true }));
        }
      }
    } catch (e) {}
  }
  // AVVIO RITARDATO: il plugin gira a document_start, ma la Giocata Rapida va
  // attivata solo QUANDO la pagina (Angular) è pronta e il toggle esiste davvero —
  // altrimenti il click va a vuoto e resta "solo grafica". Aspettiamo il caricamento
  // completo + che il toggle compaia nel DOM, poi partiamo con il polling ogni 2s.
  function startFastPlayWhenReady() {
    let tries = 0;
    const kick = () => {
      tries++;
      const toggleReady = document.querySelector('.fast-play input[type="checkbox"], app-scommesse-toggle input[type="checkbox"]');
      if (toggleReady) {
        ensureFastPlay();
        setInterval(ensureFastPlay, 2000);
        return;
      }
      if (tries < 120) setTimeout(kick, 500);  // riprova fino a ~60s finché il toggle appare
      else setInterval(ensureFastPlay, 2000);  // fallback: parte comunque il polling
    };
    if (document.readyState === "complete") setTimeout(kick, 800);
    else window.addEventListener("load", () => setTimeout(kick, 800), { once: true });
  }
  startFastPlayWhenReady();

  // ─────────── auto-click "CONTINUA A GIOCARE" (popup gioco responsabile) ───────────
  // Quando compare il messaggio di interruzione con il bottone "CONTINUA A GIOCARE",
  // lo clicca da solo per non fermare la sessione. Cerca un .container--button (o
  // qualsiasi bottone/div cliccabile) il cui testo contiene "continua a giocare".
  function autoContinue() {
    try {
      const cands = document.querySelectorAll(
        '.container--button, button, [role="button"], .btn, a'
      );
      for (const el of cands) {
        const t = (el.textContent || "").trim().toLowerCase();
        if (t === "continua a giocare" || (t.includes("continua a giocare") && t.length < 40)) {
          realClick(el);
          return true;
        }
      }
    } catch (e) {}
    return false;
  }
  setInterval(autoContinue, 1500);

  // ───────────────────── hotkey: click quota per nome ─────────────────────
  // Cerca l'.item (dentro app-quota-dumb) il cui ".item--mercato span" ha come
  // testo il nome mercato richiesto ("Casa"/"Ospite") e lo clicca con realClick
  // (Angular: un .click() sintetico non basta). Ritorna true se ha cliccato.
  function clickQuotaByName(name) {
    try {
      const items = document.querySelectorAll(
        '.item.item-hover, app-quota-dumb .item, .single-quota-wrapper .item'
      );
      for (const it of items) {
        const span = it.querySelector('.item--mercato span');
        if (span && span.textContent.trim().toLowerCase() === name.toLowerCase()) {
          realClick(it);
          return true;
        }
      }
      return false;
    } catch (e) { return false; }
  }

  // etichetta leggibile per un event.key (" " → "Spazio", frecce → nome, …)
  function keyLabel(k) {
    if (k === null || k === undefined || k === "") return "—";
    if (k === " ") return "Spazio";
    if (k.length === 1) return k.toUpperCase();
    return k;  // "ArrowLeft", "Enter", "Escape", …
  }

  // siamo su una pagina evento live? (generico per tutti gli sport)
  function isLivePage() {
    try { return location.pathname.includes("/scommesse/live/"); }
    catch (e) { return false; }
  }

  // hook che la GUI registra per aggiornare le etichette dei tasti dopo un REC
  let onHotkeyRecorded = null;

  // ───────────────────── listener globale tastiera ─────────────────────
  // Sempre attivo a livello di document. In modalità REGISTRAZIONE cattura il
  // tasto premuto (senza bettare). Altrimenti, se hotkeyEnabled + pagina live +
  // non stiamo scrivendo in un campo, clicca la quota Casa/Ospite.
  document.addEventListener("keydown", function (e) {
    try {
      // 1) modalità registrazione: cattura il tasto, non bettare
      if (recordingFor) {
        // ignora i modificatori "puri" per non registrare Shift/Ctrl/Alt da soli
        if (e.key === "Shift" || e.key === "Control" || e.key === "Alt" || e.key === "Meta") return;
        e.preventDefault();
        e.stopPropagation();
        const which = recordingFor;
        recordingFor = null;
        if (which === "casa") {
          keyCasa = e.key;
          try { localStorage.setItem(LS_KEY_CASA, keyCasa); } catch (er) {}
        } else {
          keyOspite = e.key;
          try { localStorage.setItem(LS_KEY_OSPITE, keyOspite); } catch (er) {}
        }
        if (typeof onHotkeyRecorded === "function") onHotkeyRecorded(which);
        return;
      }

      // 2) betting via hotkey
      if (!hotkeyEnabled) return;
      if (!isLivePage()) return;

      // non intercettare se l'utente sta scrivendo in un campo
      const ae = document.activeElement;
      const tag = ae && ae.tagName ? ae.tagName.toUpperCase() : "";
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || (ae && ae.isContentEditable)) return;

      let hit = false;
      if (keyCasa !== null && e.key === keyCasa)   hit = clickQuotaByName("Casa")   || true;
      else if (keyOspite !== null && e.key === keyOspite) hit = clickQuotaByName("Ospite") || true;

      if (hit) { e.preventDefault(); e.stopPropagation(); }
    } catch (er) {}
  }, true);

  // ───────────────────────────── GUI overlay ───────────────────────
  function buildUI() {
    const host = document.createElement("div");
    host.id = "gbfb-host";
    host.style.cssText = "position:fixed!important;top:0!important;right:0!important;" +
      "z-index:2147483647!important;width:0;height:0;pointer-events:none;";
    (document.body || document.documentElement).appendChild(host);
    const root = host.attachShadow({ mode: "open" });

    root.innerHTML = `
      <style>
        :host { all: initial; }
        * { box-sizing: border-box; margin: 0; padding: 0;
            font-family: -apple-system, "Segoe UI", system-ui, sans-serif; }
        .wrap { position: fixed; top: 14px; right: 14px; width: 300px;
          z-index: 2147483647; pointer-events: auto;
          background: ${T.bg}; color: ${T.txt};
          border: 1px solid ${T.border}; border-radius: 14px;
          box-shadow: 0 14px 44px rgba(0,0,0,.6); overflow: hidden; transition: all .2s; }
        .wrap.min { height: 50px; }
        .wrap.min .body { display: none; }

        .head { display: flex; align-items: center; gap: 10px; padding: 13px 14px; cursor: move;
          background: linear-gradient(135deg, ${T.bg}, ${T.bg2});
          border-bottom: 1px solid ${T.border}; user-select: none; }
        .logo { width: 30px; height: 30px; border-radius: 8px; background: ${T.accent};
          color: ${T.logoTxt}; display: flex; align-items: center; justify-content: center;
          font-size: 17px; font-weight: 900; flex-shrink: 0;
          box-shadow: 0 3px 12px ${T.accentShadow}; }
        .title { font-size: 14px; font-weight: 800; color: #fff; flex: 1; line-height: 1.05; }
        .title small { display: block; font-size: 9px; color: ${T.accent}; font-weight: 700; letter-spacing: .5px; }
        .hbtn { width: 24px; height: 24px; border-radius: 6px; border: 1px solid ${T.border};
          background: ${T.box}; color: ${T.muted}; cursor: pointer; font-size: 12px;
          display: flex; align-items: center; justify-content: center; }
        .hbtn:hover { color: ${T.accent}; border-color: ${T.accent}; }
        .hbtn.stop { color: #e85d5d; border-color: #5a2230; background: #2a1418; font-size: 11px; font-weight: 800; }
        .hbtn.stop:hover { color: #fff; background: #e85d5d; border-color: #e85d5d; }

        .smk-wrap { display: flex; flex-direction: column; align-items: center; gap: 2px; flex-shrink: 0; }
        .smk-dot { width: 10px; height: 10px; border-radius: 50%;
          background: #3a3a5c; transition: background .4s, box-shadow .4s; }
        .smk-dot.green { background: #6fd36f; box-shadow: 0 0 6px #6fd36f; }
        .smk-dot.red   { background: #e85d5d; box-shadow: 0 0 8px #e85d5d;
          animation: pulse-red .8s ease-in-out infinite; }
        @keyframes pulse-red {
          0%,100% { box-shadow: 0 0 4px #e85d5d; }
          50%      { box-shadow: 0 0 14px #e85d5d; }
        }
        .smk-label { font-size: 7px; font-weight: 800; color: #e85d5d; text-align: center;
          letter-spacing: .3px; max-width: 54px; line-height: 1.2; display: none; }
        .smk-label.visible { display: block; }

        .body { padding: 14px; }

        .switch-row { display: flex; align-items: center; justify-content: space-between;
          background: ${T.box}; border: 1px solid ${T.border}; border-radius: 11px; padding: 12px 14px; }
        .switch-label { font-size: 13px; font-weight: 700; color: #fff; }
        .switch { position: relative; width: 46px; height: 25px; flex-shrink: 0; }
        .switch input { display: none; }
        .slider { position: absolute; inset: 0; background: ${T.border}; border: 1px solid ${T.border};
          border-radius: 25px; cursor: pointer; transition: all .3s; }
        .slider::before { content: ""; position: absolute; width: 17px; height: 17px; left: 4px; top: 3px;
          background: ${T.muted}; border-radius: 50%; transition: all .3s; }
        input:checked + .slider { background: ${T.accent}; border-color: ${T.accent}; }
        input:checked + .slider::before { transform: translateX(21px); background: ${T.logoTxt}; }

        .stake-row { display: flex; align-items: center; justify-content: space-between;
          background: ${T.box}; border: 1px solid ${T.border}; border-radius: 11px;
          padding: 12px 14px; margin-top: 9px; }
        .stake-label { font-size: 13px; font-weight: 700; color: #fff; }
        #stakeInput { width: 84px; padding: 7px 9px; border-radius: 8px;
          border: 1px solid ${T.border}; background: ${T.bg}; color: ${T.accent};
          font-size: 14px; font-weight: 800; text-align: right;
          font-variant-numeric: tabular-nums; }
        #stakeInput:focus { outline: none; border-color: ${T.accent}; }

        .hotkey-panel { background: ${T.box}; border: 1px solid ${T.border}; border-radius: 11px;
          padding: 12px 14px; margin-top: 9px; }
        .hotkey-row { display: flex; align-items: center; justify-content: space-between; }
        .hotkey-label { font-size: 13px; font-weight: 700; color: #fff; }
        .hotkey-keys { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; }
        .hk-btn { font-size: 11px; font-weight: 700; color: ${T.txt}; cursor: pointer;
          background: ${T.bg}; border: 1px solid ${T.border}; border-radius: 8px; padding: 8px 6px;
          text-align: center; transition: all .2s; }
        .hk-btn:hover { border-color: ${T.accent}; color: ${T.accent}; }
        .hk-btn b { color: ${T.accent}; font-weight: 800; }
        .hk-btn.recording { border-color: ${T.accent};
          background: ${T.accentDim}; color: ${T.accent};
          animation: hk-pulse .8s ease-in-out infinite; }
        @keyframes hk-pulse { 0%,100% { opacity: 1; } 50% { opacity: .55; } }
        .hotkey-hint { font-size: 9px; color: ${T.muted}; text-align: center; margin-top: 9px;
          letter-spacing: .3px; }

        /* ── MULTIBOOK (replica di gruppo) ── */
        .mb-panel { background: ${T.box}; border: 1px solid ${T.border}; border-radius: 11px;
          padding: 12px 14px; margin-top: 9px; }
        .mb-row { display: flex; align-items: center; justify-content: space-between; }
        .mb-title { font-size: 13px; font-weight: 700; color: #fff; }
        .mb-books { display: flex; flex-direction: column; gap: 6px; margin-top: 10px; }
        .mb-book { display: flex; align-items: center; gap: 8px;
          background: ${T.bg}; border: 1px solid ${T.border}; border-radius: 8px; padding: 7px 9px; }
        .mb-book input[type="checkbox"] { width: 15px; height: 15px; flex-shrink: 0;
          accent-color: ${T.accent}; cursor: pointer; margin: 0; }
        .mb-book .mb-name { font-size: 11px; font-weight: 700; color: ${T.txt}; flex: 1;
          text-transform: capitalize; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .mb-book .mb-name .mb-cur { color: ${T.muted}; font-weight: 600; font-size: 9px;
          text-transform: none; margin-left: 4px; }
        .mb-book .mb-cbx-spacer { width: 15px; flex-shrink: 0; }
        .mb-status { font-size: 8px; font-weight: 800; padding: 3px 6px; border-radius: 5px;
          flex-shrink: 0; letter-spacing: .3px; white-space: nowrap; }
        .mb-status.fresh   { background: rgba(111,211,111,.15); color: #6fd36f; }
        .mb-status.expired { background: rgba(232,93,93,.15);  color: #e85d5d; }
        .mb-status.none    { background: ${T.boxAlt}; color: ${T.muted}; }
        .mb-add { display: flex; gap: 6px; margin-top: 10px; }
        .mb-add input[type="text"] { flex: 1; min-width: 0; padding: 7px 9px; border-radius: 8px;
          border: 1px solid ${T.border}; background: ${T.bg}; color: ${T.txt}; font-size: 11px; }
        .mb-add input[type="text"]::placeholder { color: ${T.muted}; }
        .mb-add input[type="text"]:focus { outline: none; border-color: ${T.accent}; }
        .mb-btn { font-size: 12px; font-weight: 800; color: ${T.txt}; cursor: pointer;
          background: ${T.bg}; border: 1px solid ${T.border}; border-radius: 8px; padding: 7px 12px;
          transition: all .2s; flex-shrink: 0; }
        .mb-btn:hover { border-color: ${T.accent}; color: ${T.accent}; }
        .mb-btn.wide { width: 100%; margin-top: 9px; padding: 9px; font-size: 11px;
          background: ${T.accentDim}; color: ${T.accent}; border-color: ${T.accent}; }
        .mb-btn.wide:hover { background: ${T.accent}; color: ${T.logoTxt}; }
        .mb-hint { font-size: 9px; color: ${T.muted}; text-align: center; margin-top: 9px;
          letter-spacing: .3px; line-height: 1.4; }

        .status { text-align: center; font-size: 10px; font-weight: 700; padding: 7px; border-radius: 8px;
          margin: 9px 0 13px; letter-spacing: .3px; }
        .status.on  { background: ${T.accentDim}; color: ${T.accent}; }
        .status.off { background: ${T.box}; color: ${T.muted}; }

        .crono-box { background: ${T.box}; border: 1px solid ${T.border}; border-radius: 12px;
          padding: 18px; text-align: center; position: relative; overflow: hidden; }
        .crono-box::before { content: ""; position: absolute; top: 0; left: 0; right: 0; height: 3px;
          background: linear-gradient(90deg, transparent, ${T.accent}, transparent); }
        .crono-label { font-size: 9px; color: ${T.muted}; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 8px; }
        .crono-val { font-size: 48px; font-weight: 800; font-variant-numeric: tabular-nums;
          color: ${T.accent}; line-height: 1; }
        .crono-val .u { font-size: 16px; font-weight: 500; color: ${T.muted}; margin-left: 5px; }
        .crono-val.run { color: #6fd36f; }
        .crono-detail { font-size: 10px; color: ${T.muted}; margin-top: 9px; }

        .mini { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; }
        .mini .box { background: ${T.box}; border: 1px solid ${T.border}; border-radius: 9px; padding: 10px; text-align: center; }
        .mini .v { font-size: 20px; font-weight: 800; color: ${T.accent}; }
        .mini .v.green { color: #6fd36f; }
        .mini .l { font-size: 8px; color: ${T.muted}; text-transform: uppercase; letter-spacing: 1px; margin-top: 2px; }

        .tabs { display: flex; gap: 4px; margin: 12px 0 0; }
        .tab { flex: 1; text-align: center; padding: 7px 0; font-size: 10px; font-weight: 700;
          color: ${T.muted}; cursor: pointer; border-radius: 7px; background: ${T.box}; border: 1px solid ${T.border};
          text-transform: uppercase; letter-spacing: .5px; }
        .tab.active { color: ${T.accent}; border-color: ${T.accent}; }

        .pane { display: none; margin-top: 10px; }
        .pane.active { display: block; }

        .loghead { display: flex; justify-content: space-between; align-items: center; margin-bottom: 7px; }
        .loghead span { font-size: 9px; color: ${T.muted}; text-transform: uppercase; letter-spacing: 1px; }
        .loghead button { font-size: 9px; background: ${T.box}; color: ${T.muted}; border: 1px solid ${T.border};
          padding: 3px 9px; border-radius: 5px; cursor: pointer; font-weight: 700; }
        .loghead button:hover { color: ${T.accent}; border-color: ${T.accent}; }
        .log-list { display: flex; flex-direction: column; gap: 4px; max-height: 220px; overflow-y: auto; }
        .log-list::-webkit-scrollbar { width: 6px; }
        .log-list::-webkit-scrollbar-thumb { background: ${T.border}; border-radius: 3px; }
        .li { background: ${T.box}; border: 1px solid ${T.border}; border-radius: 7px; padding: 8px 10px;
          display: grid; grid-template-columns: 52px 1fr 1fr 38px; align-items: center; font-size: 11px; gap: 4px; }
        .li .o { color: ${T.muted}; font-size: 10px; }
        .li .i { color: ${T.accent}; text-align: center; font-weight: 600; }
        .li .t { color: #fff; text-align: center; font-weight: 800; }
        .li .b { font-size: 8px; font-weight: 800; padding: 2px 4px; border-radius: 3px; text-align: center; }
        .li .b.on { background: ${T.accentDim}; color: ${T.accent}; }
        .li .b.off { background: ${T.boxAlt}; color: ${T.muted}; }
        .empty { text-align: center; color: ${T.boxAlt}; font-size: 11px; padding: 18px 0; }

        .stat-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
        .sbox { background: ${T.box}; border: 1px solid ${T.border}; border-radius: 9px; padding: 12px; text-align: center; }
        .sbox .v { font-size: 22px; font-weight: 800; color: ${T.accent}; }
        .sbox .v.green { color: #6fd36f; } .sbox .v.white { color: #fff; }
        .sbox .l { font-size: 8px; color: ${T.muted}; text-transform: uppercase; letter-spacing: 1px; margin-top: 3px; }
        .swide { background: ${T.box}; border: 1px solid ${T.border}; border-radius: 9px; padding: 9px 12px;
          margin-top: 8px; display: flex; justify-content: space-between; align-items: center; }
        .swide .l { font-size: 10px; color: ${T.muted}; } .swide .v { font-size: 13px; font-weight: 800; color: ${T.accent}; }

        /* login */
        .login { text-align: center; padding: 6px 2px; }
        .login .ico { font-size: 32px; margin-bottom: 8px; }
        .login h3 { font-size: 14px; color: #fff; margin-bottom: 2px; }
        .login p { font-size: 11px; color: ${T.muted}; margin-bottom: 16px; }
        .login input { width: 100%; padding: 10px 12px; border-radius: 9px; border: 1px solid ${T.border};
          background: ${T.bg}; color: ${T.txt}; font-size: 13px; margin-bottom: 9px; }
        .login input::placeholder { color: ${T.muted}; }
        .login .gobtn { width: 100%; padding: 11px; border-radius: 9px; border: none;
          background: ${T.accent}; color: ${T.logoTxt}; font-weight: 800; font-size: 14px; cursor: pointer; }
        .login .gobtn:hover { filter: brightness(1.08); }
        .login .gobtn:disabled { opacity: .6; cursor: default; }
        .login .msg { font-size: 11px; min-height: 16px; margin-top: 10px; }
        .login .msg.err { color: #e85d5d; }
        .login .msg.warn { color: ${T.accent}; }
        .userbar { display: flex; align-items: center; gap: 6px; font-size: 10px; color: ${T.muted};
          margin-bottom: 10px; padding: 7px 10px; background: ${T.box}; border: 1px solid ${T.border}; border-radius: 8px; }
        .userbar b { color: #6fd36f; }
        .userbar .out { margin-left: auto; cursor: pointer; color: ${T.muted}; font-weight: 700; }
        .userbar .out:hover { color: #e85d5d; }
      </style>

      <div class="wrap" id="wrap">
        <div class="head" id="head">
          <div class="logo">⚡</div>
          <div class="title">${SITE.name} FAST BET<small>v6.12 · LICENSED</small></div>
          <div class="smk-wrap">
            <div class="smk-dot" id="smkDot"></div>
            <div class="smk-label" id="smkLabel"></div>
          </div>
          <div class="hbtn stop" id="stop" title="Reset / ferma cronometro" style="display:none">⏹</div>
          <div class="hbtn" id="min">—</div>
        </div>

        <!-- VISTA LOGIN -->
        <div class="body" id="loginView">
          <div class="login">
            <div class="ico">🔒</div>
            <h3>Accesso richiesto</h3>
            <p>Inserisci le credenziali della tua licenza</p>
            <input type="email" id="liEmail" placeholder="email" autocomplete="off">
            <input type="password" id="liPass" placeholder="password" autocomplete="off">
            <button class="gobtn" id="liBtn">Accedi</button>
            <div class="msg" id="liMsg"></div>
          </div>
        </div>

        <!-- VISTA BLOCCO (account Goldbet mancante o non autorizzato) -->
        <div class="body" id="blockView" style="display:none">
          <div class="login">
            <div class="ico" id="blkIco">⛔</div>
            <h3 id="blkTitle">Accesso bloccato</h3>
            <p id="blkMsg" style="margin-bottom:0">—</p>
          </div>
        </div>

        <!-- VISTA PRINCIPALE -->
        <div class="body" id="mainView" style="display:none">
          <div class="userbar">
            <span>licenza: <b id="ubEmail">—</b></span>
            <span>GB: <b id="ubGb">—</b></span>
            <span class="out" id="ubOut">esci</span>
          </div>
          <div class="switch-row">
            <span class="switch-label">Mock pendingBet</span>
            <label class="switch"><input type="checkbox" id="tg"><span class="slider"></span></label>
          </div>
          <div class="stake-row">
            <span class="stake-label">Importo puntata (€)</span>
            <input type="number" id="stakeInput" min="0.05" step="0.05" value="1">
          </div>
          <div class="hotkey-panel">
            <div class="hotkey-row">
              <span class="hotkey-label">⌨️ Hotkey bet</span>
              <label class="switch"><input type="checkbox" id="hotkeyToggle"><span class="slider"></span></label>
            </div>
            <div class="hotkey-keys">
              <button class="hk-btn" id="recCasa">REC Casa: <b id="keyCasaLbl">—</b></button>
              <button class="hk-btn" id="recOspite">REC Ospite: <b id="keyOspiteLbl">—</b></button>
            </div>
            <div class="hotkey-hint" id="hotkeyHint">assegna i tasti e attiva il toggle</div>
          </div>

          <div class="mb-panel">
            <div class="mb-row">
              <span class="mb-title">🔗 MULTIBOOK — replica sul gruppo</span>
              <label class="switch"><input type="checkbox" id="mbReplica"><span class="slider"></span></label>
            </div>
            <div class="mb-books" id="mbBooks"><!-- righe bookmaker generate via JS --></div>
            <div class="mb-add">
              <input type="text" id="mbNewDomain" placeholder="aggiungi dominio (es. brand.it)">
              <button class="mb-btn" id="mbAddBtn">+</button>
            </div>
            <button class="mb-btn wide" id="mbLoginBtn">🔑 Collega bookmaker (login)</button>
            <div class="mb-hint" id="mbHint">attiva la replica e scegli i bookmaker</div>
          </div>

          <div class="status off" id="st">OFF — timing reale (~7 sec)</div>

          <div class="tabs">
            <div class="tab active" data-p="dash">Dashboard</div>
            <div class="tab" data-p="log">Log</div>
            <div class="tab" data-p="smk">SMK</div>
            <div class="tab" data-p="stats">Stats</div>
          </div>

          <div class="pane active" id="pane-dash">
            <div class="crono-box">
              <div class="crono-label">ultima puntata</div>
              <div class="crono-val" id="crono">--</div>
              <div class="crono-detail" id="cdet">in attesa di una giocata…</div>
            </div>
            <div class="mini">
              <div class="box"><div class="v" id="d-med">--</div><div class="l">media ms</div></div>
              <div class="box"><div class="v green" id="d-rec">--</div><div class="l">record ms</div></div>
            </div>
          </div>

          <div class="pane" id="pane-log">
            <div class="loghead"><span>ultime 10 giocate</span><button id="clr">Pulisci</button></div>
            <div class="log-list" id="loglist"><div class="empty">Nessuna giocata</div></div>
          </div>

          <div class="pane" id="pane-smk">
            <div class="loghead">
              <span>durata sospensioni (rosso→verde)</span>
              <button id="clrSmk">Pulisci</button>
            </div>
            <div class="mini" style="margin-bottom:8px">
              <div class="box"><div class="v" id="smk-cnt">0</div><div class="l">sospensioni</div></div>
              <div class="box"><div class="v green" id="smk-avg">--</div><div class="l">durata media ms</div></div>
            </div>
            <div class="log-list" id="smklist"><div class="empty">Nessuna sospensione registrata</div></div>
          </div>

          <div class="pane" id="pane-stats">
            <div class="stat-grid">
              <div class="sbox"><div class="v white" id="s-tot">0</div><div class="l">puntate</div></div>
              <div class="sbox"><div class="v green" id="s-rec">--</div><div class="l">record ms</div></div>
              <div class="sbox"><div class="v" id="s-med">--</div><div class="l">media ms</div></div>
              <div class="sbox"><div class="v white" id="s-stk">€0</div><div class="l">stake tot</div></div>
            </div>
            <div class="swide"><span class="l">Peggiore</span><span class="v" id="s-wor" style="color:#e85d5d">--</span></div>
            <div class="swide"><span class="l">Mock ON / OFF</span><span class="v" id="s-mon">-- / --</span></div>
            <div class="swide"><span class="l">Risparmio medio</span><span class="v" id="s-sav" style="color:#6fa8ff">--</span></div>
          </div>
        </div>
      </div>
    `;

    const $ = (s) => root.querySelector(s);
    const wrap = $("#wrap"), crono = $("#crono"), cdet = $("#cdet");
    const tg = $("#tg"), st = $("#st"), loglist = $("#loglist");

    function showLogin(msg, cls) {
      $("#loginView").style.display = "block";
      $("#blockView").style.display = "none";
      $("#mainView").style.display = "none";
      $("#stop").style.display = "none";
      if (msg) { $("#liMsg").textContent = msg; $("#liMsg").className = "msg " + (cls || ""); }
    }
    function showBlocked(ico, title, msg) {
      $("#loginView").style.display = "none";
      $("#blockView").style.display = "block";
      $("#mainView").style.display = "none";
      $("#stop").style.display = "none";
      $("#blkIco").textContent = ico;
      $("#blkTitle").textContent = title;
      $("#blkMsg").textContent = msg;
    }
    function showMain() {
      $("#loginView").style.display = "none";
      $("#blockView").style.display = "none";
      $("#mainView").style.display = "block";
      $("#stop").style.display = "flex";
      $("#ubEmail").textContent = licEmail || "—";
      $("#ubGb").textContent = gbUser || "—";
      startSmkMonitor();
    }

    function showGbMissing() {
      showBlocked("🔗", "Login Goldbet richiesto",
        "Nessun account Goldbet rilevato: accedi al tuo conto Goldbet. " +
        "Fast Bet si apre solo con un account autorizzato dalla licenza.");
    }
    function showGbDenied() {
      showBlocked("⛔", "Account Goldbet non autorizzato",
        `L'account "${gbUser}" non è associato a questa licenza. ` +
        "Contatta il fornitore per farlo aggiungere.");
    }

    // ── gate centrale: decide la vista in base a account Goldbet + licenza ──
    async function refreshGate() {
      if (!gbUser) { licActive = false; showGbMissing(); return; }
      if (!licToken) { showLogin("", ""); return; }
      const r = await apiCheck(licToken);
      if (r.offline) {
        // backend momentaneamente irraggiungibile: mantieni lo stato corrente
        if (!licActive) showLogin("Backend offline — riprova", "err");
        return;
      }
      if (!r.ok) {
        if (r.error === "Sessione non valida") {
          licToken = null; licEmail = null; licActive = false; saveLicense();
          showLogin("Sessione terminata dall'amministratore", "warn");
        } else {
          licActive = false;
          showLogin(r.error || "Errore backend", "err");
        }
        return;
      }
      if (Array.isArray(r.commands)) handleCommands(r.commands);
      if (r.update) showUpdateBanner(r.update);
      if (!r.gb_allowed) { licActive = false; showGbDenied(); return; }
      if (!r.active) {
        licActive = false;
        showLogin("Licenza non attiva. Contatta il fornitore.", "warn");
        return;
      }
      if (!licToken) return; // un comando remoto (logout) ha appena chiuso la sessione
      licActive = true;
      showMain();
    }

    async function doLogin() {
      const email = $("#liEmail").value.trim();
      const password = $("#liPass").value;
      const btn = $("#liBtn");
      if (!gbUser) { showGbMissing(); return; }
      if (!email || !password) { $("#liMsg").textContent = "Inserisci email e password"; $("#liMsg").className = "msg err"; return; }
      btn.disabled = true; btn.textContent = "Accesso…";
      try {
        const r = await apiLogin(email, password);
        if (!r.ok) { showLogin(r.error || "Credenziali non valide", "err"); }
        else if (!r.gb_allowed) {
          licToken = r.token; licEmail = r.email; licActive = false; saveLicense();
          showGbDenied();
        }
        else if (!r.active) {
          licToken = r.token; licEmail = r.email; licActive = false; saveLicense();
          showLogin("Licenza non attiva. Contatta il fornitore.", "warn");
        } else {
          licToken = r.token; licEmail = r.email; licActive = true; saveLicense();
          showMain();
        }
      } catch (e) {
        showLogin("Backend non raggiungibile", "err");
      }
      btn.disabled = false; btn.textContent = "Accedi";
    }

    $("#liBtn").addEventListener("click", doLogin);
    $("#liPass").addEventListener("keydown", (e) => { if (e.key === "Enter") doLogin(); });
    $("#ubOut").addEventListener("click", () => {
      doLogout();
      if (smkTimer) { clearInterval(smkTimer); smkTimer = null; }
      if (ui) ui.setSmk("gray");
      showLogin("", ""); $("#liEmail").value=""; $("#liPass").value="";
    });

    (async function initLicense() {
      showBlocked("⏳", "Rilevamento account Goldbet…",
        "Attendi qualche secondo: sto leggendo il nome utente dalla pagina.");
      // poll rapido all'avvio: Angular renderizza l'header dopo qualche secondo
      for (let i = 0; i < 24 && !gbUser; i++) {
        gbUser = readGbUser();
        if (gbUser) break;
        await new Promise(res => setTimeout(res, 500));
      }
      refreshGate();
    })();

    // se l'account Goldbet cambia (login/logout sul sito) → rivaluta il gate
    setInterval(() => {
      const u = readGbUser();
      if (u !== gbUser) { gbUser = u; refreshGate(); }
    }, 2000);

    // ricontrolla la licenza ogni 60s (disattivazione, account GB, comandi remoti, update)
    setInterval(() => { if (licToken) refreshGate(); }, 60000);

    root.querySelectorAll(".tab").forEach(tab => {
      tab.addEventListener("click", () => {
        root.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
        root.querySelectorAll(".pane").forEach(p => p.classList.remove("active"));
        tab.classList.add("active");
        $("#pane-" + tab.dataset.p).classList.add("active");
      });
    });

    $("#min").addEventListener("click", () => {
      wrap.classList.toggle("min");
      $("#min").textContent = wrap.classList.contains("min") ? "▢" : "—";
    });

    $("#stop").addEventListener("click", () => {
      if (cronoTimer) { clearInterval(cronoTimer); cronoTimer = null; }
      t0 = 0; t1 = 0; couponCode = null; pendingXhr = null;
      if (log.length) showResult(log[0]); else resultIdle();
      const b = $("#stop"); const old = b.textContent; b.textContent = "✓";
      setTimeout(() => { b.textContent = old; }, 800);
    });

    (function () {
      const head = $("#head");
      let drag = false, sx = 0, sy = 0, ox = 0, oy = 0;
      head.addEventListener("mousedown", (e) => {
        if (e.target.id === "min") return;
        drag = true;
        const r = wrap.getBoundingClientRect();
        sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top;
        wrap.style.right = "auto"; wrap.style.left = ox + "px"; wrap.style.top = oy + "px";
        e.preventDefault();
      });
      window.addEventListener("mousemove", (e) => {
        if (!drag) return;
        wrap.style.left = (ox + e.clientX - sx) + "px";
        wrap.style.top = Math.max(0, oy + e.clientY - sy) + "px";
      });
      window.addEventListener("mouseup", () => { drag = false; });
    })();

    function setSwitch(on) {
      tg.checked = on;
      st.textContent = on ? "ON — pendingBet istantaneo" : "OFF — timing reale (~7 sec)";
      st.className = "status " + (on ? "on" : "off");
    }
    tg.addEventListener("change", () => {
      mockEnabled = tg.checked; saveState(); setSwitch(mockEnabled);
    });
    setSwitch(mockEnabled);

    // importo puntata → collegato a fastStake (usato da ensureFastPlay)
    try {
      const stakeInput = $("#stakeInput");
      if (stakeInput) {
        stakeInput.value = fastStake;
        const onStake = () => {
          const v = parseFloat(stakeInput.value);
          if (v > 0) {
            fastStake = v;
            try { localStorage.setItem(LS_STAKE, String(v)); } catch (e) {}
          }
        };
        stakeInput.addEventListener("input", onStake);
        stakeInput.addEventListener("change", onStake);
      }
    } catch (e) {}

    // ───────────────────── wiring pannello hotkey ─────────────────────
    try {
      const hkToggle   = $("#hotkeyToggle");
      const recCasaBtn = $("#recCasa");
      const recOspBtn  = $("#recOspite");
      const keyCasaLbl = $("#keyCasaLbl");
      const keyOspLbl  = $("#keyOspiteLbl");
      const hotkeyHint = $("#hotkeyHint");

      function refreshHotkeyLabels() {
        if (keyCasaLbl) keyCasaLbl.textContent = keyLabel(keyCasa);
        if (keyOspLbl)  keyOspLbl.textContent  = keyLabel(keyOspite);
      }
      refreshHotkeyLabels();

      if (hkToggle) {
        hkToggle.checked = hotkeyEnabled;
        hkToggle.addEventListener("change", () => {
          hotkeyEnabled = hkToggle.checked;
          try { localStorage.setItem(LS_HOTKEY, hotkeyEnabled ? "1" : "0"); } catch (er) {}
          if (hotkeyHint) {
            hotkeyHint.textContent = hotkeyEnabled
              ? "attivo: su una pagina live premi i tasti per bettare"
              : "assegna i tasti e attiva il toggle";
          }
        });
      }

      if (recCasaBtn) {
        recCasaBtn.addEventListener("click", () => {
          recordingFor = "casa";
          recCasaBtn.classList.add("recording");
          if (recOspBtn) recOspBtn.classList.remove("recording");
          if (hotkeyHint) hotkeyHint.textContent = "premi un tasto per CASA…";
        });
      }
      if (recOspBtn) {
        recOspBtn.addEventListener("click", () => {
          recordingFor = "ospite";
          recOspBtn.classList.add("recording");
          if (recCasaBtn) recCasaBtn.classList.remove("recording");
          if (hotkeyHint) hotkeyHint.textContent = "premi un tasto per OSPITE…";
        });
      }

      // il listener globale keydown chiama questo dopo aver registrato un tasto
      onHotkeyRecorded = (which) => {
        refreshHotkeyLabels();
        if (recCasaBtn) recCasaBtn.classList.remove("recording");
        if (recOspBtn)  recOspBtn.classList.remove("recording");
        if (hotkeyHint) {
          const lbl = keyLabel(which === "casa" ? keyCasa : keyOspite);
          hotkeyHint.textContent =
            `tasto ${which === "casa" ? "CASA" : "OSPITE"} = "${lbl}"` +
            (hotkeyEnabled ? "" : " · attiva il toggle per usarlo");
        }
      };
    } catch (e) {}

    // ───────────────────── MULTIBOOK (replica di gruppo) ─────────────────────
    // La finestra di validità di un token auth prima che vada considerato "scaduto".
    const MB_FRESH_MS = 19 * 60 * 1000;   // 19 minuti
    const MB_FIXED    = ["goldbet", "lottomatica", "planetwin365"];
    const mbBooksEl   = $("#mbBooks");
    const mbHintEl    = $("#mbHint");

    // etichetta leggibile del bookmaker (nomi noti dalla mappa, altrimenti il dominio)
    function mbLabel(bk) {
      const known = { goldbet: "Goldbet", lottomatica: "Lottomatica", planetwin365: "Planetwin365" };
      return known[bk] || bk;
    }

    // calcola il badge stato { cls, txt } da { ts, hasAuth }
    function mbStatusBadge(info) {
      try {
        if (info && info.hasAuth && info.ts) {
          const age = Date.now() - info.ts;
          if (age < MB_FRESH_MS) {
            const min = Math.max(1, Math.ceil((MB_FRESH_MS - age) / 60000));
            return { cls: "fresh", txt: "✓ " + min + "min" };
          }
          return { cls: "expired", txt: "scaduto — rilogga" };
        }
      } catch (e) {}
      return { cls: "none", txt: "non collegato" };
    }

    // aggiorna LS_ACTIVE_BOOKMAKERS con i checkbox spuntati correnti
    function mbSaveActive() {
      try {
        if (!mbBooksEl) return;
        const active = [];
        mbBooksEl.querySelectorAll('input[type="checkbox"][data-bk]').forEach(cb => {
          if (cb.checked) active.push(cb.dataset.bk);
        });
        localStorage.setItem(LS_ACTIVE_BOOKMAKERS, JSON.stringify(active));
      } catch (e) {}
    }

    async function renderMultibook() {
      if (!mbBooksEl) return;
      try {
        // stato auth + domini custom dal bridge (entrambi possono tornare null)
        let authStatus = {}, customDomains = [];
        try {
          const a = await bridgeRequest("GET_AUTH_STATUS");
          if (a && a.status) authStatus = a.status;
        } catch (e) {}
        try {
          const d = await bridgeRequest("GET_CUSTOM_DOMAINS");
          if (d && Array.isArray(d.domains)) customDomains = d.domains;
        } catch (e) {}

        const active = getActiveExtraBookmakers();
        // lista completa senza duplicati (fissi + custom), preservando l'ordine
        const list = [];
        MB_FIXED.concat(customDomains).forEach(bk => {
          if (bk && list.indexOf(bk) === -1) list.push(bk);
        });

        mbBooksEl.innerHTML = list.map(bk => {
          const isCurrent = (bk === BOOKMAKER);
          const badge = mbStatusBadge(authStatus[bk]);
          const checked = active.indexOf(bk) !== -1 ? "checked" : "";
          const cbx = isCurrent
            ? '<span class="mb-cbx-spacer"></span>'
            : `<input type="checkbox" data-bk="${bk}" ${checked}>`;
          const cur = isCurrent ? '<span class="mb-cur">(questa scheda)</span>' : "";
          return `<div class="mb-book">
              ${cbx}
              <span class="mb-name">${mbLabel(bk)}${cur}</span>
              <span class="mb-status ${badge.cls}">${badge.txt}</span>
            </div>`;
        }).join("");

        // wiring dei checkbox appena renderizzati
        mbBooksEl.querySelectorAll('input[type="checkbox"][data-bk]').forEach(cb => {
          cb.addEventListener("change", mbSaveActive);
        });
      } catch (e) {}
    }

    try {
      const mbReplica  = $("#mbReplica");
      const mbAddBtn   = $("#mbAddBtn");
      const mbNewDom   = $("#mbNewDomain");
      const mbLoginBtn = $("#mbLoginBtn");

      function mbUpdateHint() {
        if (!mbHintEl) return;
        mbHintEl.textContent = isGroupReplicaEnabled()
          ? "replica ATTIVA — la scommessa verrà rigiocata sui bookmaker spuntati"
          : "replica disattivata — gioca solo su questa scheda";
      }

      if (mbReplica) {
        mbReplica.checked = isGroupReplicaEnabled();
        mbReplica.addEventListener("change", () => {
          try { localStorage.setItem(LS_GROUP_REPLICA, mbReplica.checked ? "1" : "0"); } catch (e) {}
          mbUpdateHint();
          renderMultibook();
        });
      }
      mbUpdateHint();

      if (mbAddBtn && mbNewDom) {
        const doAdd = async () => {
          try {
            const dom = (mbNewDom.value || "").trim().toLowerCase()
              .replace(/^https?:\/\//, "").replace(/\/.*$/, "");
            if (!dom || !dom.includes(".")) {
              if (mbHintEl) mbHintEl.textContent = "dominio non valido (es. brand.it)";
              return;
            }
            let existing = [];
            try {
              const d = await bridgeRequest("GET_CUSTOM_DOMAINS");
              if (d && Array.isArray(d.domains)) existing = d.domains;
            } catch (e) {}
            if (existing.indexOf(dom) === -1) {
              await bridgeRequest("SET_CUSTOM_DOMAINS", { domains: existing.concat([dom]) });
            }
            mbNewDom.value = "";
            await renderMultibook();
          } catch (e) {}
        };
        mbAddBtn.addEventListener("click", doAdd);
        mbNewDom.addEventListener("keydown", (e) => { if (e.key === "Enter") doAdd(); });
      }

      if (mbLoginBtn) {
        mbLoginBtn.addEventListener("click", async () => {
          try {
            let customDomains = [];
            try {
              const d = await bridgeRequest("GET_CUSTOM_DOMAINS");
              if (d && Array.isArray(d.domains)) customDomains = d.domains;
            } catch (e) {}
            const domains = [];
            MB_FIXED.concat(customDomains).forEach(bk => {
              if (bk && bk !== BOOKMAKER && domains.indexOf(bk) === -1) domains.push(bk);
            });
            window.postMessage({ source: "gbfb", type: "OPEN_LOGIN_TABS", domains }, "*");
            if (mbHintEl) mbHintEl.textContent = "apertura schede di login…";
          } catch (e) {}
        });
      }

      // primo render + refresh periodico (aggiorna i minuti rimanenti dei token)
      renderMultibook();
      setInterval(renderMultibook, 10000);
    } catch (e) {}

    $("#clr").addEventListener("click", () => { log = []; saveState(); renderLog(); renderStats(); resultIdle(); });
    $("#clrSmk").addEventListener("click", () => { smkLog = []; saveSmkLog(); renderSmk(); });

    function startCrono(betStart) {
      if (cronoTimer) clearInterval(cronoTimer);
      crono.className = "crono-val run";
      cronoTimer = setInterval(() => {
        crono.innerHTML = (Date.now() - betStart) + '<span class="u">ms</span>';
        cdet.textContent = "bet in corso…";
      }, 50);
    }
    function showResult(e) {
      if (cronoTimer) { clearInterval(cronoTimer); cronoTimer = null; }
      if (!e) return;
      crono.innerHTML = e.totale + '<span class="u">ms</span>';
      crono.className = "crono-val " + (e.mock ? "run" : "");
      cdet.textContent = `totale ${e.totale}ms · insert ${e.insert}ms · pending ${e.pend}ms`;
    }
    function resultIdle() {
      crono.innerHTML = "--"; crono.className = "crono-val"; cdet.textContent = "in attesa di una giocata…";
    }

    function renderLog() {
      if (!log.length) { loglist.innerHTML = '<div class="empty">Nessuna giocata</div>'; return; }
      loglist.innerHTML = log.map(e => `
        <div class="li">
          <span class="o">${e.orario}</span>
          <span class="i">${e.insert}ms</span>
          <span class="t">${e.totale}ms</span>
          <span class="b ${e.mock ? "on" : "off"}">${e.mock ? "ON" : "OFF"}</span>
        </div>`).join("");
    }

    function renderSmk() {
      const smklist = $("#smklist");
      const setT = (id, v) => { const el = $("#" + id); if (el) el.textContent = v; };
      setT("smk-cnt", smkLog.length);
      if (!smkLog.length) {
        smklist.innerHTML = '<div class="empty">Nessuna sospensione registrata</div>';
        setT("smk-avg", "--");
        return;
      }
      const avg = Math.round(smkLog.reduce((a, e) => a + e.durata, 0) / smkLog.length);
      setT("smk-avg", avg);
      smklist.innerHTML = smkLog.map(e => `
        <div class="li" style="grid-template-columns:52px 1fr 70px">
          <span class="o">${e.orario}</span>
          <span class="i" style="text-align:left;color:#e85d5d">${e.sel}</span>
          <span class="t">${e.durata}ms</span>
        </div>`).join("");
    }

    function renderStats() {
      const n = log.length;
      const setT = (id, v) => { const el = $("#" + id); if (el) el.textContent = v; };
      if (!n) {
        ["d-med","d-rec","s-rec","s-med","s-wor"].forEach(id => setT(id, "--"));
        setT("s-tot", "0"); setT("s-stk", "€0"); setT("s-mon", "-- / --"); setT("s-sav", "--");
        return;
      }
      const tempi = log.map(e => e.totale);
      const media = Math.round(tempi.reduce((a, b) => a + b, 0) / n);
      const rec = Math.min(...tempi), wor = Math.max(...tempi);
      const stk = log.reduce((a, e) => a + (e.stake || 0), 0).toFixed(2);
      const on = log.filter(e => e.mock).length, off = n - on;
      const mOn = on ? Math.round(log.filter(e => e.mock).reduce((a, e) => a + e.totale, 0) / on) : null;
      const mOff = off ? Math.round(log.filter(e => !e.mock).reduce((a, e) => a + e.totale, 0) / off) : null;
      const sav = (mOn !== null && mOff !== null) ? (mOff - mOn) + "ms" : "--";
      setT("d-med", media); setT("d-rec", rec);
      setT("s-tot", n); setT("s-rec", rec + "ms"); setT("s-med", media + "ms"); setT("s-stk", "€" + stk);
      setT("s-wor", wor + "ms"); setT("s-mon", on + " / " + off); setT("s-sav", sav);
    }

    const smkDot   = $("#smkDot");
    const smkLabel = $("#smkLabel");

    ui = {
      startCrono,
      showLogin,
      showBlocked,
      onNewBet(e) { showResult(e); renderLog(); renderStats(); },
      onRetrying(attempt = 1) {
        crono.className = "crono-val run";
        cdet.textContent = attempt > 1
          ? `quota scaduta — retry #${attempt} con quota fresca…`
          : "quota scaduta — retry con quota fresca…";
      },
      onRetryOk() {
        crono.className = "crono-val";
        cdet.textContent = "✓ retry OK — scommessa piazzata con quota aggiornata";
      },
      onRetryFailed(reason) {
        if (cronoTimer) { clearInterval(cronoTimer); cronoTimer = null; }
        crono.innerHTML = "✕"; crono.className = "crono-val";
        const msg = {
          retired:   "quota RITIRATA dal bookmaker (probabile gol imminente) — non piazzabile",
          suspended: "mercato SOSPESO (lucchetto) — riprova quando riapre",
          server:    "rifiutata dal server dopo i tentativi — quota non più disponibile",
          notfound:  "selezione non più presente nei mercati live",
          payload:   "errore interno nel coupon",
        };
        cdet.textContent = msg[reason] || ("scommessa rifiutata (" + (reason || "?") + ")");
      },
      onSmkClosed() { renderSmk(); },
      onReplicaResult(r) {
        try {
          const el = $("#mbHint");
          if (!el || !r) return;
          const bk = r.bookmaker || "?";
          if (r.ok) {
            el.textContent = "✓ replicato su " + bk + (r.couponCode ? " (" + r.couponCode + ")" : "");
          } else {
            el.textContent = "✕ " + bk + ": " + (r.reason || "errore");
          }
        } catch (e) {}
      },
      setSmk(state, suspended = []) {
        if (!smkDot) return;
        smkDot.className = "smk-dot" + (state !== "gray" ? " " + state : "");
        if (smkLabel) {
          if (state === "red" && suspended.length) {
            smkLabel.textContent = suspended.join(" · ");
            smkLabel.classList.add("visible");
          } else {
            smkLabel.textContent = "";
            smkLabel.classList.remove("visible");
          }
        }
      }
    };

    if (log.length) showResult(log[0]);
    renderLog(); renderStats(); renderSmk();
  }

  let built = false;
  function tryBuild() {
    if (built || !document.body) return built;
    try { buildUI(); built = true; } catch (e) {}
    return built;
  }
  function init() {
    if (tryBuild()) return;
    document.addEventListener("DOMContentLoaded", tryBuild, { once: true });
    try { const o = new MutationObserver(() => { if (tryBuild()) o.disconnect(); });
      o.observe(document.documentElement, { childList: true, subtree: true }); } catch (e) {}
    let n = 0; const iv = setInterval(() => { if (tryBuild() || ++n > 40) clearInterval(iv); }, 250);
  }
  init();

})();
