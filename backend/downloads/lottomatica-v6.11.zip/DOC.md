# Lottomatica Fast Bet (v6.x) — Documentazione

## Cos'è
Versione **singola** dell'estensione Fast Bet dedicata al solo **Lottomatica**. Precursore dell'estensione unificata "Lottomatica Group": stessa piattaforma e stessa tecnica di Goldbet, ma limitata a un unico bookmaker (manifest v6.11).

## Piattaforma tecnica
GAD / piattaforma Lottomatica in **Angular** (identica a Goldbet e Planetwin365), endpoint `/api/sport/...`. Endpoint chiave del piazzamento:
- `POST /api/sport/book/insertBet` — registra la scommessa e restituisce già il `couponCode`.
- `pendingBet` — passo di conferma successivo, in realtà solo polling estetico.
- `GET /api/sport/live/getDetailsEventLive/1/<evtId>` — quota fresca per il retry su quota scaduta.

## Velocità di piazzamento LIVE
**~2,4 secondi** (stessa piattaforma di Goldbet, dai ~7,4s originali). I ~1230 ms di `insertBet` sono server-side invalicabili.

## Come funziona
`insertBet` restituisce già il `couponCode` alla prima chiamata: scommessa già registrata. L'estensione intercetta `pendingBet` e **mocka la conferma** (`statusCode:"P"`), eliminando il polling estetico. Include gate di licenza, GUI overlay, telemetria e retry su quota scaduta. Nel sistema licenze il bookmaker è distinto come `lottomatica`.

## Cosa è stato provato / scoperto
- Mock del `pendingBet` → **funziona**, bet reale, ~2,4s (stessa scoperta di Goldbet: `pendingBet` è solo estetica).
- Retry automatico su **errore 41** (quota scaduta): recupera quota fresca da `getDetailsEventLive` e ripiazza.
- Gli ID selezione (`evtId`/`selId`/`markId`/`aamsId`) coincidono con quelli di Goldbet e Planetwin365 → base per il multibook realizzato nell'estensione unificata.

## Stato
**Funzionante.** Sostituita in produzione dall'estensione unificata `lottomatica_group_fast_bet`, che copre anche questo book aggiungendo multibook e guardia anti-storno.

## Come si usa
1. Chrome → `chrome://extensions` → **Modalità sviluppatore** → **Carica estensione non pacchettizzata** → cartella `lottomatica_fast_bet`.
2. Login su lottomatica.it.
3. Login con la licenza nell'overlay dell'estensione.
4. Prepara e piazza la giocata; la conferma è istantanea.
