# Bwin Fast Bet — Documentazione

## Cos'è
Estensione per **bwin.it** che ti fa piazzare in un gesto: clicchi una quota (o premi una hotkey Casa/Ospite) e l'estensione aggiunge al carrello, scrive il tuo importo e clicca "Piazza scommessa". L'importo si imposta nel pannello dell'estensione.

## Piattaforma tecnica
**Entain proprietaria** (ex-GVC), frontend Angular. Feed quote via `cds-api/bettingoffer` (auth `x-bwin-accessid`). Piazzamento a 2 fasi: `POST /it/sports/api/placebet/place` (torna un requestId) → dopo ~4s → `GET /it/sports/api/placebet/querystatus` (esito). Tracing Datadog RUM.

## Velocità di piazzamento LIVE
**~4 secondi** (misurato su 3 giocate: place ~180ms → attesa ~4s → querystatus ~150ms). È il 2° book più veloce dopo Goldbet (2,4s), meglio di William Hill (12s), NetBet (14s), Fastbet (22s).

## Come funziona
**Auto-click DOM** (non API): al click su una quota `.option-pick`, l'estensione — senza bloccare il click nativo — aspetta che la schedina si popoli, scrive l'importo nel campo `input.stake-input-value` col native Angular setter, e clicca `button.place-button` ("Piazza scommessa"). È il SITO a costruire il payload (firmato con `sign`), quindi sempre valido.

Hotkey Casa/Ospite: nel primo mercato aperto/visibile, **Casa = 1ª quota, Ospite = ultima** (Bwin mostra i nomi squadra o 1/X/2, non "Casa/Ospite"). L'opzione di mezzo (X/Nessun gol) viene ignorata.

### Novità v1.1
- **Gol Casa / Gol Ospite 1° Tempo** — due hotkey in più. Cercano il **mercato con titolo "1° tempo"** (parole: `1° tempo`, `1 tempo`, `1t`, `primo tempo`, `1st half`) e prendono 1ª/ultima quota. Le righe compaiono nel pannello **solo se il mercato 1°T è in pagina** (o se hai già registrato il tasto). Se non è aperto, un avviso te lo dice.
- **Cronometro da 0** — al click/hotkey parte un cronometro (00.00s, oro mentre gira) che misura il TUO tempo reale dal gesto alla conferma. Si ferma **esattamente** quando il sito fa il `GET placebet/querystatus` (intercettato via `fetch`), cioè quando arriva l'esito; fallback a 6s se non lo intercetta. Diventa verde a fine corsa.
- Pause interne ridotte al minimo (poll a 20ms, meno sleep) per accorciare la parte velocizzabile.

## Cosa è stato provato / scoperto
- Bwin è **"pending" fino al querystatus**: il `place` torna solo un `requestId` (non un ticket), poi ~4s di attesa. È il risk-management Entain (come xSport) → **i 4s NON sono azzerabili** (mockare darebbe un "confermato" falso).
- I body delle risposte sono compressi **Brotli** (`content-encoding: br`) — illeggibili col REST Sniffer attuale, ma la struttura è chiara dai payload di richiesta.
- Payload `place` leggibile: `betSlips[].stake.amount`, `bets[].odds.european`, `picks[].id`, `betDetails[]` con `sign` firmati, `oddsAcceptanceMode:"Any"`.

## Stato
**Funzionante come velocizzatore di invio** (auto-click DOM). NON azzera i ~4s del server (risk Entain, non aggirabile). Da testare dal vivo con una giocata reale.

## Come si usa
1. Carica la cartella `bwin_fast_bet` in `chrome://extensions` (Modalità sviluppatore → Carica estensione non pacchettizzata).
2. Apri bwin.it su una partita live, imposta l'importo nel pannello (in basso a destra).
3. **Clicca una quota** → gioca subito. Oppure registra i tasti Casa/Ospite e premili.
4. Per tornare al comportamento normale del sito, spegni l'interruttore Fast Bet.

## Note per il tester
Se al click la quota si aggiunge ma non trova il campo importo o il pulsante, apri la Console (F12): l'estensione stampa i candidati trovati. In quel caso i selettori (`input.stake-input-value`, `button.place-button`) vanno aggiornati sul DOM reale.
