// REST Sniffer v1.3 — popup

const listEl   = document.getElementById("list");
const countEl  = document.getElementById("count");
const filterEl = document.getElementById("filter");
const onlyBetEl = document.getElementById("onlyBet");
const btnCapture = document.getElementById("btnCapture");
const btnCopy   = document.getElementById("btnCopy");
const btnClear  = document.getElementById("btnClear");

let captures = [];
const openIds = new Set();

// ---- REC on/off ----
chrome.storage.local.get("capturing", (r) => {
  const on = (r.capturing === undefined) ? true : r.capturing;
  setCaptureBtn(on);
});
function setCaptureBtn(on) {
  btnCapture.classList.toggle("active", on);
  btnCapture.textContent = on ? "● REC" : "▷ OFF";
}
btnCapture.addEventListener("click", () => {
  chrome.storage.local.get("capturing", (r) => {
    const on = (r.capturing === undefined) ? true : r.capturing;
    chrome.storage.local.set({ capturing: !on });
    setCaptureBtn(!on);
  });
});

btnClear.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "CLEAR_CAPTURES" });
  chrome.storage.local.set({ captures: [] });
  captures = []; openIds.clear(); render();
});

btnCopy.addEventListener("click", () => {
  const data = filtered();
  navigator.clipboard.writeText(exportText(data)).then(() => {
    btnCopy.textContent = "✓ Copiato";
    setTimeout(() => btnCopy.textContent = "Copia tutto", 1200);
  });
});

filterEl.addEventListener("input", render);
onlyBetEl.addEventListener("change", render);

// ---- helpers ----
function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function pretty(body) {
  if (body == null) return "(vuoto)";
  if (typeof body !== "string") return String(body);
  const t = body.trim();
  if ((t.startsWith("{") && t.endsWith("}")) || (t.startsWith("[") && t.endsWith("]"))) {
    try { return JSON.stringify(JSON.parse(t), null, 2); } catch (e) {}
  }
  return body;
}

function shortUrl(u) {
  try { const x = new URL(u); return x.pathname + (x.search.length > 1 ? x.search : ""); }
  catch (e) { return u; }
}

function filtered() {
  const f = filterEl.value.trim().toLowerCase();
  const onlyBet = onlyBetEl.checked;
  return captures.filter(c => {
    if (onlyBet && !c.isBet) return false;
    if (f && !((c.url || "").toLowerCase().includes(f))) return false;
    return true;
  });
}

function kvBlock(obj) {
  const keys = Object.keys(obj || {});
  if (!keys.length) return '<div class="kv">(nessuno)</div>';
  return '<div class="kv">' + keys.map(k => `<b>${esc(k)}:</b> ${esc(obj[k])}`).join("<br>") + "</div>";
}

// ---- render ----
function render() {
  const data = filtered();
  countEl.textContent = `${data.length} chiamate${data.length !== captures.length ? " (di " + captures.length + ")" : ""}`;

  if (!data.length) {
    listEl.innerHTML = '<div class="empty">Nessuna chiamata catturata.<br>Naviga su Eurobet e piazza una scommessa.</div>';
    return;
  }

  listEl.innerHTML = data.map(c => {
    const time = new Date(c.tStart).toLocaleTimeString("it-IT", { hour12: false }) + "." + String(c.tStart % 1000).padStart(3, "0");
    const statusCls = c.status >= 200 && c.status < 400 ? "ok" : "err";
    const durCls = c.durationMs > 1000 ? "slow" : "";
    const open = openIds.has(c.id) ? " open" : "";

    // v1.1: badge extra (piattaforma, delay server, piazzamento lento)
    let badges = "";
    if (c.slowBet) badges += ` <span class="badge-slow">★ LENTO ${(c.durationMs/1000).toFixed(1)}s</span>`;
    if (c.delayServer != null) badges += ` <span class="badge-delay">delay ${c.delayServer}s</span>`;
    if (c.platform) badges += ` <span class="badge-plat">${esc(c.platform)}</span>`;

    return `
      <div class="row${c.isBet ? " bet" : ""}${c.slowBet ? " slowbet" : ""}${open}" data-id="${c.id}">
        <div class="row-head">
          <span class="kind">${c.kind}</span>
          <span class="method ${c.method}">${c.method}</span>
          <span class="url" title="${esc(c.url)}">${esc(shortUrl(c.url))}${badges}</span>
          <span class="status ${statusCls}">${c.status}</span>
          <span class="dur ${durCls}">${c.durationMs}ms</span>
        </div>
        <div class="detail">
          <div class="meta-line"><b>URL completo:</b> ${esc(c.url)}</div>
          <div class="meta-line"><b>Orario:</b> ${esc(time)} &nbsp; <b>ISO:</b> ${esc(c.iso || "")} &nbsp; <b>ts:</b> ${c.tStart}</div>
          <div class="meta-line"><b>Durata:</b> ${c.durationMs}ms &nbsp; <b>Pagina:</b> ${esc(c.page || "")}</div>

          <div class="sec">
            <div class="sec-title">Request Headers <span class="copy-mini" data-copy="reqh" data-id="${c.id}">copia</span></div>
            ${kvBlock(c.reqHeaders)}
          </div>
          <div class="sec">
            <div class="sec-title">Request Body <span class="copy-mini" data-copy="reqb" data-id="${c.id}">copia</span></div>
            <pre>${esc(pretty(c.reqBody))}</pre>
          </div>
          <div class="sec">
            <div class="sec-title">Response Headers</div>
            ${kvBlock(c.respHeaders)}
          </div>
          <div class="sec">
            <div class="sec-title">Response Body <span class="copy-mini" data-copy="respb" data-id="${c.id}">copia</span></div>
            <pre>${esc(pretty(c.respBody))}</pre>
          </div>
          <div class="sec">
            <div class="sec-title">cURL <span class="copy-mini" data-copy="curl" data-id="${c.id}">copia</span></div>
            <pre>${esc(toCurl(c))}</pre>
          </div>
        </div>
      </div>`;
  }).join("");

  // toggle apertura
  listEl.querySelectorAll(".row-head").forEach(h => {
    h.addEventListener("click", (e) => {
      if (e.target.classList.contains("copy-mini")) return;
      const id = +h.parentElement.dataset.id;
      if (openIds.has(id)) openIds.delete(id); else openIds.add(id);
      h.parentElement.classList.toggle("open");
    });
  });

  // copia mini
  listEl.querySelectorAll(".copy-mini").forEach(btn => {
    btn.addEventListener("click", () => {
      const id = +btn.dataset.id;
      const c = captures.find(x => x.id === id);
      if (!c) return;
      let text = "";
      if (btn.dataset.copy === "reqh") text = JSON.stringify(c.reqHeaders, null, 2);
      if (btn.dataset.copy === "reqb") text = pretty(c.reqBody);
      if (btn.dataset.copy === "respb") text = pretty(c.respBody);
      if (btn.dataset.copy === "curl") text = toCurl(c);
      navigator.clipboard.writeText(text).then(() => {
        const old = btn.textContent; btn.textContent = "✓";
        setTimeout(() => btn.textContent = old, 1000);
      });
    });
  });
}

// ---- cURL builder ----
function toCurl(c) {
  let out = `curl '${c.url}' \\\n  -X ${c.method}`;
  Object.entries(c.reqHeaders || {}).forEach(([k, v]) => {
    out += ` \\\n  -H '${k}: ${String(v).replace(/'/g, "'\\''")}'`;
  });
  if (c.reqBody && typeof c.reqBody === "string" && !c.reqBody.startsWith("[")) {
    out += ` \\\n  --data-raw '${c.reqBody.replace(/'/g, "'\\''")}'`;
  }
  return out;
}

// ---- export testo completo ----
function exportText(data) {
  return data.slice().reverse().map(c => {
    return [
      "════════════════════════════════════════════════════════",
      `[${c.kind}] ${c.method} ${c.url}`,
      `status: ${c.status} | durata: ${c.durationMs}ms | ${c.iso} | ts:${c.tStart}${c.isBet ? " | ★ BET" : ""}${c.slowBet ? " | ★ PIAZZAMENTO LENTO" : ""}${c.delayServer != null ? " | delay server:" + c.delayServer + "s" : ""}${c.platform ? " | piattaforma:" + c.platform : ""}`,
      `pagina: ${c.page || ""}`,
      "",
      "--- REQUEST HEADERS ---",
      Object.entries(c.reqHeaders || {}).map(([k, v]) => `${k}: ${v}`).join("\n") || "(nessuno)",
      "",
      "--- REQUEST BODY ---",
      pretty(c.reqBody),
      "",
      "--- RESPONSE HEADERS ---",
      Object.entries(c.respHeaders || {}).map(([k, v]) => `${k}: ${v}`).join("\n") || "(nessuno)",
      "",
      "--- RESPONSE BODY ---",
      pretty(c.respBody),
      "",
      "--- cURL ---",
      toCurl(c),
      ""
    ].join("\n");
  }).join("\n");
}

// ---- load + live ----
function load() {
  chrome.storage.local.get("captures", (r) => {
    captures = r.captures || [];
    render();
  });
}
chrome.storage.onChanged.addListener((changes) => {
  if (changes.captures) { captures = changes.captures.newValue || []; render(); }
  if (changes.capturing) setCaptureBtn(changes.capturing.newValue);
});
load();
