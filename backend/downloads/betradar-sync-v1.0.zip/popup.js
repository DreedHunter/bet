/* Popup: configura host/porta/token del relay WebSocket Betradar. */

const DEFAULTS = { host: "localhost", port: "3000", token: "betradar2026" };

const $host = document.getElementById("host");
const $port = document.getElementById("port");
const $token = document.getElementById("token");
const $preview = document.getElementById("preview");
const $status = document.getElementById("status");

function buildUrl(host, port, token) {
  host = (host || "").trim();
  port = (port || "").trim() || "3000";
  token = (token || "").trim();
  if (!host) return "ws://…";
  return `ws://${host}:${port}?role=subscriber&token=${encodeURIComponent(token)}`;
}

function refreshPreview() {
  $preview.textContent = buildUrl($host.value, $port.value, $token.value);
}

// carica valori salvati
chrome.storage.local.get(["wsConfig"], (res) => {
  const cfg = res.wsConfig || DEFAULTS;
  $host.value = cfg.host || "";
  $port.value = cfg.port || "3000";
  $token.value = cfg.token || DEFAULTS.token;
  refreshPreview();
});

[$host, $port, $token].forEach((el) => el.addEventListener("input", refreshPreview));

document.getElementById("save").addEventListener("click", () => {
  const host = $host.value.trim();
  if (!host) {
    $status.textContent = "Inserisci l'host del relay.";
    $status.className = "err";
    return;
  }
  const cfg = {
    host,
    port: ($port.value.trim() || "3000"),
    token: $token.value.trim(),
  };
  // Salvo anche l'URL completo pronto all'uso, e un contatore per forzare
  // la riconnessione anche se l'URL non cambia (storage.onChanged nel content).
  chrome.storage.local.get(["reconnectNonce"], (r) => {
    const nonce = (r.reconnectNonce || 0) + 1;
    chrome.storage.local.set(
      { wsConfig: cfg, wsUrl: buildUrl(cfg.host, cfg.port, cfg.token), reconnectNonce: nonce },
      () => {
        $status.textContent = "Salvato. Riconnessione in corso…";
        $status.className = "ok";
      }
    );
  });
});
