# Goldbet ↔ Betradar Sync

Estensione Chrome (Manifest V3) che confronta **in tempo reale** i tempi di gioco
delle pagine **goldbet.it** con un **feed Betradar multi-partita** ricevuto da un
relay WebSocket già esistente, mostrando per ogni partita abbinata il **ritardo**
(chi è avanti e di quanti secondi).

## Installazione

1. Chrome → `chrome://extensions`
2. Attiva **Modalità sviluppatore** (in alto a destra)
3. **Carica estensione non pacchettizzata** → seleziona la cartella
   `goldbet_betradar_sync`

## Configurazione del feed (obbligatoria)

Clicca l'icona dell'estensione → si apre il popup:

- **Host**: IP o hostname del relay WebSocket (es. `192.168.1.50` o `localhost`)
- **Porta**: default `3000`
- **Token**: default `betradar2026`

Salva. L'estensione si connette come subscriber a:

```
ws://<host>:<porta>?role=subscriber&token=<token>
```

Riconnessione automatica ogni 3 s se il relay cade. Il pallino in alto a sinistra
dell'overlay indica lo stato: **verde** = connesso, **rosso** = assente,
**giallo** = in riconnessione.

## Come si usa

1. Apri la sezione **Live** di Goldbet (es.
   `goldbet.it/scommesse/live/tutti-gli-eventi`).
2. Compare un **overlay flottante** (trascinabile per l'intestazione) con una riga
   per ogni partita **abbinata** al feed Betradar:
   - squadre, punteggio Betradar, periodo, orologio Betradar estrapolato
   - **Diff**: differenza Betradar − Goldbet
     - 🟢 verde = Betradar **avanti**
     - 🔴 rosso = Betradar **indietro**
     - ⚪ grigio = allineati (|diff| < 300 ms) o in pausa
   - simbolo qualità della misura:
     - `⚽` misura sul **gol** (la più precisa, priorità per 2 min)
     - *(nessun simbolo)* orologio **LMT** al secondo
     - `≈` **scatto del minuto** Goldbet
     - `~` **stima grezza** (prima lettura, non ancora una misura reale)

## Abbinamento partite

- **Automatico**: i nomi vengono normalizzati (minuscole, senza accenti) e
  confrontati. Se entrambe le squadre combaciano → abbinamento certo.
- **Manuale**: clicca **Abbinamenti**. Le partite Betradar senza corrispondenza
  compaiono con un menu a tendina delle righe live Goldbet: scegli quella giusta.
  L'abbinamento viene **salvato** (`chrome.storage.local`) e riusato in futuro.
- È normale che **non tutte** le partite esistano su entrambi i lati: quelle senza
  controparte restano semplicemente non abbinate, senza errori.

## Note tecniche

- **Orologio Betradar estrapolato**: `clockSec + (running ? (now − tickTs)/1000 : 0)`.
  Se `running = false` l'estrapolazione è congelata e la riga mostra "pausa".
- **Convenzione minuto Goldbet**: `34'` = 34° minuto in corso → il cronometro reale
  è tra 33:00 e 33:59; lo scatto a `34'` avviene quando il cronometro tocca 33:00,
  quindi `secGoldbet = (min − 1) × 60`.
- **Misura precisa** allo scatto del minuto (MutationObserver, non polling) e sul
  cambio punteggio. La prima lettura dopo ogni ri-aggancio **non** è una misura.
- **Mediana** delle ultime 5 misure; gli outlier oltre 20 s vengono scartati salvo
  conferma da una seconda misura simile.
- **Orologio LMT** (Sportradar, pagine di dettaglio con i secondi): se presente in
  un iframe, una "spia" (`lmt-spy.js`) legge `.sr-lmt-plus-scb__clock` e invia i
  tick al frame principale via `postMessage`. Ha priorità sul minuto.
- Tutti i timestamp usano `Date.now()` (confrontabili tra frame/contesti diversi).

## File

| File | Ruolo |
|------|-------|
| `manifest.json` | MV3: content script monitor (frame top goldbet) + spia LMT (tutti i frame) |
| `popup.html/js` | Configurazione host/porta/token del relay |
| `src/util.js` | Costanti, normalizzazione nomi, mediana, log sicuro |
| `src/ws-client.js` | Connessione subscriber + riconnessione |
| `src/betradar.js` | Store partite feed, estrapolazione orologio, crossing dei secondi |
| `src/goldbet.js` | Lettura righe live (squadre/gol/minuto), ri-aggancio, MutationObserver |
| `src/lmt-spy.js` | Spia orologio Sportradar LMT negli iframe |
| `src/matcher.js` | Abbinamento auto + manuale (persistito) |
| `src/measure.js` | Motore di misura del ritardo (scatto minuto, gol, mediana, outlier) |
| `src/ui.js` | Overlay Shadow DOM |
| `src/main.js` | Orchestratore: collega tutto, gestisce i tick LMT |
