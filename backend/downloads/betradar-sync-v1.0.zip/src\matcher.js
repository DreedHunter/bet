/* =============================================================================
 * matcher.js — abbinamento partite Betradar <-> righe Goldbet. (spec §5)
 *
 * Regole:
 *  - Normalizza i nomi (GBS.normName): minuscole, no accenti, solo [a-z0-9].
 *  - AUTO certo:   entrambe le squadre Goldbet (primi 10 char normalizzati)
 *                  contenute nei nomi Betradar.
 *  - AUTO probabile: una sola squadra con nome normalizzato >=8 char contenuta.
 *  - MANUALE: salvato in chrome.storage.local, chiave = ID Betradar. Prevale
 *             sempre sull'automatico e viene riusato.
 *  - Non tutte le partite esistono su entrambi i lati: e' normale, nessun errore.
 *
 * Espone GBS.matcher.resolve() -> ritorna array di abbinamenti:
 *   { betId, brRec, gbRec|null, mode: 'manual'|'auto-sure'|'auto-likely'|'none' }
 * piu' la lista delle Betradar non abbinate (per l'UI manuale).
 * ========================================================================== */

(() => {
  "use strict";
  const GBS = window.GBS;
  const N = GBS.normName;

  const M = (GBS.matcher = {
    manual: {},            // betId -> goldbetRowKey
    _loaded: false,
  });

  const STORAGE_KEY = "manualMatches";

  function load(cb) {
    chrome.storage.local.get([STORAGE_KEY], (res) => {
      M.manual = res[STORAGE_KEY] || {};
      M._loaded = true;
      if (cb) cb();
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[STORAGE_KEY]) {
        M.manual = changes[STORAGE_KEY].newValue || {};
        GBS.log("matcher: abbinamenti manuali aggiornati");
      }
    });
  }

  function setManual(betId, goldbetRowKey) {
    M.manual[betId] = goldbetRowKey;
    chrome.storage.local.set({ [STORAGE_KEY]: M.manual });
  }
  function clearManual(betId) {
    delete M.manual[betId];
    chrome.storage.local.set({ [STORAGE_KEY]: M.manual });
  }

  // una squadra "contenuta" nell'altra dopo normalizzazione
  function contains(hay, needle) {
    return needle && hay.includes(needle);
  }

  // prova auto-match tra un record Betradar e le righe Goldbet correnti
  function autoMatch(brRec, gbRows) {
    const brBlob = N(brRec.home) + "|" + N(brRec.away);
    const brBlobFlat = N(brRec.home) + N(brRec.away);

    let bestLikely = null;
    for (const gb of gbRows) {
      const gHome = N(gb.home), gAway = N(gb.away);
      const gH10 = gHome.slice(0, 10), gA10 = gAway.slice(0, 10);

      // certo: entrambe (primi 10) presenti nel blob Betradar
      const homeIn = contains(brBlob, gH10) || contains(brBlobFlat, gH10);
      const awayIn = contains(brBlob, gA10) || contains(brBlobFlat, gA10);
      if (homeIn && awayIn && gH10 && gA10) {
        return { gb, mode: "auto-sure" };
      }
      // probabile: una sola, ma con nome lungo (>=8)
      const hLong = gHome.length >= 8 && (contains(brBlob, gHome) || contains(brBlobFlat, gHome));
      const aLong = gAway.length >= 8 && (contains(brBlob, gAway) || contains(brBlobFlat, gAway));
      if ((hLong || aLong) && !bestLikely) bestLikely = { gb, mode: "auto-likely" };
    }
    return bestLikely; // puo' essere null
  }

  // Risolve tutti gli abbinamenti nello stato corrente.
  function resolve() {
    const gbRows = [...GBS.goldbet.rows.values()];
    const gbByKey = new Map(gbRows.map((r) => [r.key, r]));
    const results = [];
    const unmatchedBet = [];
    const usedGbKeys = new Set();

    for (const brRec of GBS.betradar.matches.values()) {
      const betId = brRec.id;

      // 1) manuale ha priorita'
      const manKey = M.manual[betId];
      if (manKey && gbByKey.has(manKey)) {
        const gb = gbByKey.get(manKey);
        usedGbKeys.add(gb.key);
        results.push({ betId, brRec, gbRec: gb, mode: "manual" });
        continue;
      }

      // 2) automatico (escludendo righe gia' usate da manuali)
      const freeRows = gbRows.filter((r) => !usedGbKeys.has(r.key));
      const am = autoMatch(brRec, freeRows);
      if (am) {
        usedGbKeys.add(am.gb.key);
        results.push({ betId, brRec, gbRec: am.gb, mode: am.mode });
      } else {
        results.push({ betId, brRec, gbRec: null, mode: "none" });
        unmatchedBet.push(brRec);
      }
    }

    // righe Goldbet senza feed: semplicemente ignorate (non entrano nei results)
    const unmatchedGb = gbRows.filter((r) => !usedGbKeys.has(r.key));

    return { results, unmatchedBet, unmatchedGb };
  }

  M.load = load;
  M.setManual = setManual;
  M.clearManual = clearManual;
  M.resolve = resolve;

  GBS.log("matcher.js caricato");
})();
