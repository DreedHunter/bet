# Goldbet ↔ Betradar Sync (v1.0) — Documentazione

## Cos'è
NON è un'estensione Fast Bet. È uno strumento di **analisi/timing**: confronta in tempo reale i tempi di gioco delle pagine **goldbet.it** con un feed **Betradar** multi-partita, mostrando per ogni partita abbinata il **ritardo** (chi è avanti e di quanti secondi).

## Piattaforma tecnica
Estensione Chrome MV3 su goldbet.it. La lista live Goldbet è un'app **Angular** (custom elements `app-scommesse-row-event`); l'estensione legge minuto, squadre e punteggio dal DOM. Il feed arriva da un **relay WebSocket** già esistente: `ws://<host>:3000?role=subscriber&token=betradar2026`, con un messaggio `{type:"DATA", scout:{...clockSec, tickTs, running...}}` per partita. Moduli in `src/`: util, ws-client, betradar, goldbet, matcher, measure, ui, main, più `lmt-spy` (spia dei widget di dettaglio).

## Come funziona
L'estensione si connette al relay come subscriber, estrapola l'orologio Betradar di ogni partita e lo confronta con il tempo letto dalle pagine Goldbet. Mostra un overlay flottante con una riga per ogni partita abbinata: squadre, punteggio, periodo, orologio Betradar e **Diff** (Betradar − Goldbet: avanti = verde/+, indietro = rosso/−). Il matching abbina le partite tra i due lati; la misura usa la mediana con scarto degli outlier (>20s) e mette in pausa quando `running=false`.

## Cosa è stato provato / scoperto
- La lista live Goldbet mostra **solo il minuto intero** (`45'`), niente secondi. Convenzione: `34'` = 34° minuto in corso → cronometro reale 33:00–33:59.
- Struttura DOM della riga: minuto, squadre e punteggio sono **fratelli** dentro `app-scommesse-row-event`, non annidati → il contenitore corretto è `app-scommesse-row-event`. Testato con jsdom: 18/18 partite lette con minuto+gol corretti.
- I **secondi esatti** esistono solo nel widget streaming di dettaglio (dietro login). Discrepanza aperta: nello snapshot il provider era **Perform/Opta**, ma la spec parlava di **Sportradar LMT** → `lmt-spy.js` gira in tutti i frame sui domini sportradar/performgroup e comunica via `postMessage`.
- Verificato (2026-07-06): `node --check` su tutti i JS OK, manifest valido, parser e motore di misura testati su scenari simulati. NON ancora provata in Chrome reale contro un relay vero.

## Stato
**In analisi.** Codice verificato staticamente e su snapshot; manca il test end-to-end in Chrome contro un relay Betradar reale.

## Come si usa
1. Chrome → `chrome://extensions` → **Modalità sviluppatore** → **Carica estensione non pacchettizzata** → cartella `goldbet_betradar_sync`.
2. Clicca l'icona dell'estensione e configura il feed (Host, Porta default `3000`, Token default `betradar2026`), poi salva.
3. Apri la sezione **Live** di Goldbet: compare l'overlay trascinabile con il ritardo per ogni partita abbinata. Il pallino in alto a sinistra indica lo stato del WebSocket (verde = connesso, rosso = assente, giallo = in riconnessione).
