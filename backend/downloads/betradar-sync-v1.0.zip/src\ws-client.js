/* =============================================================================
 * ws-client.js — connessione al relay WebSocket come subscriber.
 *
 *  - URL: ws://<host>:3000?role=subscriber&token=...  (da chrome.storage.local)
 *  - Riconnessione automatica ogni 3s se cade.
 *  - I publisher sono MOLTI e interlacciati: accumuliamo per scout.id in
 *    GBS.betradar (vedi betradar.js). Qui solo trasporto + dispatch.
 *  - storage.onChanged -> se cambia config o reconnectNonce, riconnetti.
 * ========================================================================== */

(() => {
  "use strict";
  const GBS = window.GBS;

  const WS = (GBS.ws = {
    url: null,
    sock: null,
    connected: false,
    lastError: null,
    _retryTimer: null,
    _onMessage: null,     // impostato da betradar.js
    _onStatus: null,      // impostato da main/ui per il pallino stato
  });

  function setStatus(state) {
    WS.connected = state === "open";
    if (typeof WS._onStatus === "function") GBS.safe(() => WS._onStatus(state));
  }

  function connect(url) {
    if (!url) { GBS.warn("WS: nessun URL configurato"); setStatus("closed"); return; }
    WS.url = url;

    // chiudi eventuale socket precedente
    disconnect(/*silent*/ true);

    GBS.log("WS: connessione a", url);
    let sock;
    try {
      sock = new WebSocket(url);
    } catch (e) {
      GBS.warn("WS: URL non valido", e);
      scheduleRetry();
      return;
    }
    WS.sock = sock;

    sock.onopen = () => {
      GBS.log("WS: connesso");
      WS.lastError = null;
      setStatus("open");
    };

    sock.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch (_) { return; } // ignora non-JSON
      if (typeof WS._onMessage === "function") GBS.safe(() => WS._onMessage(msg));
    };

    sock.onerror = (e) => {
      WS.lastError = e;
      setStatus("error");
    };

    sock.onclose = () => {
      GBS.warn("WS: chiuso, riprovo tra", GBS.C.RECONNECT_MS, "ms");
      setStatus("closed");
      scheduleRetry();
    };
  }

  function scheduleRetry() {
    clearTimeout(WS._retryTimer);
    WS._retryTimer = setTimeout(() => connect(WS.url), GBS.C.RECONNECT_MS);
  }

  function disconnect(silent) {
    clearTimeout(WS._retryTimer);
    if (WS.sock) {
      // stacca gli handler per evitare che onclose schedani un retry doppio
      try {
        WS.sock.onopen = WS.sock.onmessage = WS.sock.onerror = WS.sock.onclose = null;
        WS.sock.close();
      } catch (_) {}
    }
    WS.sock = null;
    if (!silent) setStatus("closed");
  }

  // Carica config e connetti; reagisci ai cambi da popup.
  function boot() {
    chrome.storage.local.get(["wsUrl", "wsConfig"], (res) => {
      const url = res.wsUrl || buildDefault(res.wsConfig);
      connect(url);
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.wsUrl || changes.reconnectNonce) {
        GBS.log("WS: config cambiata, riconnetto");
        chrome.storage.local.get(["wsUrl"], (res) => {
          if (res.wsUrl) connect(res.wsUrl);
        });
      }
    });
  }

  function buildDefault(cfg) {
    cfg = cfg || {};
    const host = cfg.host || "localhost";
    const port = cfg.port || "3000";
    const token = cfg.token || "betradar2026";
    return `ws://${host}:${port}?role=subscriber&token=${encodeURIComponent(token)}`;
  }

  WS.connect = connect;
  WS.disconnect = disconnect;
  WS.boot = boot;

  GBS.log("ws-client.js caricato");
})();
