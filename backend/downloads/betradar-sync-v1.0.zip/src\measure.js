/* =============================================================================
 * measure.js — motore di misura del RITARDO Goldbet vs Betradar. (spec §4)
 *
 * Differenza = secBetradar_estrapolato − secGoldbet_estrapolato  (in ms).
 *   Positivo = Betradar AVANTI (verde). Negativo = Betradar INDIETRO (rosso).
 *
 * Fonti di misura, dalla piu' alla meno precisa:
 *   ⚽ gol      : cambio punteggio su entrambi i lati -> differenza dei due istanti
 *   (niente)   : orologio LMT ai secondi (se presente) -> misura diretta al secondo
 *   ≈ minuto   : scatto del minuto Goldbet -> confronto con crossing Betradar
 *   ~ grezza   : stima da prima lettura (min-1)*60 + 30  (MAI come misura salvata)
 *
 * Stato per betId in GBS.measure.state[betId]:
 *   { buffer:[ms...], median, quality, lastGoalTs, lmtSec, lmtTs, paused, rough }
 * ========================================================================== */

(() => {
  "use strict";
  const GBS = window.GBS;
  const C = GBS.C;

  const MZ = (GBS.measure = {
    state: new Map(),          // betId -> stato misura
    // indice per collegare i tick Goldbet (che conoscono solo la riga) al betId:
    // lo aggiorna il main a ogni resolve(): gbKey -> betId
    gbKeyToBet: new Map(),
    // per la spia LMT: quale betId sta mostrando l'orologio LMT (best-effort)
    lmtByBet: new Map(),       // betId -> {sec, ts}
  });

  function st(betId) {
    let s = MZ.state.get(betId);
    if (!s) {
      s = {
        buffer: [], median: null, quality: null,
        lastGoalTs: 0, goalDiffMs: null,
        rough: null, paused: false,
      };
      MZ.state.set(betId, s);
    }
    return s;
  }

  // --- inserimento misura con mediana + scarto outlier (spec §4.4) ----------
  function pushMeasure(betId, ms, quality) {
    if (ms == null || !isFinite(ms)) return;
    if (Math.abs(ms) > C.ABSURD_MS) return;        // assurda (>5min) -> scarta
    const s = st(betId);

    const med = GBS.median(s.buffer);
    if (med != null && Math.abs(ms - med) > C.OUTLIER_MS) {
      // outlier: accetta solo se una SECONDA misura simile conferma
      if (s._pendingOutlier != null && Math.abs(ms - s._pendingOutlier) < C.OUTLIER_MS) {
        // confermato: svuota il buffer e riparti da queste due
        s.buffer = [s._pendingOutlier, ms];
        s._pendingOutlier = null;
      } else {
        s._pendingOutlier = ms;                    // tieni in sospeso, non inserire
        return;
      }
    } else {
      s._pendingOutlier = null;
      s.buffer.push(ms);
      if (s.buffer.length > C.MEASURE_BUFFER) s.buffer.shift();
    }

    s.median = GBS.median(s.buffer);
    s.quality = quality;                            // qualita' dell'ultima misura buona
  }

  // ---------------------------------------------------------------------------
  // Handler dei tick Goldbet (registrati dal main su GBS.goldbet.on)
  // ---------------------------------------------------------------------------

  // Scatto del minuto Goldbet.
  function onGoldbetMinute(gbRec, min, ts, isFirst) {
    const betId = MZ.gbKeyToBet.get(gbRec.key);
    if (!betId) return;                             // riga non abbinata
    const brRec = GBS.betradar.matches.get(betId);
    if (!brRec) return;
    const s = st(betId);

    // secGoldbet allo scatto = (min-1)*60  (spec §3)
    const secG = (min - 1) * 60;

    if (isFirst) {
      // prima lettura: solo stima grezza centrata, NON misura (spec §4.1)
      s.rough = roughDiffMs(brRec, (min - 1) * 60 + 30);
      return;
    }

    // Istante in cui Betradar ha toccato lo stesso secondo:
    const brTs = GBS.betradar.tsWhenCrossed(brRec, secG);
    if (brTs == null) return;                        // non abbiamo il crossing

    // misura = tsScattoGoldbet − tsBetradarQuandoHaToccato(secG)
    // Se Betradar ha toccato secG PRIMA (brTs < ts) => Goldbet e' in ritardo
    // => Betradar avanti => diff POSITIVA.
    const diffMs = ts - brTs;
    pushMeasure(betId, diffMs, "minute");           // ≈
  }

  // Cambio punteggio Goldbet (gol). (spec §4.5)
  function onGoldbetScore(gbRec, sh, sa, ts, isFirst) {
    const betId = MZ.gbKeyToBet.get(gbRec.key);
    if (!betId) return;
    if (isFirst) return;                            // prima lettura punteggio: init
    const brRec = GBS.betradar.matches.get(betId);
    if (!brRec) return;
    const s = st(betId);

    // istante gol lato Betradar
    const brGoalTs = brRec.scoreChangedAt;
    if (!brGoalTs) return;                           // Betradar non ha ancora il gol
    // accetta solo se i due gol sono ragionevolmente vicini nel tempo (<60s)
    const diffMs = ts - brGoalTs;
    if (Math.abs(diffMs) > 60000) return;

    s.lastGoalTs = Date.now();
    s.goalDiffMs = diffMs;
    pushMeasure(betId, diffMs, "goal");             // ⚽ (priorita' in view)
  }

  // ---------------------------------------------------------------------------
  // Orologio LMT (dalla spia iframe, via postMessage nel main)
  // ---------------------------------------------------------------------------
  function onLmtTick(betId, sec, ts) {
    const brRec = GBS.betradar.matches.get(betId);
    if (!brRec) return;
    // secGoldbet(LMT) = sec (ha gia' i secondi). Betradar quando ha toccato sec:
    const brTs = GBS.betradar.tsWhenCrossed(brRec, sec);
    if (brTs == null) return;
    const diffMs = ts - brTs;
    pushMeasure(betId, diffMs, "lmt");              // nessun simbolo (piu' precisa)
  }

  // ---------------------------------------------------------------------------
  // Stima grezza (quando non c'e' ancora nessuna misura vera). (spec §4.1)
  // secGoldbet centrato = (min-1)*60 + 30 gia' passato dal chiamante.
  // ---------------------------------------------------------------------------
  function roughDiffMs(brRec, secGoldbetCentered) {
    const secB = GBS.betradar.secBetradar(brRec);
    if (secB == null) return null;
    return (secB - secGoldbetCentered) * 1000;
  }

  // ---------------------------------------------------------------------------
  // Valore da mostrare per una partita abbinata.
  // Ritorna { ms, quality, state } dove:
  //   ms       = differenza in ms (o null)
  //   quality  = 'goal'|'lmt'|'minute'|'rough'|null
  //   state    = 'ok'|'paused'|'stale'
  // Priorita': pausa > gol(2min) > mediana(lmt/minute) > grezza.
  // ---------------------------------------------------------------------------
  function view(betId) {
    const brRec = GBS.betradar.matches.get(betId);
    const s = MZ.state.get(betId);
    if (!brRec) return { ms: null, quality: null, state: "stale" };

    // pausa: orologio fermo (spec §4.7)
    if (brRec.running === false) {
      return { ms: null, quality: null, state: "paused" };
    }
    if (GBS.betradar.isStale(brRec)) {
      return { ms: (s && s.median) ?? null, quality: s && s.quality, state: "stale" };
    }
    if (!s) return { ms: null, quality: null, state: "ok" };

    // misura sul gol prevale per 2 minuti (spec §4.5)
    if (s.goalDiffMs != null && Date.now() - s.lastGoalTs < C.GOAL_PRIORITY_MS) {
      return { ms: s.goalDiffMs, quality: "goal", state: "ok" };
    }
    if (s.median != null) {
      return { ms: s.median, quality: s.quality || "minute", state: "ok" };
    }
    if (s.rough != null) {
      return { ms: s.rough, quality: "rough", state: "ok" };
    }
    return { ms: null, quality: null, state: "ok" };
  }

  MZ.onGoldbetMinute = onGoldbetMinute;
  MZ.onGoldbetScore = onGoldbetScore;
  MZ.onLmtTick = onLmtTick;
  MZ.view = view;

  GBS.log("measure.js caricato");
})();
