/* =============================================================================
 * ui.js — overlay flottante in Shadow DOM (CSS isolato). (spec §6)
 *
 * Una riga per partita ABBINATA:
 *   squadre | punteggio Betradar | periodo | orologio Betradar estrapolato | diff
 * diff: verde se Betradar avanti, rosso se indietro, grigio se |diff|<300ms o pausa.
 * qualita': ~ grezza · ≈ scatto minuto · ⚽ gol · (nessuno) = LMT al secondo.
 * pallino stato feed: verde ok / giallo dati vecchi / rosso assente.
 * Sezione per abbinamenti manuali (Betradar non abbinate + tendina righe Goldbet).
 *
 * Trascinabile per l'header. Tutto dentro Shadow DOM.
 * ========================================================================== */

(() => {
  "use strict";
  const GBS = window.GBS;

  const UI = (GBS.ui = { root: null, shadow: null, els: {}, onManualPick: null });

  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: -apple-system, Segoe UI, Roboto, Arial, sans-serif; }
    .wrap {
      position: fixed; top: 70px; right: 16px; width: 560px; max-width: 94vw;
      max-height: 80vh; display: flex; flex-direction: column;
      background: #14181f; color: #e9edf2; border: 1px solid #2b3442;
      border-radius: 10px; box-shadow: 0 10px 34px rgba(0,0,0,.55);
      font-size: 13px; z-index: 2147483647; overflow: hidden;
    }
    .head {
      display: flex; align-items: center; gap: 8px; padding: 8px 10px; cursor: move;
      background: linear-gradient(90deg,#1b2230,#171c25); border-bottom: 1px solid #2b3442;
      user-select: none;
    }
    .title { font-weight: 700; }
    .dot { width: 10px; height: 10px; border-radius: 50%; background: #6b7a8d; }
    .dot.ok { background: #4fd08a; } .dot.warn { background: #f2b705; } .dot.err { background: #ff6b6b; }
    .sp { flex: 1; }
    .cnt { background:#2b3442; border-radius:999px; padding:1px 8px; font-size:11px; }
    button.mini { border:none; border-radius:6px; background:#2b3442; color:#e9edf2; cursor:pointer; padding:3px 8px; font-size:12px; }
    button.mini:hover { background:#3a4658; }
    .body { overflow:auto; }
    table { width:100%; border-collapse:collapse; }
    th,td { padding:6px 8px; text-align:left; border-bottom:1px solid #232b36; white-space:nowrap; }
    thead th { position:sticky; top:0; background:#1b2230; font-size:11px; text-transform:uppercase; letter-spacing:.4px; color:#9fb0c3; }
    td.clock { font-variant-numeric: tabular-nums; font-weight:700; color:#cfe3ff; }
    td.score { text-align:center; font-weight:700; color:#f2b705; font-variant-numeric: tabular-nums; }
    td.per { color:#9fb0c3; }
    td.diff { font-variant-numeric: tabular-nums; font-weight:700; text-align:right; }
    td.diff.ahead { color:#4fd08a; } td.diff.behind { color:#ff6b6b; } td.diff.flat { color:#8fa0b3; }
    .q { color:#9fb0c3; font-weight:400; margin-left:4px; }
    .fdot { display:inline-block; width:8px; height:8px; border-radius:50%; margin-right:6px; vertical-align:middle; }
    .fdot.ok{background:#4fd08a;} .fdot.warn{background:#f2b705;} .fdot.err{background:#ff6b6b;}
    .manual { border-top:1px solid #2b3442; padding:8px 10px; background:#0f141b; }
    .manual h4 { margin:0 0 6px; font-size:11px; text-transform:uppercase; color:#9fb0c3; letter-spacing:.4px; }
    .mrow { display:flex; align-items:center; gap:8px; margin:4px 0; }
    .mrow .nm { flex:1; overflow:hidden; text-overflow:ellipsis; }
    select { background:#0e1218; color:#e9edf2; border:1px solid #2b3442; border-radius:6px; padding:4px 6px; font:inherit; max-width:230px; }
    .empty { color:#8fa0b3; text-align:center; padding:16px; white-space:normal; }
    .hidden { display:none !important; }
  `;

  function build() {
    if (UI.root) return;
    const host = document.createElement("div");
    host.id = "gbs-overlay-host";
    // il body puo' avere stili aggressivi: fissiamo posizione via host
    host.style.position = "fixed";
    host.style.zIndex = "2147483647";
    host.style.top = "0"; host.style.left = "0"; host.style.width = "0"; host.style.height = "0";
    document.documentElement.appendChild(host);

    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = CSS;
    shadow.appendChild(style);

    const wrap = document.createElement("div");
    wrap.className = "wrap";
    wrap.innerHTML = `
      <div class="head">
        <span class="dot" id="feedDot"></span>
        <span class="title">Goldbet ↔ Betradar</span>
        <span class="cnt" id="cnt">0</span>
        <span class="sp"></span>
        <button class="mini" id="btnManual">Abbinamenti</button>
        <button class="mini" id="btnMin">–</button>
      </div>
      <div class="body" id="body">
        <table>
          <thead><tr>
            <th>Squadre</th><th class="score">BR</th><th>Per.</th>
            <th class="clock">Orol. BR</th><th class="diff">Diff</th>
          </tr></thead>
          <tbody id="tbody"></tbody>
        </table>
      </div>
      <div class="manual hidden" id="manual">
        <h4>Abbinamenti manuali (Betradar senza corrispondenza)</h4>
        <div id="manualList"></div>
      </div>`;
    shadow.appendChild(wrap);

    UI.root = host; UI.shadow = shadow;
    UI.els = {
      wrap,
      feedDot: shadow.getElementById("feedDot"),
      cnt: shadow.getElementById("cnt"),
      body: shadow.getElementById("body"),
      tbody: shadow.getElementById("tbody"),
      manual: shadow.getElementById("manual"),
      manualList: shadow.getElementById("manualList"),
      btnManual: shadow.getElementById("btnManual"),
      btnMin: shadow.getElementById("btnMin"),
      head: wrap.querySelector(".head"),
    };

    UI.els.btnMin.addEventListener("click", () => {
      const b = UI.els.body, hidden = b.classList.toggle("hidden");
      UI.els.btnMin.textContent = hidden ? "+" : "–";
    });
    UI.els.btnManual.addEventListener("click", () => {
      UI.els.manual.classList.toggle("hidden");
    });

    makeDraggable(wrap, UI.els.head);
  }

  // ms -> "+1.2s" / "-0.4s"
  function fmtDiff(ms) {
    const sign = ms >= 0 ? "+" : "−";
    return sign + Math.abs(ms / 1000).toFixed(1) + "s";
  }

  const QSYM = { goal: "⚽", lmt: "", minute: "≈", rough: "~" };

  function setFeedDot(state) {
    const d = UI.els.feedDot;
    if (!d) return;
    d.className = "dot " + (state === "open" ? "ok" : state === "closed" || state === "error" ? "err" : "warn");
  }

  // Render principale: riceve la lista abbinamenti risolti + stato feed globale.
  function render(model) {
    if (!UI.root) return;
    const { matched, unmatchedBet, gbRows, feedState } = model;

    setFeedDot(feedState);
    UI.els.cnt.textContent = matched.length;

    // ---- tabella partite abbinate ----
    const tb = UI.els.tbody;
    tb.textContent = "";
    if (matched.length === 0) {
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      td.colSpan = 5; td.className = "empty";
      td.textContent = "Nessuna partita abbinata. Verifica il feed (pallino) e gli abbinamenti.";
      tr.appendChild(td); tb.appendChild(tr);
    } else {
      for (const m of matched) {
        const br = m.brRec;
        const v = m.view;                              // {ms, quality, state}
        const secB = GBS.betradar.secBetradar(br);
        const clockB = secB == null ? "—" : mmss(secB);

        const tr = document.createElement("tr");

        const tdTeams = document.createElement("td");
        const fdot = document.createElement("span");
        fdot.className = "fdot " + (v.state === "stale" ? "warn" : v.state === "ok" ? "ok" : "warn");
        tdTeams.appendChild(fdot);
        tdTeams.appendChild(document.createTextNode(`${br.home} – ${br.away}`));

        const tdScore = document.createElement("td");
        tdScore.className = "score";
        tdScore.textContent = `${br.scoreH ?? "-"}:${br.scoreA ?? "-"}`;

        const tdPer = document.createElement("td");
        tdPer.className = "per";
        tdPer.textContent = v.state === "paused" ? "PAUSA" : (br.periodo || "");

        const tdClock = document.createElement("td");
        tdClock.className = "clock";
        tdClock.textContent = clockB;

        const tdDiff = document.createElement("td");
        tdDiff.className = "diff " + diffClass(v);
        if (v.state === "paused" || v.ms == null) {
          tdDiff.textContent = v.state === "paused" ? "pausa" : "—";
        } else {
          const q = QSYM[v.quality] ?? "";
          tdDiff.innerHTML = `${fmtDiff(v.ms)}<span class="q">${q}</span>`;
        }

        tr.append(tdTeams, tdScore, tdPer, tdClock, tdDiff);
        tb.appendChild(tr);
      }
    }

    // ---- sezione abbinamenti manuali ----
    renderManual(unmatchedBet, gbRows);
  }

  function diffClass(v) {
    if (v.state === "paused" || v.ms == null) return "flat";
    if (Math.abs(v.ms) < GBS.C.GRAY_THRESHOLD_MS) return "flat";
    return v.ms > 0 ? "ahead" : "behind";
  }

  function renderManual(unmatchedBet, gbRows) {
    const list = UI.els.manualList;
    list.textContent = "";
    if (!unmatchedBet || unmatchedBet.length === 0) {
      const d = document.createElement("div");
      d.className = "empty"; d.style.padding = "6px";
      d.textContent = "Tutte le partite Betradar sono abbinate.";
      list.appendChild(d);
      return;
    }
    for (const br of unmatchedBet) {
      const row = document.createElement("div");
      row.className = "mrow";
      const nm = document.createElement("span");
      nm.className = "nm";
      nm.textContent = `${br.home} – ${br.away}`;
      const sel = document.createElement("select");
      const opt0 = document.createElement("option");
      opt0.value = ""; opt0.textContent = "— scegli riga Goldbet —";
      sel.appendChild(opt0);
      for (const gb of gbRows) {
        const o = document.createElement("option");
        o.value = gb.key;
        o.textContent = `${gb.home} – ${gb.away}`;
        sel.appendChild(o);
      }
      sel.addEventListener("change", () => {
        if (sel.value && typeof UI.onManualPick === "function") {
          UI.onManualPick(br.id, sel.value);
        }
      });
      row.append(nm, sel);
      list.appendChild(row);
    }
  }

  function mmss(sec) {
    sec = Math.max(0, Math.floor(sec));
    const m = Math.floor(sec / 60), s = sec % 60;
    return String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
  }

  function makeDraggable(box, handle) {
    let sx=0, sy=0, ox=0, oy=0, drag=false;
    handle.addEventListener("mousedown", (e) => {
      if (e.target.tagName === "BUTTON") return;
      drag = true; sx=e.clientX; sy=e.clientY;
      const r = box.getBoundingClientRect(); ox=r.left; oy=r.top;
      box.style.right="auto"; box.style.left=ox+"px"; box.style.top=oy+"px";
      e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!drag) return;
      box.style.left = ox + (e.clientX - sx) + "px";
      box.style.top  = oy + (e.clientY - sy) + "px";
    });
    window.addEventListener("mouseup", () => { drag = false; });
  }

  UI.build = build;
  UI.render = render;
  UI.setFeedDot = setFeedDot;

  GBS.log("ui.js caricato");
})();
