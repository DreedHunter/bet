/* =============================================================================
 * betradar.js — store delle partite dal feed + estrapolazione orologio.
 *
 * Mappa: GBS.betradar.matches[scout.id] = {
 *   id, home, away, scoreH, scoreA, statusRaw, periodo,
 *   clockTxt, clockSec, running, tickTs,       // dal messaggio
 *   lastMsgTs,                                  // Date.now() ultimo msg (staleness)
 *   crossedAt: Map(sec -> Date.now()),          // istante in cui secBetradar ha
 *                                               // attraversato ogni valore intero
 *   prevScoreKey, scoreChangedAt,               // per la misura sul gol
 * }
 *
 * Estrapolazione (spec §2):
 *   secBetradar = clockSec + (running ? (Date.now() - tickTs)/1000 : 0)
 * ========================================================================== */

(() => {
  "use strict";
  const GBS = window.GBS;

  const B = (GBS.betradar = {
    matches: new Map(),   // scout.id -> record
  });

  const VALID_PERIODS = new Set(["1T", "2T", "HT", "FT", "ET", "RIG", "NS"]);

  // Registra l'attraversamento dei secondi interi tra due letture del clock,
  // così il motore misura sa "a che ora Betradar ha toccato il secondo X".
  function recordCrossings(rec, prevSec, newSec, now) {
    if (prevSec == null) return;
    const from = Math.floor(prevSec);
    const to = Math.floor(newSec);
    if (to <= from) return;                 // fermo o indietro: niente crossing
    // Per non esplodere in memoria teniamo solo gli ultimi ~200 valori.
    for (let s = from + 1; s <= to; s++) {
      // interpola l'istante in cui ha attraversato s (lineare tra le due letture)
      rec.crossedAt.set(s, now);
    }
    if (rec.crossedAt.size > 250) {
      const cutoff = to - 200;
      for (const k of rec.crossedAt.keys()) if (k < cutoff) rec.crossedAt.delete(k);
    }
  }

  // Gestisce UN messaggio in arrivo dal relay.
  function onMessage(msg) {
    if (!msg || typeof msg !== "object") return;

    // Il publisher legacy single-match usa "scores"/"events": ignoralo (spec §2)
    if (msg.scores || msg.events) return;

    if (msg.type !== "DATA" || !msg.scout || !msg.scout.id) return;

    const s = msg.scout;
    const id = String(s.id);
    const now = Date.now();

    let rec = B.matches.get(id);
    if (!rec) {
      rec = {
        id,
        crossedAt: new Map(),
        prevScoreKey: null,
        scoreChangedAt: 0,
        _prevSecBetradar: null,
        _firstScoreSeen: false,
      };
      B.matches.set(id, rec);
    }

    // aggiorna campi
    rec.home = s.home;
    rec.away = s.away;
    rec.scoreH = s.scoreH;
    rec.scoreA = s.scoreA;
    rec.statusRaw = s.statusRaw;
    rec.periodo = VALID_PERIODS.has(s.periodo) ? s.periodo : (s.periodo || "");
    rec.clockTxt = s.clockTxt;
    rec.clockSec = Number(s.clockSec) || 0;
    rec.running = !!s.running;
    rec.tickTs = Number(s.tickTs) || now;
    rec.lastMsgTs = now;

    // --- crossing dei secondi (per misura scatto-minuto) ---
    const secNow = secBetradar(rec);
    recordCrossings(rec, rec._prevSecBetradar, secNow, now);
    rec._prevSecBetradar = secNow;

    // --- cambio punteggio (per misura sul gol, spec §4.5) ---
    const scoreKey = `${rec.scoreH}:${rec.scoreA}`;
    if (rec.prevScoreKey === null) {
      // PRIMA lettura del punteggio: inizializzazione, NON e' un gol
      rec.prevScoreKey = scoreKey;
      rec._firstScoreSeen = true;
    } else if (scoreKey !== rec.prevScoreKey) {
      rec.prevScoreKey = scoreKey;
      rec.scoreChangedAt = now;   // istante del gol lato Betradar
      GBS.log("Betradar GOL", rec.home, rec.away, scoreKey);
    }
  }

  // Orologio Betradar estrapolato (in SECONDI, float).
  function secBetradar(rec) {
    if (!rec) return null;
    const base = rec.clockSec || 0;
    if (!rec.running) return base;                 // fermo: congela (spec §4.7)
    return base + (Date.now() - rec.tickTs) / 1000;
  }

  // La partita ha dati "vecchi"? (nessun messaggio da >10s)
  function isStale(rec) {
    return !rec || (Date.now() - (rec.lastMsgTs || 0) > GBS.C.FEED_STALE_MS);
  }

  // Cerca l'istante (Date.now) in cui Betradar ha attraversato il secondo target.
  // Se non registrato, stima con l'estrapolazione corrente.
  function tsWhenCrossed(rec, targetSec) {
    if (!rec) return null;
    const exact = rec.crossedAt.get(Math.floor(targetSec));
    if (exact != null) return exact;
    // fallback: se ora siamo oltre il target e running, stima all'indietro
    const nowSec = secBetradar(rec);
    if (nowSec == null || !rec.running) return null;
    const deltaSec = nowSec - targetSec;
    if (deltaSec < 0) return null;                 // non ancora raggiunto
    return Date.now() - deltaSec * 1000;
  }

  B.onMessage = onMessage;
  B.secBetradar = secBetradar;
  B.isStale = isStale;
  B.tsWhenCrossed = tsWhenCrossed;

  // aggancia il client WS a questo store
  if (GBS.ws) GBS.ws._onMessage = onMessage;

  GBS.log("betradar.js caricato");
})();
