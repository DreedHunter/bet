/* =============================================================================
 * util.js — funzioni condivise (namespace globale window.GBS)
 * Caricato per primo: crea l'oggetto GBS su cui gli altri moduli appendono.
 * ========================================================================== */

(() => {
  "use strict";
  const GBS = (window.GBS = window.GBS || {});

  // --- costanti di configurazione -------------------------------------------
  GBS.C = {
    RECONNECT_MS: 3000,        // riconnessione WebSocket
    FEED_STALE_MS: 10000,      // partita senza messaggi -> "dati vecchi"
    GOLDBET_SCAN_MS: 800,      // ricerca periodica righe Goldbet (ri-aggancio)
    UI_TICK_MS: 250,           // refresh overlay
    MEASURE_BUFFER: 5,         // ultime N misure per mediana
    OUTLIER_MS: 20000,         // scarto outlier oltre 20s dalla mediana
    ABSURD_MS: 300000,         // misura assurda oltre 5 min -> scarta
    GRAY_THRESHOLD_MS: 300,    // |diff| < 300ms -> grigio (allineati)
    GOAL_PRIORITY_MS: 120000,  // priorita' visualizzazione misura-gol per 2 min
  };

  // --- log sicuro (prefissato, non esplode mai) -----------------------------
  GBS.log = (...a) => { try { console.log("%c[GBS]", "color:#f2b705", ...a); } catch (_) {} };
  GBS.warn = (...a) => { try { console.warn("[GBS]", ...a); } catch (_) {} };

  // Wrapper per cicli periodici: un errore non deve fermare il monitor.
  GBS.safe = (fn) => {
    try { return fn(); } catch (e) { GBS.warn("errore in ciclo periodico:", e); }
  };

  // --- normalizzazione nomi squadra ------------------------------------------
  // minuscole, rimuove accenti (NFD + strip combining), tiene solo [a-z0-9]
  GBS.normName = (s) => {
    if (!s) return "";
    return String(s)
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")   // combining diacritics
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "");
  };

  // --- statistica ------------------------------------------------------------
  GBS.median = (arr) => {
    if (!arr || arr.length === 0) return null;
    const a = [...arr].sort((x, y) => x - y);
    const m = Math.floor(a.length / 2);
    return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
  };

  GBS.clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  // testo pulito da un nodo DOM
  GBS.txt = (el) => (el ? el.textContent.replace(/\s+/g, " ").trim() : "");

  GBS.log("util.js caricato");
})();
