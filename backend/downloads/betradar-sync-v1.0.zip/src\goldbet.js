/* =============================================================================
 * goldbet.js — lettura delle righe live dalla pagina Goldbet (app Angular).
 *
 * REGOLE CRITICHE (spec §3, §4):
 *  - MAI agganciarsi agli hash _ngcontent-gadplatform-cXXXX o a ng-star-inserted.
 *    Solo classi semantiche.
 *  - Il minuto Goldbet "34'" = 34° minuto IN CORSO -> cronometro reale 33:00..33:59.
 *    Lo scatto a "34'" avviene quando il cronometro tocca 33:00.
 *    => secGoldbet all'istante dello scatto = (min - 1) * 60.
 *  - PRIMA lettura != scatto: alla scoperta/ri-aggancio la prima lettura serve
 *    solo per la stima grezza centrata (min-1)*60 + 30, MAI come misura.
 *  - Reset a ogni ri-aggancio: le righe vengono distrutte/ricreate (virtual
 *    scroll / re-render). Al ritrovamento azzeriamo lo stato del minuto, altrimenti
 *    generiamo scatti finti a meta' minuto.
 *
 * Ogni riga tracciata ha un WeakMap-state legato all'elemento DOM; se l'elemento
 * viene sostituito, il nuovo elemento riparte "pulito" (isFirst=true).
 *
 * Espone GBS.goldbet.rows: Map(rowKey -> {el, home, away, min, scoreH, scoreA, ...})
 * e callback GBS.goldbet.on = { minuteTick, scoreTick, rowsChanged }.
 * ========================================================================== */

(() => {
  "use strict";
  const GBS = window.GBS;
  const { txt } = GBS;

  const G = (GBS.goldbet = {
    rows: new Map(),                 // rowKey (home|away) -> record
    on: { minuteTick: null, scoreTick: null, rowsChanged: null },
  });

  // --- selettori (con fallback verificati sullo snapshot) --------------------
  // IMPORTANTE: nel DOM reale minuto, squadre e punteggio sono FRATELLI dentro
  // <app-scommesse-row-event>. Percio' la "riga" e' il contenitore row-event,
  // non .row--teams_live (che contiene solo i nomi). Fallback su .row--teams_live
  // per compatibilita' con eventuali layout diversi.
  const SEL = {
    row: ["app-scommesse-row-event", ".row-event", ".row--teams_live"],
    // Minuto: prima il nome da spec, poi quello osservato nello snapshot reale.
    minute: [".row--teams_live_time_text", ".row_first-column_isLive_minutes"],
    names: ".row--teams_live_names",
    score: ".ultimo-risultato_punteggio",
  };

  function firstMatch(el, selectors) {
    for (const s of selectors) {
      const found = el.querySelector(s);
      if (found) return found;
    }
    return null;
  }

  // Seleziona le righe usando il PRIMO selettore (tra SEL.row) che produce
  // risultati. Cosi' funziona sia col contenitore row-event reale sia coi
  // fallback, senza duplicare le righe.
  function queryRows() {
    for (const s of SEL.row) {
      const list = document.querySelectorAll(s);
      if (list.length) return list;
    }
    return document.querySelectorAll(SEL.row[SEL.row.length - 1]);
  }

  function parseMin(raw) {
    if (!raw) return null;
    const m = raw.match(/(\d{1,3})/);
    return m ? parseInt(m[1], 10) : null;
  }

  // Legge i dati grezzi di una riga (senza logica temporale).
  function readRow(rowEl) {
    const namesEl = rowEl.querySelector(SEL.names);
    if (!namesEl) return null;                      // header categoria, non partita
    const nd = namesEl.querySelectorAll("div");
    if (nd.length < 2) return null;
    const home = txt(nd[0]), away = txt(nd[1]);
    if (!home || !away) return null;

    const min = parseMin(txt(firstMatch(rowEl, SEL.minute)));

    let scoreH = null, scoreA = null;
    const sb = rowEl.querySelector(SEL.score);
    if (sb) {
      const cells = sb.querySelectorAll("div");
      if (cells.length >= 2) { scoreH = txt(cells[0]); scoreA = txt(cells[1]); }
    }
    return { home, away, min, scoreH, scoreA };
  }

  function rowKey(d) { return GBS.normName(d.home) + "|" + GBS.normName(d.away); }

  // Stato per-elemento: se l'elemento DOM cambia, lo stato riparte pulito.
  // Usiamo una proprieta' non-enumerabile sull'elemento (piu' semplice del WeakMap
  // per il caso "stesso elemento ri-osservato").
  function elState(el) {
    if (!el.__gbs) {
      Object.defineProperty(el, "__gbs", {
        value: { lastMin: null, lastScoreKey: null, seenOnce: false },
        enumerable: false, writable: true, configurable: true,
      });
    }
    return el.__gbs;
  }

  // Scansione completa: aggiorna la mappa, gestisce ri-aggancio + reset,
  // emette minuteTick/scoreTick con isFirst corretto.
  function scan() {
    const now = Date.now();
    const seenKeys = new Set();
    let changed = false;

    queryRows().forEach((rowEl) => {
      const d = readRow(rowEl);
      if (!d) return;

      const key = rowKey(d);
      seenKeys.add(key);
      const st = elState(rowEl);

      let rec = G.rows.get(key);
      if (!rec || rec.el !== rowEl) {
        // NUOVA riga o elemento RICREATO -> reset (spec §4.2)
        rec = {
          el: rowEl, key,
          home: d.home, away: d.away,
          min: d.min, scoreH: d.scoreH, scoreA: d.scoreA,
          firstSeenTs: now,
        };
        G.rows.set(key, rec);
        st.lastMin = null;
        st.lastScoreKey = null;
        st.seenOnce = false;
        changed = true;
      }

      rec.el = rowEl;
      rec.home = d.home; rec.away = d.away;

      // ---- MINUTO ----
      if (d.min != null) {
        const isFirst = !st.seenOnce || st.lastMin == null;
        if (st.lastMin == null) {
          // prima lettura dopo (ri)aggancio: stima grezza, NON misura
          st.lastMin = d.min;
          emitMinute(rec, d.min, now, /*isFirst*/ true);
        } else if (d.min !== st.lastMin) {
          // SCATTO reale del minuto
          st.lastMin = d.min;
          emitMinute(rec, d.min, now, /*isFirst*/ false);
        }
        rec.min = d.min;
      }
      st.seenOnce = true;

      // ---- PUNTEGGIO ----
      if (d.scoreH != null && d.scoreA != null) {
        const sk = `${d.scoreH}:${d.scoreA}`;
        if (st.lastScoreKey == null) {
          st.lastScoreKey = sk;                       // init, non e' gol
          emitScore(rec, d.scoreH, d.scoreA, now, /*isFirst*/ true);
        } else if (sk !== st.lastScoreKey) {
          st.lastScoreKey = sk;
          emitScore(rec, d.scoreH, d.scoreA, now, /*isFirst*/ false);  // GOL
        }
        rec.scoreH = d.scoreH; rec.scoreA = d.scoreA;
      }
    });

    // rimuovi righe scomparse da un po'
    for (const [key, rec] of G.rows) {
      if (!seenKeys.has(key) && !rec.el.isConnected) { G.rows.delete(key); changed = true; }
    }

    if (changed && typeof G.on.rowsChanged === "function") GBS.safe(G.on.rowsChanged);
  }

  function emitMinute(rec, min, ts, isFirst) {
    if (typeof G.on.minuteTick === "function")
      GBS.safe(() => G.on.minuteTick(rec, min, ts, isFirst));
  }
  function emitScore(rec, sh, sa, ts, isFirst) {
    if (typeof G.on.scoreTick === "function")
      GBS.safe(() => G.on.scoreTick(rec, sh, sa, ts, isFirst));
  }

  // --- avvio: MutationObserver (scatti immediati) + scan periodico -----------
  function start() {
    const mo = new MutationObserver(() => {
      clearTimeout(mo._t);
      mo._t = setTimeout(() => GBS.safe(scan), 60);   // debounce, reazione rapida
    });
    mo.observe(document.body, { subtree: true, childList: true, characterData: true });

    // ricerca periodica per ri-aggancio (controllo isConnected implicito nello scan)
    setInterval(() => GBS.safe(scan), GBS.C.GOLDBET_SCAN_MS);

    GBS.safe(scan);
  }

  G.scan = scan;
  G.start = start;

  GBS.log("goldbet.js caricato");
})();
