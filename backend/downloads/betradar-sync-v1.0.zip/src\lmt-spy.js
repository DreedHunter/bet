/* =============================================================================
 * lmt-spy.js — "spia" per lo scoreboard Sportradar LMT (ha i SECONDI).
 *
 * Gira in OGNI frame (manifest all_frames). Se il frame contiene l'orologio
 * LMT (.sr-lmt-plus-scb__clock), legge "mm:ss" e manda i tick al frame
 * principale con window.top.postMessage. Il main.js li ascolta.
 *
 * NB: e' un file separato NON incluso in manifest.json come modulo del monitor;
 * viene caricato da main.js SOLO quando serve? No: piu' semplice includerlo
 * nella lista content_scripts. Qui lo teniamo autonomo e idempotente.
 *
 * Timestamp con Date.now() (confrontabile tra frame). (spec §7)
 * ========================================================================== */

(() => {
  "use strict";

  const CLOCK_SEL = ".sr-lmt-plus-scb__clock";
  const MSG_TYPE = "GBS_LMT_TICK";

  // Evita doppio avvio nello stesso frame
  if (window.__gbsLmtSpy) return;
  window.__gbsLmtSpy = true;

  function parseClock(txt) {
    if (!txt) return null;
    const m = txt.trim().match(/(\d{1,3}):(\d{2})/);
    if (!m) return null;
    return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);   // secondi totali
  }

  let lastSec = null;

  function readAndPost() {
    const el = document.querySelector(CLOCK_SEL);
    if (!el) return;
    const sec = parseClock(el.textContent);
    if (sec == null) return;

    // posta solo quando cambia (evita spam), col timestamp dello scatto
    if (sec !== lastSec) {
      lastSec = sec;
      const payload = {
        type: MSG_TYPE,
        sec,
        ts: Date.now(),
        // qualche indizio per l'abbinamento lato main (se disponibile nel widget)
        href: location.href,
      };
      try { window.top.postMessage(payload, "*"); } catch (_) {}
    }
  }

  function start() {
    // Reagisci ai cambi del clock (MutationObserver) + fallback periodico.
    try {
      const mo = new MutationObserver(() => readAndPost());
      mo.observe(document.body, { subtree: true, childList: true, characterData: true });
    } catch (_) {}
    setInterval(() => { try { readAndPost(); } catch (_) {} }, 500);
    readAndPost();
  }

  // Parte solo se ha senso: se non c'e' il clock ora, riprova per un po'
  // (il widget puo' caricare in ritardo). Se dopo 30s niente, resta dormiente
  // ma l'interval continua a costare pochissimo.
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
