/* =============================================================================
 * main.js — orchestratore. Collega WS + betradar + goldbet + matcher + measure + ui.
 *
 * Architettura frame:
 *  - Questo bundle (manifest #1) e' iniettato SOLO nel frame top di goldbet.it
 *    (all_frames:false) => qui gira il monitor completo.
 *  - La spia LMT (lmt-spy.js, manifest #2) gira in TUTTI i frame e posta i tick
 *    a window.top; li riceviamo qui con window.addEventListener('message').
 *
 * Timestamp sempre Date.now() (confrontabili tra frame). (spec §7)
 * ========================================================================== */

(() => {
  "use strict";
  const GBS = window.GBS;

  // gira solo nel frame principale
  if (window.top !== window.self) return;
  if (window.__gbsMainStarted) return;
  window.__gbsMainStarted = true;

  const MZ = GBS.measure;

  function start() {
    // 1) UI
    GBS.ui.build();
    GBS.ui.onManualPick = (betId, gbKey) => {
      GBS.matcher.setManual(betId, gbKey);
      GBS.safe(refreshMatchesAndRender);
    };

    // 2) stato feed -> pallino
    GBS.ws._onStatus = (state) => GBS.ui.setFeedDot(state);

    // 3) abbina i tick Goldbet al motore misura
    GBS.goldbet.on.minuteTick = MZ.onGoldbetMinute;
    GBS.goldbet.on.scoreTick = MZ.onGoldbetScore;
    GBS.goldbet.on.rowsChanged = () => GBS.safe(refreshMatchesAndRender);

    // 4) tick LMT dagli iframe (spia)
    window.addEventListener("message", onLmtMessage);

    // 5) carica abbinamenti manuali, poi avvia feed + lettura DOM
    GBS.matcher.load(() => {
      GBS.ws.boot();       // connette il WebSocket (e riconnette ai cambi config)
      GBS.goldbet.start(); // MutationObserver + scan periodico
    });

    // 6) cicli periodici: aggiorna abbinamenti + render UI
    setInterval(() => GBS.safe(refreshMatchesAndRender), GBS.C.UI_TICK_MS);
    setInterval(() => GBS.safe(refreshMatchesAndRender), GBS.C.GOLDBET_SCAN_MS);

    GBS.log("main avviato (frame top)");
  }

  // Ricalcola gli abbinamenti, aggiorna l'indice gbKey->betId per il motore
  // misura, costruisce il modello e ridisegna.
  let lastResolve = { results: [], unmatchedBet: [], unmatchedGb: [] };

  function refreshMatchesAndRender() {
    const res = GBS.matcher.resolve();
    lastResolve = res;

    // aggiorna indice gbKey -> betId (solo per abbinati) per measure.js
    MZ.gbKeyToBet.clear();
    for (const r of res.results) {
      if (r.gbRec) MZ.gbKeyToBet.set(r.gbRec.key, r.betId);
    }

    // costruisci il modello per la UI (solo partite abbinate mostrate in tabella)
    const matched = res.results
      .filter((r) => r.gbRec)
      .map((r) => ({ ...r, view: MZ.view(r.betId) }));

    // ordina: gol recente prima, poi per |diff| decrescente, poi per periodo
    matched.sort((a, b) => {
      const ag = a.view.quality === "goal" ? 1 : 0;
      const bg = b.view.quality === "goal" ? 1 : 0;
      if (ag !== bg) return bg - ag;
      const am = a.view.ms == null ? -1 : Math.abs(a.view.ms);
      const bm = b.view.ms == null ? -1 : Math.abs(b.view.ms);
      return bm - am;
    });

    GBS.ui.render({
      matched,
      unmatchedBet: res.unmatchedBet,
      gbRows: [...GBS.goldbet.rows.values()],
      feedState: GBS.ws.connected ? "open" : "closed",
    });
  }

  // ---- gestione tick LMT (dagli iframe) ------------------------------------
  // La spia non conosce il betId. Associamo il tick alla partita abbinata la cui
  // estrapolazione Betradar e' piu' vicina al valore LMT ricevuto (best-effort).
  // Se c'e' una sola partita abbinata, va a quella.
  function onLmtMessage(ev) {
    const d = ev && ev.data;
    if (!d || d.type !== "GBS_LMT_TICK" || typeof d.sec !== "number") return;

    const candidates = lastResolve.results.filter((r) => r.gbRec);
    if (candidates.length === 0) return;

    let best = null, bestDelta = Infinity;
    for (const r of candidates) {
      const br = GBS.betradar.matches.get(r.betId);
      if (!br) continue;
      const secB = GBS.betradar.secBetradar(br);
      if (secB == null) continue;
      const delta = Math.abs(secB - d.sec);
      if (delta < bestDelta) { bestDelta = delta; best = r; }
    }
    // accetta solo se plausibile (entro 3 minuti dall'orologio Betradar)
    if (best && bestDelta <= 180) {
      MZ.onLmtTick(best.betId, d.sec, d.ts || Date.now());
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
