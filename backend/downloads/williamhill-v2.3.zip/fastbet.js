(function () {
  "use strict";

  // ═══════════════════════════════════════════════════════════════════════════
  // William Hill Fast Bet v2.3 — MAIN world.
  //
  // PIATTAFORMA: xSport (sports.williamhill.it, endpoint /XSportDatastore/…).
  //   Piazzamento: POST /XSportDatastore/purchase → risponde code -9996 con un
  //   "delay" dichiarato dal server (~10s, tempo reale ADM/Sogei), poi polling
  //   POST /getScheduledPurchaseTransaction finché code:0 + ticketSogei = confermata.
  //
  // COSA FA:
  //   1) DOPPIO-CLICK su una quota → costruisce e invia la purchase col TUO importo,
  //      saltando carrello/importo/Scommetti manuali. Piazzi in un gesto.
  //   2) HOTKEY Casa/Ospite → registri due quote (come su Lottomatica) e le giochi
  //      da tastiera con il tasto scelto.
  //
  // COME COSTRUISCE IL PAYLOAD (cattura & replica):
  //   Il payload purchase di xSport è enorme. Invece di ricostruirlo, CATTURIAMO la
  //   prima purchase reale che fai a mano e ne salviamo la struttura come TEMPLATE.
  //   Da lì, per ogni giocata rapida, prendiamo il template e ci iniettiamo la
  //   selezione cliccata + il tuo importo. Il "contorno" resta corretto.
  //
  // ⚠️ ONESTÀ: l'attesa di ~10s dopo l'invio è il delay REALE del server (ADM/Sogei),
  //   NON azzerabile. L'estensione velocizza il TUO invio, non l'accettazione.
  // ═══════════════════════════════════════════════════════════════════════════

  const LS_STAKE      = "whfb_stake";
  const LS_TEMPLATE   = "whfb_purchase_tpl";
  const LS_ENABLED    = "whfb_enabled";
  const LS_KEY_CASA   = "whfb_key_casa";
  const LS_KEY_OSPITE = "whfb_key_ospite";
  const LS_SEL_CASA   = "whfb_sel_casa";
  const LS_SEL_OSPITE = "whfb_sel_ospite";

  let stake    = 2.0;
  let enabled  = true;
  let keyCasa  = null, keyOspite = null;
  let recMode  = null;   // "sel-casa" | "sel-ospite" quando si registra una quota
  let recKey   = null;   // "casa" | "ospite" quando si registra un tasto

  try { const s = parseFloat(localStorage.getItem(LS_STAKE)); if (s > 0) stake = s; } catch (e) {}
  try { enabled = localStorage.getItem(LS_ENABLED) !== "0"; } catch (e) {}
  try { keyCasa = localStorage.getItem(LS_KEY_CASA) || null; } catch (e) {}
  try { keyOspite = localStorage.getItem(LS_KEY_OSPITE) || null; } catch (e) {}

  const API  = "/XSportDatastore/purchase";
  const POLL = "/XSportDatastore/getScheduledPurchaseTransaction";

  // ───────────────────── cattura template purchase ─────────────────────
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    this._whUrl = url || "";
    return _open.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (this._whUrl && this._whUrl.indexOf(API) !== -1 && body && !this._whFast) {
        try {
          const decoded = decodeURIComponent(String(body));
          const obj = JSON.parse(decoded);
          if (extractSelectionFromPayload(obj)) {
            localStorage.setItem(LS_TEMPLATE, decoded);
            // salviamo anche il token dalla URL, se presente
            const tm = this._whUrl.match(/[?&]token=([^&]+)/);
            if (tm) localStorage.setItem("whfb_token", tm[1]);
            toast("Modello giocata catturato ✓ — Fast Bet pronta", "ok");
          }
        } catch (e) {}
      }
    } catch (e) {}
    return _send.apply(this, arguments);
  };

  function extractSelectionFromPayload(obj) {
    try {
      const c1 = obj.betslip.coupons["1"];
      const sel = (c1.selections && c1.selections[0]) ||
                  (c1.multipleBonus && c1.multipleBonus.bonusElements && c1.multipleBonus.bonusElements[0]);
      if (sel && sel.bets && sel.bets[0]) return sel;
    } catch (e) {}
    return null;
  }

  // ───────────────────── lettura selezione dalla quota (DOM) ─────────────────────
  function readSelectionFromQuota(quotaEl) {
    try {
      const barra = quotaEl.closest('[id^="barra-extra-"]');
      let scomSogei = null, handicap = null, idEvento = null;
      if (barra) {
        const m = barra.id.match(/barra-extra-(\d+)_(\d+)_(\d+)_(\d+)_(\d+)_([\d;]+)/);
        if (m) { idEvento = m[4]; scomSogei = m[5]; handicap = m[6]; }
      }
      const spans = quotaEl.querySelectorAll("span");
      let descDraw = null, oddText = null;
      if (spans.length >= 2) {
        descDraw = (spans[0].textContent || "").replace(/\s*\(\d+\)\s*/, "").trim();
        oddText  = (spans[spans.length - 1].textContent || "").trim();
      }
      const odd = oddText ? Math.round(parseFloat(oddText.replace(",", ".")) * 100) : null;
      return { scomSogei, handicap, idEvento, descDraw, odd, oddText };
    } catch (e) { return null; }
  }

  function isQuota(el) {
    if (!el) return null;
    const q = el.closest(".quota, .quota-con-nome");
    return (q && q.closest('[id^="barra-extra-"]')) ? q : null;
  }

  // ───────────────────── costruzione & invio purchase ─────────────────────
  function fastPurchase(selData) {
    const tplStr = (() => { try { return localStorage.getItem(LS_TEMPLATE); } catch (e) { return null; } })();
    if (!tplStr) {
      toast("Prima fai UNA giocata normale a mano: serve per catturare il modello. Poi la Fast Bet è pronta.", "warn", 7000);
      return;
    }
    if (!selData || !selData.scomSogei || selData.odd == null) {
      toast("Non riesco a leggere la selezione da questa quota.", "warn");
      return;
    }
    let tpl;
    try { tpl = JSON.parse(tplStr); } catch (e) { toast("Modello non valido: rifai una giocata normale.", "warn"); return; }

    const amountCents = Math.round(stake * 100);
    const printable = stake.toFixed(2).replace(".", ",");
    const baseSel = extractSelectionFromPayload(tpl) || {};

    const newBet = {
      scomSogei: parseInt(selData.scomSogei, 10),
      handicap: String(selData.handicap || "").split(";")[0],
      draw: 1,
      odd: String(selData.odd),
      legabile: false,
      combinationType: 0,
      amount: amountCents,
      printableAmount: printable,
      descBet: (baseSel.bets && baseSel.bets[0].descBet) || "",
      descDraw: selData.descDraw || "",
      minPlError: false, maxPlError: false, minOddError: null,
      isBonusMultiple: false, updated: null
    };
    const newSel = {
      pal: baseSel.pal, avv: baseSel.avv, banker: false,
      descEvent: baseSel.descEvent || "", isLive: true, bets: [newBet],
      alias: baseSel.alias || "", descSport: baseSel.descSport || "",
      descTournament: baseSel.descTournament || "",
      sportId: baseSel.sportId || 1, tournamentId: baseSel.tournamentId || 0,
      timestamp: baseSel.timestamp || "", matchData: baseSel.matchData || {}
    };

    try {
      const c1 = tpl.betslip.coupons["1"];
      c1.selections = [newSel];
      c1.selectedContainer = "singlebets";
      c1.amountSingle = amountCents;
      c1.amountMulti = amountCents;
      c1.betOnAll = amountCents;
      c1.printableBetOnAll = printable;
      c1.printableAmountMulti = printable;
      if (c1.multipleBonus) { c1.multipleBonus.bonusElements = []; c1.multipleBonus.applied = false; }
      tpl.betslip.selectedCoupon = "1";
      const fe = tpl.frontendTransactionId || "WILLIAMHILL-0-0";
      tpl.frontendTransactionId = fe.replace(/-\d+$/, "-" + Date.now());
    } catch (e) { toast("Errore nel costruire la giocata.", "warn"); return; }

    const token = (() => { try { return localStorage.getItem("whfb_token") || ""; } catch (e) { return ""; } })();
    const url = API + "?systemCode=WILLIAMHILL&lingua=IT&hash=&token=" + token + "&shopUserType=";
    const xhr = new XMLHttpRequest();
    xhr._whFast = true;
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8;");
    xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
    xhr.setRequestHeader("Cache-Control", "no-transform");
    const t0 = performance.now();
    toast(`Invio ${printable}€ su «${newBet.descDraw}» @${selData.oddText}…`, "info", 12000);
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      try {
        const data = JSON.parse(xhr.responseText);
        const rc = data && data.returnCode;
        const tx = rc && rc.object && rc.object.transactionId;
        if (rc && (rc.code === -9996 || rc.code === 0) && tx) {
          const delay = (rc.object && rc.object.delay) || "?";
          toast(`In elaborazione (delay server ~${delay}s)…`, "info", 14000);
          pollOutcome(tx, t0);
        } else {
          toast(`Giocata rifiutata (code ${rc ? rc.code : "?"}).`, "warn", 6000);
        }
      } catch (e) { toast("Risposta inattesa dal server.", "warn"); }
    };
    try { xhr.send(encodeURIComponent(JSON.stringify(tpl))); }
    catch (e) { toast("Errore invio.", "warn"); }
  }

  function pollOutcome(transactionId, t0) {
    let tries = 0;
    const tick = () => {
      tries++;
      const xhr = new XMLHttpRequest();
      xhr._whFast = true;
      xhr.open("POST", POLL, true);
      xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8;");
      xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== 4) return;
        try {
          const data = JSON.parse(xhr.responseText);
          const rc = data && (data.returnCode ||
                     (data.responseSingle && data.responseSingle.returnCode) ||
                     (data.responseMultiple && data.responseMultiple.returnCode));
          const code = rc ? rc.code : null;
          const ticket = findTicket(data);
          if (code === 0 && ticket) {
            const ms = Math.round(performance.now() - t0);
            toast(`✓ CONFERMATA (ticket ${ticket}) — ${(ms/1000).toFixed(1)}s`, "ok", 8000);
            return;
          }
          if (code != null && code !== -9996 && code !== -9995 && code !== 0) {
            toast(`Esito: code ${code}. Controlla lo storico.`, "warn", 7000);
            return;
          }
        } catch (e) {}
        if (tries < 25) setTimeout(tick, 900);
        else toast("Esito non ricevuto — controlla lo storico giocate.", "warn", 7000);
      };
      try { xhr.send(JSON.stringify({ transactionId: transactionId })); } catch (e) {}
    };
    setTimeout(tick, 900);
  }

  function findTicket(data) {
    try {
      for (const r of [data.responseSingle, data.responseMultiple, data.responseSystems])
        if (r && r.ticketSogei) return r.ticketSogei;
    } catch (e) {}
    return null;
  }

  // ───────────────────── azioni ─────────────────────
  function playFromQuotaEl(quotaEl) { fastPurchase(readSelectionFromQuota(quotaEl)); }

  function playFromRegistered(which) {
    const key = which === "casa" ? LS_SEL_CASA : LS_SEL_OSPITE;
    let sel = null;
    try { sel = JSON.parse(localStorage.getItem(key) || "null"); } catch (e) {}
    if (!sel) { toast(`Registra prima la quota ${which.toUpperCase()} dal pannello.`, "warn"); return; }
    const fresh = findLiveQuotaBySel(sel);   // quota aggiornata dal DOM
    fastPurchase(fresh || sel);
  }

  function findLiveQuotaBySel(sel) {
    try {
      const barre = document.querySelectorAll('[id^="barra-extra-"]');
      for (const b of barre) {
        if (sel.scomSogei && b.id.indexOf("_" + sel.scomSogei + "_") === -1) continue;
        const quote = b.querySelectorAll(".quota-con-nome, .quota");
        for (const q of quote) {
          const s = readSelectionFromQuota(q);
          if (s && s.descDraw === sel.descDraw && s.scomSogei === sel.scomSogei) return s;
        }
      }
    } catch (e) {}
    return null;
  }

  // ───────────────────── click (registra quota) & dblclick (gioca) ─────────────────────
  document.addEventListener("click", function (e) {
    if (!enabled) return;
    if (recMode === "sel-casa" || recMode === "sel-ospite") {
      const q = isQuota(e.target);
      if (q) {
        e.preventDefault(); e.stopPropagation();
        const sel = readSelectionFromQuota(q);
        const key = recMode === "sel-casa" ? LS_SEL_CASA : LS_SEL_OSPITE;
        try { localStorage.setItem(key, JSON.stringify(sel)); } catch (er) {}
        toast(`Registrata «${sel && sel.descDraw}» @${sel && sel.oddText} per ${recMode === "sel-casa" ? "CASA" : "OSPITE"}`, "ok");
        recMode = null; paintPanel();
      }
    }
  }, true);

  document.addEventListener("dblclick", function (e) {
    if (!enabled || recMode) return;
    const q = isQuota(e.target);
    if (q) { e.preventDefault(); e.stopPropagation(); playFromQuotaEl(q); }
  }, true);

  // ───────────────────── hotkey ─────────────────────
  document.addEventListener("keydown", function (e) {
    const tag = (e.target && e.target.tagName) || "";
    const typing = tag === "INPUT" || tag === "TEXTAREA" || (e.target && e.target.isContentEditable);
    if (recKey) {
      e.preventDefault();
      if (recKey === "casa")   { keyCasa = e.key;   try { localStorage.setItem(LS_KEY_CASA, keyCasa); } catch (er) {} }
      if (recKey === "ospite") { keyOspite = e.key; try { localStorage.setItem(LS_KEY_OSPITE, keyOspite); } catch (er) {} }
      recKey = null; paintPanel();
      return;
    }
    if (typing || !enabled) return;
    if (keyCasa && e.key === keyCasa)          { e.preventDefault(); playFromRegistered("casa"); }
    else if (keyOspite && e.key === keyOspite) { e.preventDefault(); playFromRegistered("ospite"); }
  }, true);

  // ───────────────────── PANNELLO GUI ─────────────────────
  const T = { accent: "#e2231a", bg: "#12161c", box: "#1b212b", border: "#2b3542", ok: "#1a9e5f" };

  function ensurePanel() {
    if (document.getElementById("whfb-panel")) return;
    const style = document.createElement("style");
    style.textContent = `
      #whfb-panel{position:fixed;right:16px;bottom:16px;z-index:2147483647;width:262px;
        font:13px/1.4 -apple-system,Segoe UI,sans-serif;color:#fff;background:${T.bg};
        border:1px solid ${T.border};border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.5);overflow:hidden}
      #whfb-panel .hd{display:flex;align-items:center;justify-content:space-between;
        padding:11px 13px;background:linear-gradient(135deg,${T.accent},#a01018);font-weight:800}
      #whfb-panel .hd small{opacity:.85;font-weight:600}
      #whfb-panel .bd{padding:12px 13px;display:flex;flex-direction:column;gap:10px}
      #whfb-panel .row{display:flex;align-items:center;justify-content:space-between;gap:8px;
        background:${T.box};border:1px solid ${T.border};border-radius:9px;padding:9px 11px}
      #whfb-panel .col{flex-direction:column;align-items:stretch;gap:8px}
      #whfb-panel .lbl{font-weight:700}
      #whfb-panel input#whfb-stake{width:82px;padding:6px 8px;border-radius:7px;border:1px solid ${T.border};
        background:${T.bg};color:${T.accent};font-weight:800;text-align:right;font-size:14px}
      #whfb-panel .btn{cursor:pointer;border:1px solid ${T.border};background:${T.box};color:#fff;
        border-radius:8px;padding:7px 10px;font-weight:700;font-size:12px;text-align:center;flex:1}
      #whfb-panel .btn:hover{border-color:${T.accent}}
      #whfb-panel .btn.rec{background:${T.accent};border-color:${T.accent}}
      #whfb-panel .k{font-size:11px;opacity:.8}
      #whfb-panel .sw{position:relative;width:42px;height:22px;border-radius:22px;background:#444;cursor:pointer;transition:.2s;flex:none}
      #whfb-panel .sw.on{background:${T.ok}}
      #whfb-panel .sw::after{content:"";position:absolute;top:2px;left:2px;width:18px;height:18px;border-radius:50%;background:#fff;transition:.2s}
      #whfb-panel .sw.on::after{left:22px}
      #whfb-toast{position:fixed;right:16px;bottom:300px;z-index:2147483647;max-width:300px;
        font:13px/1.4 -apple-system,Segoe UI,sans-serif;color:#fff;padding:11px 14px;border-radius:10px;
        box-shadow:0 6px 20px rgba(0,0,0,.4);display:none}
    `;
    document.head.appendChild(style);

    const p = document.createElement("div");
    p.id = "whfb-panel";
    p.innerHTML = `
      <div class="hd"><span>⚡ William Hill Fast Bet</span><small>v2.3</small></div>
      <div class="bd">
        <div class="row"><span class="lbl">Fast Bet</span><div class="sw" id="whfb-sw"></div></div>
        <div class="row"><span class="lbl">Importo (€)</span><input type="number" id="whfb-stake" min="0.05" step="0.05"></div>
        <div class="row col">
          <span class="lbl">Hotkey Casa <span class="k" id="whfb-kcasa"></span></span>
          <div style="display:flex;gap:6px">
            <div class="btn" id="whfb-reckey-casa">Tasto</div>
            <div class="btn" id="whfb-recsel-casa">Registra quota</div>
          </div>
          <span class="k" id="whfb-selcasa"></span>
        </div>
        <div class="row col">
          <span class="lbl">Hotkey Ospite <span class="k" id="whfb-kosp"></span></span>
          <div style="display:flex;gap:6px">
            <div class="btn" id="whfb-reckey-ospite">Tasto</div>
            <div class="btn" id="whfb-recsel-ospite">Registra quota</div>
          </div>
          <span class="k" id="whfb-selosp"></span>
        </div>
        <div class="k" style="text-align:center">Doppio-click su una quota = gioca subito.<br>L'attesa ~10s è del server (ADM), non riducibile.</div>
      </div>`;
    (document.body || document.documentElement).appendChild(p);

    const stakeInput = p.querySelector("#whfb-stake");
    stakeInput.value = stake;
    stakeInput.addEventListener("input", () => {
      const v = parseFloat(stakeInput.value);
      if (v > 0) { stake = v; try { localStorage.setItem(LS_STAKE, String(v)); } catch (e) {} }
    });
    p.querySelector("#whfb-sw").addEventListener("click", () => {
      enabled = !enabled; try { localStorage.setItem(LS_ENABLED, enabled ? "1" : "0"); } catch (e) {}
      paintPanel();
    });
    p.querySelector("#whfb-reckey-casa").addEventListener("click", () => { recKey = "casa"; toast("Premi un tasto per CASA…", "info"); });
    p.querySelector("#whfb-reckey-ospite").addEventListener("click", () => { recKey = "ospite"; toast("Premi un tasto per OSPITE…", "info"); });
    p.querySelector("#whfb-recsel-casa").addEventListener("click", () => { recMode = "sel-casa"; toast("Clicca la quota da usare per CASA…", "info", 6000); paintPanel(); });
    p.querySelector("#whfb-recsel-ospite").addEventListener("click", () => { recMode = "sel-ospite"; toast("Clicca la quota da usare per OSPITE…", "info", 6000); paintPanel(); });

    paintPanel();
  }

  function paintPanel() {
    const p = document.getElementById("whfb-panel");
    if (!p) return;
    const sw = p.querySelector("#whfb-sw"); if (sw) sw.classList.toggle("on", enabled);
    const kc = p.querySelector("#whfb-kcasa"); if (kc) kc.textContent = keyCasa ? `[${keyLabel(keyCasa)}]` : "(nessuno)";
    const ko = p.querySelector("#whfb-kosp");  if (ko) ko.textContent = keyOspite ? `[${keyLabel(keyOspite)}]` : "(nessuno)";
    const rc = p.querySelector("#whfb-recsel-casa"); if (rc) rc.classList.toggle("rec", recMode === "sel-casa");
    const ro = p.querySelector("#whfb-recsel-ospite"); if (ro) ro.classList.toggle("rec", recMode === "sel-ospite");
    const showSel = (id, key) => {
      const el = p.querySelector(id); if (!el) return;
      let s = null; try { s = JSON.parse(localStorage.getItem(key) || "null"); } catch (e) {}
      el.textContent = s ? `→ ${s.descDraw} @${s.oddText}` : "(nessuna quota registrata)";
    };
    showSel("#whfb-selcasa", LS_SEL_CASA);
    showSel("#whfb-selosp", LS_SEL_OSPITE);
  }

  function keyLabel(k) {
    if (k === " ") return "Spazio";
    if (k === "ArrowUp") return "↑"; if (k === "ArrowDown") return "↓";
    if (k === "ArrowLeft") return "←"; if (k === "ArrowRight") return "→";
    return (k || "").length === 1 ? k.toUpperCase() : k;
  }

  // ───────────────────── toast ─────────────────────
  let toastTimer = null;
  function toast(msg, kind, ms) {
    try {
      let t = document.getElementById("whfb-toast");
      if (!t) { t = document.createElement("div"); t.id = "whfb-toast"; (document.body||document.documentElement).appendChild(t); }
      const col = kind === "ok" ? "#0a7d2c" : kind === "warn" ? "#c0182b" : kind === "info" ? "#1560bd" : "#333";
      t.style.background = col; t.style.display = "block"; t.innerHTML = msg;
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => { t.style.display = "none"; }, ms || 3500);
    } catch (e) {}
  }

  // ───────────────────── avvio ─────────────────────
  function boot() { ensurePanel(); setInterval(ensurePanel, 3000); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, { once: true });
  else boot();

  console.log("%c[WH FastBet v2.3]%c doppio-click su una quota o hotkey per giocare col tuo importo",
    "color:#fff;background:#e2231a;padding:1px 6px;border-radius:3px;font-weight:bold", "color:inherit");
})();
