(function () {

  // REST Sniffer v1.1 — MAIN world
  // Intercetta XHR + fetch, cattura header/body/response/timing e li manda al bridge.
  // v1.1: filtro anti-rumore (scarta streaming/tracking/asset) → sniff piccoli e
  //       leggibili; evidenzia i piazzamenti LENTI + estrae il delay server;
  //       riconosce la piattaforma del book. Tutto senza appesantire.

  let capturing = true;   // on/off globale
  let seq = 0;

  // Parole chiave che identificano una chiamata legata al piazzamento scommessa.
  const BET_KEYWORDS = [
    "insertbet", "pendingbet", "checkeventodd", "book", "coupon", "ticket",
    "bet", "scommessa", "piazza", "wager", "stake", "betslip", "placebet",
    "purchase", "placewidget", "getscheduledpurchase", "checkforcoupon",
    "carrello", "giocata", "puntata", "aams", "sogei"
  ];

  // ── FILTRO ANTI-RUMORE: chiamate da IGNORARE (streaming, tracking, asset). ──
  // Alleggerisce lo sniff: niente più .m3u8/.mp4, analytics, immagini, font.
  // NB: se una chiamata "sembra bet" la teniamo COMUNQUE (non la scartiamo mai).
  const NOISE_URL = [
    ".m3u8", ".mp4", ".ts?", "/cmaf", "mediapackage", "akamaized.net", "dscvideo",
    ".css", ".woff", ".woff2", ".ttf", ".svg", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico",
    ".js?", ".js.download", "/assets/", "/static/", "/fonts/",
    "google-analytics", "googletagmanager", "analytics", "contentsquare",
    "doubleclick", "facebook", "hotjar", "clarity", "optimove", "zoho", "sportradar.com/common",
    "/collect?", "/pageview", "/beacon", "/gtm.js", "/log?", "nel.cloudflare"
  ];
  function isNoise(url) {
    const u = (url || "").toLowerCase();
    return NOISE_URL.some(n => u.includes(n));
  }

  // ── riconoscimento piattaforma dal dominio/endpoint ──
  function detectPlatform(url) {
    const u = (url || "").toLowerCase();
    if (u.includes("biahosted") || u.includes("altenar")) return "Altenar";
    if (u.includes("xsportdatastore")) return "xSport (ADM/Sogei)";
    if (u.includes("insertbet") || u.includes("pendingbet") || u.includes("/api/sport/book/")) return "GAD/Lottomatica";
    if (u.includes("xcodetec")) return "React (xcodetec)";
    if (u.includes("ajax.php")) return "PHP/jQuery";
    if (u.includes("sport-sale-service")) return "Eurobet proprietaria";
    if (u.includes("microgame")) return "Microgame";
    if (u.includes("kambi")) return "Kambi";
    return null;
  }

  // ── estrae il delay dichiarato dal server (xSport: "delay":N) ──
  function extractDelay(respBody) {
    try {
      const m = (respBody || "").match(/"delay"\s*:\s*(\d+)/);
      return m ? parseInt(m[1], 10) : null;
    } catch (e) { return null; }
  }

  function looksLikeBet(url, body) {
    const u = (url || "").toLowerCase();
    if (BET_KEYWORDS.some(k => u.includes(k))) return true;
    const b = (typeof body === "string" ? body : "").toLowerCase();
    if (b && BET_KEYWORDS.some(k => b.includes(k))) return true;
    return false;
  }

  window.addEventListener("__sniffer_ctl__", (e) => {
    if (typeof e.detail?.capturing === "boolean") capturing = e.detail.capturing;
  });

  // chiede lo stato (on/off) periodicamente
  setInterval(() => window.postMessage({ __sniffer__: "GET_CTL" }, "*"), 800);

  function send(entry) {
    window.postMessage({ __sniffer__: "CAPTURE", entry }, "*");
  }

  function headerStringToObj(str) {
    const obj = {};
    (str || "").trim().split(/[\r\n]+/).forEach(line => {
      const i = line.indexOf(":");
      if (i > 0) obj[line.slice(0, i).trim()] = line.slice(i + 1).trim();
    });
    return obj;
  }

  function clip(s, max) {
    if (typeof s !== "string") return s;
    return s.length > max ? s.slice(0, max) + "…[+" + (s.length - max) + " char]" : s;
  }

  // ---------- XHR ----------
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;
  const _setHeader = XMLHttpRequest.prototype.setRequestHeader;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__sniff = { method: (method || "GET").toUpperCase(), url: url, reqHeaders: {} };
    return _open.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (this.__sniff) this.__sniff.reqHeaders[name] = value;
    return _setHeader.apply(this, [name, value]);
  };

  XMLHttpRequest.prototype.send = function (body) {
    // Ignora gli XHR interni delle altre estensioni Fast Bet (per non interferire)
    if (this.__vt || this.__eb || this.__gb) return _send.apply(this, [body]);
    if (capturing && this.__sniff) {
      const s = this.__sniff;
      s.isBet = looksLikeBet(s.url, body);
      // FILTRO: scarta il rumore (streaming/tracking/asset), ma tieni sempre i bet
      if (isNoise(s.url) && !s.isBet) return _send.apply(this, [body]);
      s.id = ++seq;
      s.tStart = Date.now();
      s.tPerf = performance.now();
      s.reqBody = clip(typeof body === "string" ? body : (body ? "[" + (body.constructor?.name || "binary") + "]" : null), 20000);

      this.addEventListener("loadend", function () {
        const tPerfEnd = performance.now();
        let respHeaders = {};
        try { respHeaders = headerStringToObj(this.getAllResponseHeaders()); } catch (e) {}
        let respBody = null;
        try {
          if (this.responseType === "" || this.responseType === "text") respBody = this.responseText;
          else if (this.responseType === "json") respBody = JSON.stringify(this.response);
          else respBody = "[responseType=" + this.responseType + "]";
        } catch (e) { respBody = "[non leggibile]"; }

        const durationMs = Math.round(tPerfEnd - s.tPerf);
        send({
          id: s.id, kind: "XHR", method: s.method, url: s.url, status: this.status,
          isBet: s.isBet, tStart: s.tStart, durationMs,
          reqHeaders: s.reqHeaders, reqBody: s.reqBody, respHeaders,
          respBody: clip(respBody, 50000),
          // v1.1: metadati utili per l'analisi al volo
          platform: detectPlatform(s.url),
          delayServer: s.isBet ? extractDelay(respBody) : null,
          slowBet: s.isBet && durationMs > 2000   // piazzamento lento = betdelay
        });
      });
    }
    return _send.apply(this, [body]);
  };

  // ---------- fetch ----------
  const _fetch = window.fetch;
  if (_fetch) {
    window.fetch = function (input, init) {
      if (!capturing) return _fetch.apply(this, arguments);

      const id = ++seq;
      const tStart = Date.now();
      const tPerf = performance.now();

      let url = (typeof input === "string") ? input : (input && input.url) || "";
      let method = ((init && init.method) || (input && input.method) || "GET").toUpperCase();

      // header della richiesta
      const reqHeaders = {};
      try {
        const h = (init && init.headers) || (input && input.headers);
        if (h) {
          if (h.forEach) h.forEach((v, k) => { reqHeaders[k] = v; });
          else if (Array.isArray(h)) h.forEach(([k, v]) => { reqHeaders[k] = v; });
          else Object.entries(h).forEach(([k, v]) => { reqHeaders[k] = v; });
        }
      } catch (e) {}

      let reqBody = null;
      try {
        const b = init && init.body;
        if (typeof b === "string") reqBody = clip(b, 20000);
        else if (b) reqBody = "[" + (b.constructor?.name || "body") + "]";
      } catch (e) {}

      const isBet = looksLikeBet(url, reqBody);
      // FILTRO: scarta il rumore (streaming/tracking/asset), ma tieni sempre i bet
      if (isNoise(url) && !isBet) return _fetch.apply(this, arguments);

      return _fetch.apply(this, arguments).then(resp => {
        const clone = resp.clone();
        const tPerfEnd = performance.now();
        const durationMs = Math.round(tPerfEnd - tPerf);
        const platform = detectPlatform(url);
        const respHeaders = {};
        try { clone.headers.forEach((v, k) => { respHeaders[k] = v; }); } catch (e) {}

        clone.text().then(text => {
          send({
            id, kind: "FETCH", method, url, status: resp.status, isBet, tStart, durationMs,
            reqHeaders, reqBody, respHeaders, respBody: clip(text, 50000),
            platform, delayServer: isBet ? extractDelay(text) : null,
            slowBet: isBet && durationMs > 2000
          });
        }).catch(() => {
          send({
            id, kind: "FETCH", method, url, status: resp.status, isBet, tStart, durationMs,
            reqHeaders, reqBody, respHeaders, respBody: "[body non leggibile]",
            platform, delayServer: null, slowBet: isBet && durationMs > 2000
          });
        });
        return resp;
      }).catch(err => {
        send({
          id, kind: "FETCH", method, url, status: 0, isBet, tStart,
          durationMs: Math.round(performance.now() - tPerf),
          reqHeaders, reqBody, respHeaders: {}, respBody: "[errore: " + (err && err.message) + "]"
        });
        throw err;
      });
    };
  }

})();
