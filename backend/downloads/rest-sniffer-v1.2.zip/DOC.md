# REST Sniffer — Bet Flow Analyzer — Documentazione

## Cos'è
NON è un Fast Bet. È lo **strumento di analisi** con cui catturiamo il traffico di rete di un bookmaker per capire come funziona il suo piazzamento. È l'attrezzo con cui si fanno tutti gli "sniff" del progetto. Funziona su **qualsiasi sito** (`<all_urls>`).

## Piattaforma tecnica
Estensione Chrome Manifest V3 autonoma. Intercetta XHR + fetch nel MAIN world della pagina, raccoglie i dati e li mostra in un popup. Non tocca né modifica le richieste: le osserva soltanto.

## Cosa cattura (per ogni chiamata)
- Metodo (GET/POST/…) e URL completo
- Request headers (tutti, incluso x-auth-token, ecc.) e Request body (il JSON della giocata)
- Response headers, Response body (la risposta del server), Status code
- **Durata in ms** e **timestamp** (orario + ISO + millisecondi) — fondamentali per misurare i secondi di piazzamento
- **cURL** pronto da copiare e rieseguire

Le chiamate che sembrano legate alla scommessa (url/body con `insertBet`, `coupon`, `bet`, `ticket`, `pending`, `purchase`, `placeWidget`, ecc.) sono **evidenziate** e filtrabili con "solo bet".

## Come funziona
1. Attivo di default in REC (registra tutto).
2. Navighi sul book, piazzi una scommessa.
3. Nel popup vedi tutte le chiamate in tempo reale; clicchi una riga per espanderla.
4. "Copia tutto" esporta l'intero flusso in testo leggibile — è quello che si incolla per l'analisi.

## A cosa serve concretamente
È la base di tutta la ricerca sui book: da uno sniff di questo strumento abbiamo scoperto i tempi reali (William Hill live 12s / intervallo 8,5s / prematch 0,4s), il flusso xSport (purchase + polling), il betdelay Altenar di Fastbet (22s), i payload da replicare, e i codici di rifiuto (es. -5105, -2007). Per analizzare un book NUOVO: installi questo, fai una giocata, esporti, e si studia il flusso.

## Stato
Strumento di lavoro — funzionante e usato in produzione per tutti gli sniff.

## Come si usa
1. `chrome://extensions/` → "Modalità sviluppatore" → "Carica estensione non pacchettizzata"
2. Seleziona la cartella `rest_sniffer`
3. Vai sul book da analizzare, apri il popup dell'estensione (è già in REC)
4. Piazza una scommessa (serve credito per catturare il piazzamento reale)
5. "Copia tutto" → incolla il testo per l'analisi

## Pulsanti
- **● REC / ▷ OFF** — attiva/disattiva la cattura
- **filtro** — filtra per parte di URL (es. `purchase`, `/api/`)
- **solo bet** — mostra solo le chiamate evidenziate come scommessa
- **Copia tutto** — copia tutte le chiamate (filtrate) in formato testo
- **Pulisci** — svuota la lista
