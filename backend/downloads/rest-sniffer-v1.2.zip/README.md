# REST Sniffer — Bet Flow Analyzer

Estensione Chrome (MV3) **separata** che cattura tutte le chiamate REST di un sito
(XHR + fetch) e ne mostra header, body, response, timing, timestamp e cURL.
Pensata per analizzare il flusso di piazzamento scommessa su **Eurobet** e siti simili.

Funziona su **qualsiasi sito** (`<all_urls>`): naviga, clicca, e vedi tutto il traffico.

## Cosa cattura per ogni chiamata

- Metodo (GET/POST/…) e URL completo
- **Request headers** (tutti, incluso `x-auth-token` ecc.)
- **Request body** (es. il JSON della scommessa)
- **Response headers**
- **Response body** (la risposta del server)
- **Status code** e **durata in ms**
- **Timestamp** esatto (orario + ISO + ts millisecondi)
- **cURL** pronto da copiare e rieseguire

Le chiamate che sembrano legate alla scommessa (url/body con parole come
`insertBet`, `coupon`, `bet`, `ticket`, `pending`, `book`, `scommessa`…) sono
**evidenziate in giallo** e filtrabili con "solo bet".

## Uso

1. `chrome://extensions/` → "Modalità sviluppatore" → "Carica estensione non pacchettizzata"
2. Seleziona la cartella `rest_sniffer`
3. Vai su Eurobet, apri il popup dell'estensione (è già in REC)
4. Piazza una scommessa
5. Nel popup vedi tutte le chiamate in tempo reale. Clicca una riga per espanderla.
6. **Copia tutto** esporta l'intero flusso in testo leggibile (da incollarmi per l'analisi)

## Pulsanti

- **● REC / ▷ OFF** — attiva/disattiva la cattura
- **filtro** — scrivi parte di un URL per filtrare (es. `insertBet`, `/api/`)
- **solo bet** — mostra solo le chiamate evidenziate come scommessa
- **Copia tutto** — copia negli appunti tutte le chiamate (filtrate) in formato testo
- **Pulisci** — svuota la lista

Tiene in memoria le ultime 200 chiamate.

## Per analizzare Eurobet insieme

Piazza una bet con il REC attivo, poi premi **Copia tutto** (o "copia" sulla singola
chiamata della bet) e incollami il risultato: vediamo come funziona il loro REST e se è
mockabile come Goldbet.
