// REST Sniffer v1.0 — ISOLATED world
// Ponte: riceve le catture dal MAIN world e le inoltra al background.

function isAlive() {
  try { return !!chrome.runtime.id; } catch (e) { return false; }
}

function pushCtl() {
  if (!isAlive()) return;
  try {
    chrome.storage.local.get("capturing", (r) => {
      if (!isAlive() || chrome.runtime.lastError) return;
      const on = (r.capturing === undefined) ? true : r.capturing;
      window.dispatchEvent(new CustomEvent("__sniffer_ctl__", { detail: { capturing: on } }));
    });
  } catch (e) {}
}

window.addEventListener("message", (e) => {
  if (!e.data || typeof e.data !== "object" || !isAlive()) return;
  const t = e.data.__sniffer__;
  if (!t) return;

  if (t === "GET_CTL") { pushCtl(); return; }

  if (t === "CAPTURE") {
    try {
      chrome.runtime.sendMessage({ type: "CAPTURE", entry: e.data.entry, page: location.href }, () => {
        if (chrome.runtime.lastError) {}
      });
    } catch (err) {}
    return;
  }
});

pushCtl();
