// REST Sniffer v1.0 — service worker
// Conserva le catture (ultime N) in chrome.storage.

const MAX_ENTRIES = 200;

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ capturing: true, captures: [] });
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "CAPTURE") {
    chrome.storage.local.get("captures", (r) => {
      const list = r.captures || [];
      const entry = msg.entry;
      entry.page = msg.page;
      entry.iso = new Date(entry.tStart).toISOString();
      list.unshift(entry);
      if (list.length > MAX_ENTRIES) list.length = MAX_ENTRIES;
      chrome.storage.local.set({ captures: list });
    });
  }
  if (msg.type === "CLEAR_CAPTURES") {
    chrome.storage.local.set({ captures: [] });
  }
});
