(function () {
  "use strict";

  // ═══════════════════════════════════════════════════════════════════════════
  // William Hill Fast Bet v4.2 — MAIN world. MODALITÀ AUTO-CLICK DOM.
  //
  // SCOPO: la GUI di William Hill (aggiungi al carrello → scrivi importo → Scommetti)
  //   è LENTA. Questa estensione fa quei passaggi AL POSTO TUO, in un click:
  //     clicchi una quota → l'estensione la aggiunge al carrello, scrive il tuo
  //     importo e clicca SCOMMETTI da sola.
  //
  // PERCHÉ AUTO-CLICK (e non API): costruire il payload xSport a mano viene rifiutato
  //   dal server (es. code -2007: validazione). Simulando i click reali, è il SITO a
  //   costruire il payload corretto — 100% compatibile, come se giocassi tu a mano,
  //   solo automatico e istantaneo.
  //
  // ⚠️ Parte una GIOCATA VERA. L'attesa ~10s dopo lo Scommetti è del server (ADM),
  //   non riducibile. Qui velocizziamo i TUOI gesti, non l'accettazione.
  // ═══════════════════════════════════════════════════════════════════════════

  const LS_STAKE   = "whfb_stake";
  const LS_ENABLED = "whfb_enabled";

  let stake   = 2.0;
  let enabled = true;
  let running = false;   // una sequenza auto-click alla volta

  try { const s = parseFloat(localStorage.getItem(LS_STAKE)); if (s > 0) stake = s; } catch (e) {}
  try { enabled = localStorage.getItem(LS_ENABLED) !== "0"; } catch (e) {}

  // ───────────────────── utility ─────────────────────
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  // aspetta che un selettore compaia (o cambi), fino a timeout
  function waitFor(fn, timeout = 2500, step = 40) {
    return new Promise((resolve) => {
      const t0 = performance.now();
      const check = () => {
        let el = null;
        try { el = fn(); } catch (e) {}
        if (el) return resolve(el);
        if (performance.now() - t0 > timeout) return resolve(null);
        setTimeout(check, step);
      };
      check();
    });
  }

  // click "reale" (mousedown→mouseup→click): i framework spesso ignorano un click()
  // sintetico. Simuliamo la sequenza completa come un utente vero.
  function realClick(el) {
    if (!el) return false;
    try {
      const r = el.getBoundingClientRect();
      const opts = { bubbles: true, cancelable: true, view: window,
                     clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
      el.dispatchEvent(new MouseEvent("mousedown", opts));
      el.dispatchEvent(new MouseEvent("mouseup", opts));
      el.dispatchEvent(new MouseEvent("click", opts));
      return true;
    } catch (e) { try { el.click(); return true; } catch (e2) { return false; } }
  }

  // scrive un valore in un input React/controllato: usa il NATIVE value setter,
  // altrimenti il framework ignora la scrittura (il modello interno resta vuoto).
  function setReactInput(el, value) {
    try {
      const proto = Object.getPrototypeOf(el);
      const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value") &&
                           Object.getOwnPropertyDescriptor(proto, "value").set;
      if (nativeSetter) nativeSetter.call(el, value); else el.value = value;
      el.dispatchEvent(new Event("input",  { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }));
    } catch (e) {
      try { el.value = value; el.dispatchEvent(new Event("input", { bubbles: true })); } catch (e2) {}
    }
  }

  // ───────────────────── selettori del sito ─────────────────────
  function quotaFromTarget(el) {
    if (!el || !el.closest) return null;
    const q = el.closest(".quota-con-nome, .quota");
    return (q && q.closest('[id^="barra-extra-"]')) ? q : null;
  }
  // campo importo del carrello (input della singola). Selettori LARGHI con più
  // fallback: la classe esatta ha il numero coupon variabile e id molto lunghi,
  // quindi ci basiamo su porzioni stabili (amount-field-coupon, input-calc,
  // placeholder="Importo", id che inizia con input-calc-for-bet).
  function findAmountInput() {
    const sels = [
      'input[class*="amount-field-coupon"]',
      'input[id^="input-calc-for-bet"]',
      'input.input-calc[placeholder="Importo"]',
      'input.calcolatrice-input[placeholder="Importo"]',
      '.inserimento-puntata input.input-calc',
      '.calcSingola input.input-calc',
      '.carrello-scrollable input[placeholder="Importo"]',
      'input.input-calc'
    ];
    for (const s of sels) {
      // preferiamo quello VISIBILE (il carrello può avere più input nascosti)
      const list = document.querySelectorAll(s);
      for (const el of list) {
        if (el && el.offsetParent !== null) return el;   // visibile
      }
      if (list.length) return list[0];   // fallback: anche non visibile
    }
    return null;
  }
  // pulsante "Scommetti" (verde)
  function findBetButton() {
    // classe verde del sito
    let b = document.querySelector('.bottoni-schedina .bottone.bg-verde');
    if (b) return b;
    // fallback: bottone con testo "Scommetti"
    const btns = document.querySelectorAll('.bottoni-schedina button, button.bottone, .bottone');
    for (const x of btns) {
      const t = (x.textContent || "").trim().toLowerCase();
      if (t === "scommetti") return x;
    }
    return null;
  }
  // quante selezioni ci sono nel carrello (per capire se il click ha aggiunto)
  function betslipCount() {
    return document.querySelectorAll('.lista-eventi-schedina .grid__coupon_wh, .carrello-scrollable .events__selection').length;
  }

  // ───────────────────── sequenza AUTO (dopo il click nativo) ─────────────────────
  // IMPORTANTE: NON blocchiamo il click nativo sulla quota. Lasciamo che sia il
  // SITO ad aggiungere la selezione al carrello (lo fa correttamente). Noi reagiamo
  // DOPO: aspettiamo che il carrello si popoli, poi scriviamo l'importo e Scommettiamo.
  async function autoPlay(nomeQuota) {
    if (running) return;
    running = true;
    const printable = stake.toFixed(2).replace(".", ",");
    try {
      // 1) aspetta che il carrello si POPOLI (il click nativo lo sta facendo) e che
      //    compaia il campo importo. Attesa lunga: React puo' renderizzare tardi.
      toast(`▶ Aggiungo «${nomeQuota}»…`, "info", 8000);
      let amount = await waitFor(() => (betslipCount() > 0 ? findAmountInput() : null), 5000);

      // fallback: attiva la scheda "Singola" e/o espandi la selezione
      if (!amount) {
        const singleTab = document.querySelector('[id^="selector-singlebets-coupon-"]');
        if (singleTab) { realClick(singleTab); await sleep(300); }
        const selRow = document.querySelector('.lista-eventi-schedina .events__selection, .carrello-scrollable .grid__coupon_wh');
        if (selRow) { realClick(selRow); await sleep(300); }
        amount = await waitFor(() => findAmountInput(), 2500);
      }
      if (!amount) {
        const n = betslipCount();
        toast(`Campo importo non trovato (selezioni: ${n}). Guarda la console (F12).`, "warn", 8000);
        console.warn("[WH FastBet] no amount input. betslipCount=", n,
          "candidati:", document.querySelectorAll('input.input-calc, input[class*=amount-field], input[placeholder="Importo"]'));
        return;
      }

      // 3) scrivi il tuo importo
      await sleep(60);
      setReactInput(amount, printable);
      await sleep(120);
      // ricontrolla: alcuni carrelli riscrivono il campo → riproviamo una volta
      if ((amount.value || "").replace(".", ",") !== printable) { setReactInput(amount, printable); await sleep(100); }

      // 4) clicca Scommetti
      const betBtn = await waitFor(() => {
        const b = findBetButton();
        // evita di cliccare un bottone disabilitato
        if (b && (b.disabled || b.classList.contains("disabled") || b.getAttribute("aria-disabled") === "true")) return null;
        return b;
      }, 2500);
      if (!betBtn) { toast("Pulsante «Scommetti» non trovato/attivo. Importo inserito: premi tu.", "warn", 7000); return; }

      toast(`▶ Scommetto ${printable}€ su «${nomeQuota}»…`, "info", 12000);
      realClick(betBtn);
      // il sito ora invia la purchase e gestisce il suo polling (~10s ADM).
      toast(`Inviata — attesa server (~10s). Controlla la conferma sul sito.`, "ok", 9000);
    } catch (e) {
      toast("Errore durante la giocata rapida.", "warn", 5000);
    } finally {
      // piccola pausa per non incatenare doppi invii
      setTimeout(() => { running = false; }, 800);
    }
  }

  // ───────────────────── CLICK su quota = auto-play ─────────────────────
  // NON blocchiamo il click nativo: deve aggiungere la quota al carrello (lo fa il
  // sito). Noi partiamo IN PARALLELO con autoPlay, che aspetta il carrello popolato,
  // poi scrive l'importo e clicca Scommetti. Ascoltiamo in BUBBLING (non capture)
  // per lasciare al sito il suo handler.
  document.addEventListener("click", function (e) {
    if (!enabled) return;
    if (e.target && e.target.closest && e.target.closest("#whfb-panel")) return;
    const q = quotaFromTarget(e.target);
    if (!q) return;
    const nome = (() => { try { return (q.querySelector("span") || {}).textContent || "quota"; } catch (er) { return "quota"; } })().replace(/\s*\(\d+\)\s*/, "").trim();
    // lascia passare il click nativo; reagiamo dopo
    autoPlay(nome);
  }, false);

  // ───────────────────── PANNELLO (solo importo + on/off) ─────────────────────
  const T = { accent: "#e2231a", bg: "#12161c", box: "#1b212b", border: "#2b3542", ok: "#1a9e5f" };

  function ensurePanel() {
    if (document.getElementById("whfb-panel")) return;
    const style = document.createElement("style");
    style.textContent = `
      #whfb-panel{position:fixed;right:16px;bottom:16px;z-index:2147483647;width:230px;
        font:13px/1.4 -apple-system,Segoe UI,sans-serif;color:#fff;background:${T.bg};
        border:1px solid ${T.border};border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.5);overflow:hidden}
      #whfb-panel .hd{display:flex;align-items:center;justify-content:space-between;
        padding:11px 13px;background:linear-gradient(135deg,${T.accent},#a01018);font-weight:800}
      #whfb-panel .hd small{opacity:.85;font-weight:600}
      #whfb-panel .bd{padding:12px 13px;display:flex;flex-direction:column;gap:10px}
      #whfb-panel .row{display:flex;align-items:center;justify-content:space-between;gap:8px;
        background:${T.box};border:1px solid ${T.border};border-radius:9px;padding:9px 11px}
      #whfb-panel .lbl{font-weight:700}
      #whfb-panel input#whfb-stake{width:88px;padding:7px 9px;border-radius:7px;border:1px solid ${T.border};
        background:${T.bg};color:${T.accent};font-weight:800;text-align:right;font-size:15px}
      #whfb-panel .sw{position:relative;width:44px;height:24px;border-radius:24px;background:#444;cursor:pointer;transition:.2s;flex:none}
      #whfb-panel .sw.on{background:${T.ok}}
      #whfb-panel .sw::after{content:"";position:absolute;top:2px;left:2px;width:20px;height:20px;border-radius:50%;background:#fff;transition:.2s}
      #whfb-panel .sw.on::after{left:22px}
      #whfb-panel .hint{font-size:11.5px;opacity:.82;text-align:center;line-height:1.35}
      #whfb-panel .hint b{color:${T.accent}}
      #whfb-toast{position:fixed;right:16px;bottom:200px;z-index:2147483647;max-width:290px;
        font:13px/1.4 -apple-system,Segoe UI,sans-serif;color:#fff;padding:11px 14px;border-radius:10px;
        box-shadow:0 6px 20px rgba(0,0,0,.4);display:none;font-weight:600}
    `;
    document.head.appendChild(style);

    const p = document.createElement("div");
    p.id = "whfb-panel";
    p.innerHTML = `
      <div class="hd"><span>⚡ WH Fast Bet</span><small>v4.2</small></div>
      <div class="bd">
        <div class="row"><span class="lbl">Fast Bet</span><div class="sw" id="whfb-sw"></div></div>
        <div class="row"><span class="lbl">Importo (€)</span><input type="number" id="whfb-stake" min="0.05" step="0.05"></div>
        <div class="hint" id="whfb-hint"></div>
      </div>`;
    (document.body || document.documentElement).appendChild(p);

    const stakeInput = p.querySelector("#whfb-stake");
    stakeInput.value = stake;
    stakeInput.addEventListener("input", () => {
      const v = parseFloat(stakeInput.value);
      if (v > 0) { stake = v; try { localStorage.setItem(LS_STAKE, String(v)); } catch (e) {} paintPanel(); }
    });
    p.querySelector("#whfb-sw").addEventListener("click", () => {
      enabled = !enabled; try { localStorage.setItem(LS_ENABLED, enabled ? "1" : "0"); } catch (er) {}
      paintPanel();
    });
    paintPanel();
  }

  function paintPanel() {
    const p = document.getElementById("whfb-panel");
    if (!p) return;
    const sw = p.querySelector("#whfb-sw"); if (sw) sw.classList.toggle("on", enabled);
    const hint = p.querySelector("#whfb-hint");
    if (hint) hint.innerHTML = `<b>Clicca una quota</b> per giocare ${stake.toFixed(2).replace(".", ",")}€.<br>Aggiunge, scrive l'importo e Scommette da solo.`;
  }

  // ───────────────────── toast ─────────────────────
  let toastTimer = null;
  function toast(msg, kind, ms) {
    try {
      let t = document.getElementById("whfb-toast");
      if (!t) { t = document.createElement("div"); t.id = "whfb-toast"; (document.body||document.documentElement).appendChild(t); }
      const col = kind === "ok" ? "#0a7d2c" : kind === "warn" ? "#c0182b" : kind === "info" ? "#1560bd" : "#333";
      t.style.background = col; t.style.display = "block"; t.innerHTML = msg;
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => { t.style.display = "none"; }, ms || 3500);
    } catch (e) {}
  }

  function boot() { ensurePanel(); setInterval(ensurePanel, 3000); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, { once: true });
  else boot();

  console.log("%c[WH FastBet v4.2]%c AUTO-CLICK: click su una quota → aggiunge, importo e Scommetti da solo",
    "color:#fff;background:#e2231a;padding:1px 6px;border-radius:3px;font-weight:bold", "color:inherit");
})();
