(function () {
  "use strict";

  // ═══════════════════════════════════════════════════════════════════════════
  // Bwin Fast Bet v1.2 — MAIN world. MODALITÀ AUTO-CLICK DOM.
  //
  // SCOPO: piazzare in un gesto su Bwin (piattaforma Entain, frontend Angular).
  //   - CLICK su una quota → aggiunge al carrello, scrive il tuo importo, clicca
  //     "Piazza scommessa" da solo.
  //   - HOTKEY Casa/Ospite → nel mercato aperto della partita, Casa = 1ª quota,
  //     Ospite = ultima quota (Bwin mostra i nomi squadra/1-X-2, non "Casa/Ospite").
  //
  // PERCHÉ AUTO-CLICK: il piazzamento Bwin (POST placebet/place → ~4s →
  //   querystatus) è "pending" fino al querystatus (risk Entain), NON mockabile.
  //   Costruire il place a mano è fragile (payload firmato con 'sign'). Simulando
  //   i click reali è il SITO a costruire il payload corretto.
  //
  // ⚠️ Parte una GIOCATA VERA. L'attesa ~4s dopo il "Piazza scommessa" è del server
  //   (risk Entain), NON riducibile. Qui velocizziamo i TUOI gesti.
  // ═══════════════════════════════════════════════════════════════════════════

  const LS_STAKE         = "bwfb_stake";
  const LS_ENABLED       = "bwfb_enabled";
  const LS_KEY_CASA      = "bwfb_key_casa";
  const LS_KEY_OSPITE    = "bwfb_key_ospite";
  const LS_KEY_CASA_1T   = "bwfb_key_casa_1t";
  const LS_KEY_OSPITE_1T = "bwfb_key_ospite_1t";

  let stake   = 2.0;
  let enabled = true;
  let running = false;
  let keyCasa = null, keyOspite = null, keyCasa1t = null, keyOspite1t = null, recKey = null;

  try { const s = parseFloat(localStorage.getItem(LS_STAKE)); if (s > 0) stake = s; } catch (e) {}
  try { enabled = localStorage.getItem(LS_ENABLED) !== "0"; } catch (e) {}
  try { keyCasa     = localStorage.getItem(LS_KEY_CASA)      || null; } catch (e) {}
  try { keyOspite   = localStorage.getItem(LS_KEY_OSPITE)    || null; } catch (e) {}
  try { keyCasa1t   = localStorage.getItem(LS_KEY_CASA_1T)   || null; } catch (e) {}
  try { keyOspite1t = localStorage.getItem(LS_KEY_OSPITE_1T) || null; } catch (e) {}

  // ───────────────────── utility ─────────────────────
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  function waitFor(fn, timeout = 3000, step = 40) {
    return new Promise((resolve) => {
      const t0 = performance.now();
      const check = () => {
        let el = null; try { el = fn(); } catch (e) {}
        if (el) return resolve(el);
        if (performance.now() - t0 > timeout) return resolve(null);
        setTimeout(check, step);
      };
      check();
    });
  }

  // click reale (mousedown→mouseup→click): Angular ignora un click() sintetico.
  function realClick(el) {
    if (!el) return false;
    try {
      const r = el.getBoundingClientRect();
      const opts = { bubbles: true, cancelable: true, view: window,
                     clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
      el.dispatchEvent(new MouseEvent("mousedown", opts));
      el.dispatchEvent(new MouseEvent("mouseup", opts));
      el.dispatchEvent(new MouseEvent("click", opts));
      return true;
    } catch (e) { try { el.click(); return true; } catch (e2) { return false; } }
  }

  // scrive in un input Angular col NATIVE value setter (altrimenti il modello interno
  // resta vuoto e il "Piazza scommessa" usa importo 0/vecchio).
  function setAngularInput(el, value) {
    try {
      const proto = Object.getPrototypeOf(el);
      const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value") &&
                           Object.getOwnPropertyDescriptor(proto, "value").set;
      if (nativeSetter) nativeSetter.call(el, value); else el.value = value;
      el.dispatchEvent(new Event("input",  { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }));
    } catch (e) {
      try { el.value = value; el.dispatchEvent(new Event("input", { bubbles: true })); } catch (e2) {}
    }
  }

  // ───────────────────── selettori Bwin ─────────────────────
  // quota cliccabile: .option-pick (contiene .name = esito, .value.option-value = quota).
  // il click va sull'.option-indicator interno (dove Bwin registra il tap).
  function quotaFromTarget(el) {
    if (!el || !el.closest) return null;
    return el.closest(".option-pick") || null;
  }
  function clickTargetOfQuota(q) {
    return q.querySelector(".option-indicator") || q;
  }
  function quotaLabel(q) {
    try {
      const n = q.querySelector(".name"); const v = q.querySelector(".value, .option-value");
      return ((n && n.textContent) || "quota").trim() + (v ? " @" + v.textContent.trim() : "");
    } catch (e) { return "quota"; }
  }

  // campo importo del carrello (schedina)
  function findStakeInput() {
    const sels = [
      "input.stake-input-value",
      "input[msvalidatestakeinput]",
      '.stake-container input[type="text"]',
      '.betslip input[placeholder="Puntata"]',
      'input[placeholder="Puntata"]'
    ];
    for (const s of sels) {
      const list = document.querySelectorAll(s);
      for (const el of list) if (el && el.offsetParent !== null) return el;
      if (list.length) return list[0];
    }
    return null;
  }
  // pulsante "Piazza scommessa"
  function findPlaceButton() {
    let b = document.querySelector("button.place-button, .betslip-place-button button, button.ds-btn-filled-success");
    if (b) return b;
    const btns = document.querySelectorAll("button");
    for (const x of btns) {
      const t = (x.textContent || "").trim().toLowerCase();
      if (t.includes("piazza scommessa") || t.startsWith("piazza")) return x;
    }
    return null;
  }
  function betslipHasPick() {
    return document.querySelectorAll(".betslip .single-bet-pick, .betslip-digital-bet-pick, bs-single-bet-linear").length > 0
        || !!findStakeInput();
  }

  // ───────────────────── sequenza auto-play (dopo che la quota è nel carrello) ─────
  async function autoPlay(label) {
    if (running) return;
    running = true;
    const printable = stake.toFixed(2).replace(".", ",");
    startCrono();   // ⏱️ cronometro parte da 0 AL CLICK
    try {
      toast(`▶ ${label}…`, "info", 8000);
      // 1) aspetta che la schedina si popoli e compaia il campo importo. Poll fitto
      //    (20ms) per reagire appena c'è → meno latenza sul TUO gesto.
      let stakeEl = await waitFor(() => (betslipHasPick() ? findStakeInput() : null), 5000, 20);
      if (!stakeEl) {
        stopCrono();
        toast("Schedina non pronta (campo importo non trovato). Guarda la console (F12).", "warn", 8000);
        console.warn("[Bwin FastBet] no stake input. betslip picks:",
          document.querySelectorAll(".betslip-digital-bet-pick, bs-single-bet-linear").length,
          "candidati:", document.querySelectorAll("input.stake-input-value, input[placeholder=Puntata]"));
        return;
      }
      // 2) scrivi l'importo (pause minime: Angular ha bisogno di un tick per registrare)
      realClick(stakeEl); await sleep(20);
      setAngularInput(stakeEl, printable);
      await sleep(50);
      if ((stakeEl.value || "").replace(".", ",") !== printable) { setAngularInput(stakeEl, printable); await sleep(50); }
      // 3) clicca "Piazza scommessa" appena è attivo
      const btn = await waitFor(() => {
        const b = findPlaceButton();
        if (b && (b.disabled || b.classList.contains("disabled") || b.getAttribute("aria-disabled") === "true")) return null;
        return b;
      }, 2500, 20);
      if (!btn) { stopCrono(); toast("Pulsante «Piazza scommessa» non attivo. Importo inserito: premi tu.", "warn", 7000); return; }
      realClick(btn);
      toast(`▶ Piazzo ${printable}€ su «${label}» — attesa server…`, "info", 12000);
      // 4) il cronometro continua durante i ~4s del server; si ferma quando la giocata
      //    è confermata (parte il querystatus col ticket, o compare l'esito nella UI).
      watchOutcome();
    } catch (e) {
      stopCrono();
      toast("Errore durante la giocata rapida.", "warn", 5000);
    } finally {
      setTimeout(() => { running = false; }, 900);
    }
  }

  // ───────────────────── CRONOMETRO (parte da 0 al click) ─────────────────────
  // STOP: il segnale AUTORITATIVO è il messaggio UI di conferma
  //   "La tua scommessa è stata accettata, buona fortuna!"
  // (è il momento in cui TU la vedi accettata). Fallback: querystatus + timeout.
  let cronoT0 = 0, cronoTimer = null, cronoStopped = true;
  let outcomeWatch = null, cronoObserver = null;

  // regex tollerante: "scommessa ... accettata" (accenti/case a parte)
  const CONFIRM_RE = /scommessa[\s\S]{0,40}?accettat/i;
  function isConfirmText(s) { return !!s && CONFIRM_RE.test(s); }

  function startCrono() {
    cronoT0 = performance.now(); cronoStopped = false;
    clearInterval(cronoTimer);
    cronoTimer = setInterval(paintCrono, 50);   // aggiorna ogni 50ms = fluido
    paintCrono();
    startConfirmObserver();
  }
  function stopCrono() {
    if (cronoStopped) return;
    cronoStopped = true; clearInterval(cronoTimer);
    clearTimeout(outcomeWatch);
    if (cronoObserver) { try { cronoObserver.disconnect(); } catch (e) {} cronoObserver = null; }
    paintCrono();   // fissa il valore finale
  }
  function cronoSeconds() { return cronoT0 ? (performance.now() - cronoT0) / 1000 : 0; }
  function paintCrono() {
    const el = document.getElementById("bwfb-crono");
    if (!el) return;
    el.textContent = cronoSeconds().toFixed(2) + "s";
    el.classList.toggle("run", !cronoStopped);
    el.classList.toggle("done", cronoStopped && cronoT0 > 0);
  }

  // Observer sul DOM: appena compare il testo di conferma, ferma il crono all'istante.
  function startConfirmObserver() {
    if (cronoObserver) { try { cronoObserver.disconnect(); } catch (e) {} }
    // se per caso il messaggio è già in pagina da prima, non fermare subito:
    // lo cerchiamo solo nei nodi AGGIUNTI dopo lo start.
    cronoObserver = new MutationObserver((muts) => {
      if (cronoStopped) return;
      for (const m of muts) {
        for (const n of m.addedNodes) {
          if (n.nodeType === 1) {
            const txt = n.textContent || "";
            if (isConfirmText(txt)) { stopCrono(); return; }
          } else if (n.nodeType === 3 && isConfirmText(n.nodeValue)) {
            stopCrono(); return;
          }
        }
        // anche modifiche di testo su nodi esistenti (Angular a volte riusa il nodo)
        if (m.type === "characterData" && isConfirmText(m.target && m.target.nodeValue)) {
          stopCrono(); return;
        }
      }
    });
    try {
      cronoObserver.observe(document.body || document.documentElement,
        { childList: true, subtree: true, characterData: true });
    } catch (e) {}
  }

  function watchOutcome() {
    // fallback a tempo GENEROSO: solo se non intercettiamo né messaggio né querystatus.
    // Alto (15s) per non troncare mai prima del "accettata" reale.
    clearTimeout(outcomeWatch);
    outcomeWatch = setTimeout(() => stopCrono(), 15000);
  }
  // fallback secondario: risposta del GET querystatus (se il messaggio UI non arrivasse)
  try {
    const _fetch = window.fetch;
    if (typeof _fetch === "function") {
      window.fetch = function (input, init) {
        let url = ""; try { url = typeof input === "string" ? input : (input && input.url) || ""; } catch (e) {}
        const p = _fetch.apply(this, arguments);
        if (!cronoStopped && /placebet\/querystatus/i.test(url)) {
          // piccolo delay: dà tempo al messaggio UI di comparire e vincere lui (più preciso)
          p.then(() => { if (!cronoStopped) setTimeout(() => stopCrono(), 250); }).catch(() => {});
        }
        return p;
      };
    }
  } catch (e) {}

  // ───────────────────── hotkey: Casa=1ª, Ospite=ultima nel mercato aperto ─────────
  // trova il mercato VISIBILE con opzioni e prende la prima/ultima quota giocabile.
  function firstVisibleMarketPicks() {
    const groups = document.querySelectorAll(".option-group-container, .option-panel, ms-option-group");
    for (const g of groups) {
      if (g.offsetParent === null) continue;   // solo visibili
      const picks = [...g.querySelectorAll(".option-pick")].filter(p => {
        // scarta le opzioni bloccate/nascoste
        if (p.offsetParent === null) return false;
        if (p.closest(".option-hidden") || p.closest(".lock") || p.querySelector(".option-group-lock-icon")) return false;
        return true;
      });
      if (picks.length >= 2) return picks;
    }
    // fallback: tutte le option-pick visibili in pagina
    const all = [...document.querySelectorAll(".option-pick")].filter(p => p.offsetParent !== null);
    return all.length >= 2 ? all : null;
  }

  // opzioni giocabili dentro un contenitore mercato
  function picksOfMarket(g) {
    return [...g.querySelectorAll(".option-pick")].filter(p =>
      p.offsetParent !== null && !p.closest(".option-hidden") && !p.closest(".lock")
      && !p.querySelector(".option-group-lock-icon"));
  }
  // ─── MERCATO 1° TEMPO (Bwin: NON è un mercato separato, è una TAB dentro il mercato) ───
  // Struttura reale (dall'HTML): ogni <ms-option-panel> ha un titolo (slot="title") e, se
  // è un mercato "a periodi", una barra tab con <button role="tab"><span>1° tempo</span>.
  // Per "Gol Casa/Ospite 1°T" il mercato giusto è "1ª squadra a segnare" (Casa/Nessun gol/
  // Ospite) o in alternativa "Risultato partita". Devi cliccare la tab 1° tempo e poi
  // prendere 1ª/ultima quota (l'opzione di mezzo = Nessun gol/X va saltata).

  // titolo del pannello mercato (dal slot="title")
  function panelTitle(panel) {
    try {
      const t = panel.querySelector('[slot="title"]');
      return (t ? t.textContent : panel.textContent || "").trim().toLowerCase();
    } catch (e) { return ""; }
  }
  const FH_RE = /1°?\s*tempo|primo tempo|1st half/i;
  // trova il <button role="tab"> "1° tempo" dentro un pannello mercato (FORMA A: mercato
  // "a periodi" con tab Tempi regolamentari | 1° tempo | 2° tempo).
  function firstHalfTab(panel) {
    const tabs = panel.querySelectorAll('button[role="tab"], .ds-tab-header-item');
    for (const tb of tabs) {
      if (FH_RE.test(tb.textContent || "")) return tb;
    }
    return null;
  }
  function tabSelected(tb) {
    return tb.getAttribute("aria-selected") === "true" || tb.classList.contains("ds-tab-selected");
  }
  // Su Bwin il 1° tempo appare in DUE forme:
  //  A) mercato con TAB interne (es. "1ª squadra a segnare") → la tab "1° tempo" va cliccata.
  //  B) mercato dedicato col PERIODO NEL TITOLO (es. "1° tempo - 2ª squadra a segnare",
  //     appare dopo il 1° gol) → nessuna tab, le quote sono già del 1° tempo.
  // Un pannello è "del 1° tempo" se ha la tab 1°T (A) OPPURE il titolo contiene "1° tempo" (B).
  function panelHasFirstHalf(panel) {
    return !!firstHalfTab(panel) || FH_RE.test(panelTitle(panel));
  }
  // ordinale del marcatore nel titolo: "1ª/2ª/3ª/4ª/5ª squadra a segnare" → 1..5.
  // Bwin fa sparire il marcatore già avvenuto e mostra il prossimo: dopo il 1° gol resta
  // "2ª squadra a segnare", dopo il 2° "3ª", ecc. Copriamo 1°→5° gol del 1° tempo.
  // Accetta "1ª"/"1a"/"1°"/"1" prima di "squadra a segnare".
  function scorerOrdinal(title) {
    if (!/segnare/.test(title)) return 0;                 // non è un mercato marcatore
    const m = title.match(/(\d)\s*[ª°a]?\s*squadra a segnare/);
    if (m) return parseInt(m[1], 10);                      // 1..5
    // "1ª squadra a segnare" può comparire senza numero esplicito riconosciuto → prova generico
    const m2 = title.match(/(\d)\s*[ª°a]/);
    if (m2 && title.includes("segnare")) return parseInt(m2[1], 10);
    return 1;                                              // marcatore senza ordinale = trattalo come 1°
  }
  // punteggio di preferenza per "gol Casa/Ospite 1° tempo". Più alto = preferito.
  // Regola: tra i marcatori (1ª..5ª squadra a segnare) preferisci SEMPRE l'ordinale più
  // basso ancora disponibile (= il prossimo gol da fare). Marcatore > risultato > altro.
  function firstHalfScore(panel) {
    const t = panelTitle(panel);
    const ord = scorerOrdinal(t);
    if (ord >= 1 && ord <= 5) return 1000 - ord * 10;     // 1ª=990, 2ª=980 … 5ª=950
    if (t.includes("segnare") || t.includes("gol")) return 900; // altro marcatore/gol 1°T
    if (t.includes("risultato")) return 400;               // esito 1X2 1° tempo
    return 200;                                            // qualsiasi altro mercato 1°T
  }
  function findFirstHalfPanel() {
    const all = [...document.querySelectorAll("ms-option-panel, .option-panel")];
    const cand = all.filter(p => {
      if (p.offsetParent === null) return false;           // solo visibili
      if (!panelHasFirstHalf(p)) return false;             // deve essere del 1° tempo (tab A o titolo B)
      // forma A (ha la tab): le quote possono ancora essere di un altro periodo → ok comunque,
      // le sincronizziamo dopo. forma B (solo titolo): servono già ≥2 quote in pagina.
      if (firstHalfTab(p)) return true;
      return picksOfMarket(p).length >= 2;
    });
    const uniq = [...new Set(cand)];
    if (!uniq.length) return null;
    // preferisci il marcatore con ordinale più basso (prossimo gol), poi risultato, poi altro
    uniq.sort((a, b) => firstHalfScore(b) - firstHalfScore(a));
    return uniq[0];
  }
  // il 1° tempo è disponibile in pagina? (per mostrare i tasti)
  function hasFirstHalfMarket() { return !!findFirstHalfPanel(); }

  // gioca un lato (casa=1ª / ospite=ultima). primoTempo=true → mercato 1° tempo (forma A o B).
  async function playSide(which, primoTempo) {
    if (running) return;
    let picks, fhSuffix = "";
    if (primoTempo) {
      const panel = findFirstHalfPanel();
      if (!panel) {
        toast("Mercato 1° Tempo non disponibile in questa fase della partita.", "warn", 5000);
        return;
      }
      // etichetta: quale gol del 1°T stai giocando (1°/2°/3°… marcatore)
      const ord = scorerOrdinal(panelTitle(panel));
      fhSuffix = ord >= 1 && ord <= 5 ? ` (1°T · ${ord}° gol)` : " (1°T)";
      const tab = firstHalfTab(panel);
      if (tab) {
        // FORMA A: c'è la tab. Se non è già attiva, cliccala e ASPETTA che si attivi davvero.
        if (!tabSelected(tab)) {
          realClick(tab);
          const ok = await waitFor(() => tabSelected(tab) ? true : null, 1500, 30);
          if (!ok) {
            // la tab NON si è attivata → NON giocare (rischio periodo sbagliato / tempo pieno)
            toast("Non riesco ad attivare la tab «1° tempo». Riprova o clicca tu la tab.", "warn", 6000);
            return;
          }
          // dopo il cambio tab le quote si rigenerano: aspetta che siano pronte
          await waitFor(() => picksOfMarket(panel).length >= 2 ? true : null, 1200, 30);
        }
      }
      // FORMA B (titolo con "1° tempo"): nessuna tab, le quote sono già quelle giuste.
      picks = picksOfMarket(panel);
      if (picks.length < 2) {
        toast("Quote 1° Tempo non ancora pronte. Riprova tra un attimo.", "warn", 4000);
        return;
      }
    } else {
      picks = firstVisibleMarketPicks();
      if (!picks) {
        toast("Nessun mercato con quote visibile. Apri un mercato della partita.", "warn", 5000);
        return;
      }
    }
    const q = which === "casa" ? picks[0] : picks[picks.length - 1];
    const label = quotaLabel(q) + fhSuffix;
    realClick(clickTargetOfQuota(q));   // aggiunge al carrello
    autoPlay(label);
  }

  // ───────────────────── CLICK su quota = auto-play ─────────────────────
  // NON blocchiamo il click nativo (deve aggiungere la quota al carrello). Partiamo
  // in parallelo con autoPlay che aspetta la schedina.
  document.addEventListener("click", function (e) {
    if (!enabled || recKey) return;
    if (e.target && e.target.closest && e.target.closest("#bwfb-panel")) return;
    const q = quotaFromTarget(e.target);
    if (!q) return;
    autoPlay(quotaLabel(q));
  }, false);

  // ───────────────────── hotkey listener ─────────────────────
  const REC_LABEL = { casa: "CASA", ospite: "OSPITE", casa1t: "GOL CASA 1°T", ospite1t: "GOL OSPITE 1°T" };
  document.addEventListener("keydown", function (e) {
    if (recKey) {
      e.preventDefault();
      const which = recKey;
      if (which === "casa")     { keyCasa     = e.key; try { localStorage.setItem(LS_KEY_CASA,      keyCasa);     } catch (er) {} }
      if (which === "ospite")   { keyOspite   = e.key; try { localStorage.setItem(LS_KEY_OSPITE,    keyOspite);   } catch (er) {} }
      if (which === "casa1t")   { keyCasa1t   = e.key; try { localStorage.setItem(LS_KEY_CASA_1T,   keyCasa1t);   } catch (er) {} }
      if (which === "ospite1t") { keyOspite1t = e.key; try { localStorage.setItem(LS_KEY_OSPITE_1T, keyOspite1t); } catch (er) {} }
      recKey = null; paintPanel();
      toast(`Tasto ${REC_LABEL[which] || which} registrato`, "ok", 2500);
      return;
    }
    if (!enabled) return;
    const tag = (e.target && e.target.tagName) || "";
    if (tag === "INPUT" || tag === "TEXTAREA" || (e.target && e.target.isContentEditable)) return;
    // 1° tempo hanno priorità (tasti distinti); poi Casa/Ospite mercato principale.
    if (keyCasa1t && e.key === keyCasa1t)          { e.preventDefault(); playSide("casa", true); }
    else if (keyOspite1t && e.key === keyOspite1t) { e.preventDefault(); playSide("ospite", true); }
    else if (keyCasa && e.key === keyCasa)         { e.preventDefault(); playSide("casa", false); }
    else if (keyOspite && e.key === keyOspite)     { e.preventDefault(); playSide("ospite", false); }
  }, true);

  // ───────────────────── PANNELLO (nero/oro) ─────────────────────
  const T = { accent: "#d4af37", bg: "#0b0b0d", box: "#16161a", border: "#2a2a30", ok: "#1a9e5f" };

  function ensurePanel() {
    if (document.getElementById("bwfb-panel")) return;
    const style = document.createElement("style");
    style.textContent = `
      #bwfb-panel{position:fixed;right:16px;bottom:16px;z-index:2147483647;width:236px;
        font:13px/1.4 -apple-system,Segoe UI,sans-serif;color:#fff;background:${T.bg};
        border:1px solid ${T.border};border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.55);overflow:hidden}
      #bwfb-panel .hd{display:flex;align-items:center;justify-content:space-between;padding:11px 13px;
        background:linear-gradient(135deg,#000 0%,#1a1a1e 55%,${T.accent} 160%);color:${T.accent};
        font-weight:800;border-bottom:1px solid ${T.accent}55}
      #bwfb-panel .hd small{opacity:.85;font-weight:600;color:${T.accent}}
      #bwfb-panel .bd{padding:12px 13px;display:flex;flex-direction:column;gap:10px}
      #bwfb-panel .row{display:flex;align-items:center;justify-content:space-between;gap:8px;
        background:${T.box};border:1px solid ${T.border};border-radius:9px;padding:9px 11px}
      #bwfb-panel .lbl{font-weight:700}
      #bwfb-panel input#bwfb-stake{width:88px;padding:7px 9px;border-radius:7px;border:1px solid ${T.border};
        background:${T.bg};color:${T.accent};font-weight:800;text-align:right;font-size:15px}
      #bwfb-panel .sw{position:relative;width:44px;height:24px;border-radius:24px;background:#444;cursor:pointer;transition:.2s;flex:none}
      #bwfb-panel .sw.on{background:${T.ok}}
      #bwfb-panel .sw::after{content:"";position:absolute;top:2px;left:2px;width:20px;height:20px;border-radius:50%;background:#fff;transition:.2s}
      #bwfb-panel .sw.on::after{left:22px}
      #bwfb-panel .keyrow .kl{font-weight:700;flex:1}
      #bwfb-panel .keybtn{cursor:pointer;border:1px solid ${T.border};background:${T.box};color:#fff;
        border-radius:8px;padding:6px 10px;font-weight:800;font-size:12px;min-width:74px;text-align:center}
      #bwfb-panel .keybtn:hover{border-color:${T.accent}}
      #bwfb-panel .keybtn.rec{background:${T.accent};border-color:${T.accent};color:#000}
      #bwfb-panel .hint{font-size:11.5px;opacity:.82;text-align:center;line-height:1.35}
      #bwfb-panel .hint b{color:${T.accent}}
      #bwfb-panel .crono{display:flex;align-items:center;justify-content:center;gap:8px;
        background:#000;border:1px solid ${T.border};border-radius:9px;padding:8px 11px}
      #bwfb-panel .crono .ct{font-size:11px;opacity:.7;letter-spacing:.5px;text-transform:uppercase}
      #bwfb-panel #bwfb-crono{font:800 22px/1 ui-monospace,Menlo,Consolas,monospace;color:#666;
        min-width:78px;text-align:right;font-variant-numeric:tabular-nums}
      #bwfb-panel #bwfb-crono.run{color:${T.accent};text-shadow:0 0 8px ${T.accent}66}
      #bwfb-panel #bwfb-crono.done{color:${T.ok}}
      #bwfb-panel .keyrow.t1{border-color:${T.accent}44}
      #bwfb-panel .keyrow.t1 .kl{color:${T.accent}}
      #bwfb-toast{position:fixed;right:16px;bottom:230px;z-index:2147483647;max-width:290px;
        font:13px/1.4 -apple-system,Segoe UI,sans-serif;color:#fff;padding:11px 14px;border-radius:10px;
        box-shadow:0 6px 20px rgba(0,0,0,.5);display:none;font-weight:600}
    `;
    document.head.appendChild(style);

    const p = document.createElement("div");
    p.id = "bwfb-panel";
    p.innerHTML = `
      <div class="hd"><span>⚡ Bwin Fast Bet</span><small>v1.2</small></div>
      <div class="bd">
        <div class="row"><span class="lbl">Fast Bet</span><div class="sw" id="bwfb-sw"></div></div>
        <div class="row"><span class="lbl">Importo (€)</span><input type="number" id="bwfb-stake" min="0.05" step="0.05"></div>
        <div class="crono"><span class="ct">⏱️ Crono</span><span id="bwfb-crono">0.00s</span></div>
        <div class="row keyrow"><span class="kl">🏠 Casa</span><div class="keybtn" id="bwfb-keycasa">registra</div></div>
        <div class="row keyrow"><span class="kl">✈️ Ospite</span><div class="keybtn" id="bwfb-keyosp">registra</div></div>
        <div class="row keyrow t1" id="bwfb-row-casa1t" style="display:none" title="1ª squadra a segnare — tab 1° tempo: Casa (prima quota)"><span class="kl">⚽ Gol Casa 1°T</span><div class="keybtn" id="bwfb-keycasa1t">registra</div></div>
        <div class="row keyrow t1" id="bwfb-row-osp1t" style="display:none" title="1ª squadra a segnare — tab 1° tempo: Ospite (ultima quota)"><span class="kl">⚽ Gol Ospite 1°T</span><div class="keybtn" id="bwfb-keyosp1t">registra</div></div>
        <div class="hint" id="bwfb-hint"></div>
      </div>`;
    (document.body || document.documentElement).appendChild(p);

    const stakeInput = p.querySelector("#bwfb-stake");
    stakeInput.value = stake;
    stakeInput.addEventListener("input", () => {
      const v = parseFloat(stakeInput.value);
      if (v > 0) { stake = v; try { localStorage.setItem(LS_STAKE, String(v)); } catch (e) {} paintPanel(); }
    });
    p.querySelector("#bwfb-sw").addEventListener("click", () => {
      enabled = !enabled; try { localStorage.setItem(LS_ENABLED, enabled ? "1" : "0"); } catch (er) {}
      paintPanel();
    });
    p.querySelector("#bwfb-keycasa").addEventListener("click", () => { recKey = "casa"; paintPanel(); toast("Premi un tasto per CASA…", "info", 4000); });
    p.querySelector("#bwfb-keyosp").addEventListener("click", () => { recKey = "ospite"; paintPanel(); toast("Premi un tasto per OSPITE…", "info", 4000); });
    p.querySelector("#bwfb-keycasa1t").addEventListener("click", () => { recKey = "casa1t"; paintPanel(); toast("Premi un tasto per GOL CASA 1°T…", "info", 4000); });
    p.querySelector("#bwfb-keyosp1t").addEventListener("click", () => { recKey = "ospite1t"; paintPanel(); toast("Premi un tasto per GOL OSPITE 1°T…", "info", 4000); });
    paintPanel();
  }

  function paintPanel() {
    const p = document.getElementById("bwfb-panel");
    if (!p) return;
    const sw = p.querySelector("#bwfb-sw"); if (sw) sw.classList.toggle("on", enabled);
    const kc = p.querySelector("#bwfb-keycasa");
    if (kc) { kc.textContent = recKey === "casa" ? "premi…" : keyLabel(keyCasa); kc.classList.toggle("rec", recKey === "casa"); }
    const ko = p.querySelector("#bwfb-keyosp");
    if (ko) { ko.textContent = recKey === "ospite" ? "premi…" : keyLabel(keyOspite); ko.classList.toggle("rec", recKey === "ospite"); }
    const kc1 = p.querySelector("#bwfb-keycasa1t");
    if (kc1) { kc1.textContent = recKey === "casa1t" ? "premi…" : keyLabel(keyCasa1t); kc1.classList.toggle("rec", recKey === "casa1t"); }
    const ko1 = p.querySelector("#bwfb-keyosp1t");
    if (ko1) { ko1.textContent = recKey === "ospite1t" ? "premi…" : keyLabel(keyOspite1t); ko1.classList.toggle("rec", recKey === "ospite1t"); }
    // righe 1° tempo: mostrate solo se il mercato è in pagina O se hai già un tasto registrato
    const has1t = hasFirstHalfMarket() || keyCasa1t || keyOspite1t;
    const r1 = p.querySelector("#bwfb-row-casa1t"), r2 = p.querySelector("#bwfb-row-osp1t");
    if (r1) r1.style.display = has1t ? "" : "none";
    if (r2) r2.style.display = has1t ? "" : "none";
    const hint = p.querySelector("#bwfb-hint");
    if (hint) hint.innerHTML = `<b>Clicca una quota</b> o premi Casa/Ospite<br>per giocare ${stake.toFixed(2).replace(".", ",")}€ (Casa=1ª, Ospite=ultima).`;
  }

  function keyLabel(k) {
    if (!k) return "(nessuno)";
    if (k === " ") return "Spazio";
    if (k === "ArrowUp") return "↑"; if (k === "ArrowDown") return "↓";
    if (k === "ArrowLeft") return "←"; if (k === "ArrowRight") return "→";
    return k.length === 1 ? k.toUpperCase() : k;
  }

  // ───────────────────── toast ─────────────────────
  let toastTimer = null;
  function toast(msg, kind, ms) {
    try {
      let t = document.getElementById("bwfb-toast");
      if (!t) { t = document.createElement("div"); t.id = "bwfb-toast"; (document.body||document.documentElement).appendChild(t); }
      const col = kind === "ok" ? "#0a7d2c" : kind === "warn" ? "#c0182b" : kind === "info" ? "#1a1a1e" : "#333";
      t.style.background = col; t.style.border = kind === "info" ? "1px solid #d4af37" : "none";
      t.style.display = "block"; t.innerHTML = msg;
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => { t.style.display = "none"; }, ms || 3500);
    } catch (e) {}
  }

  function boot() {
    ensurePanel();
    setInterval(ensurePanel, 3000);
    // ridisegno periodico: fa comparire/sparire le righe Gol 1°T quando il
    // mercato 1° tempo entra/esce dalla pagina (senza toccare il crono in corso).
    setInterval(() => { if (!recKey) paintPanel(); }, 2500);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, { once: true });
  else boot();

  console.log("%c[Bwin FastBet v1.2]%c click su una quota o hotkey Casa/Ospite (+ Gol 1°T, copre 1°-5° gol) per giocare col tuo importo; cronometro da 0 al click",
    "color:#000;background:#d4af37;padding:1px 6px;border-radius:3px;font-weight:bold", "color:inherit");
})();
